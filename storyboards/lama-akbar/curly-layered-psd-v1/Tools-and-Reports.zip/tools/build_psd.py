#!/usr/bin/env python3
"""Write a real 8-bit RGB PSD from ordered RGBA PNG layers and optional native masks."""
import argparse,hashlib,json,struct,math,zlib
from pathlib import Path
from PIL import Image,ImageChops,ImageCms
import numpy as np

def predicted_plane(im):
 raw=np.asarray(im,dtype=np.uint8)
 encoded=raw.copy()
 encoded[:,1:]=(raw[:,1:].astype(np.int16)-raw[:,:-1].astype(np.int16)).astype(np.uint8)
 return encoded.tobytes()

def pack(fmt,*v):return struct.pack('>'+fmt,*v)
def block(data):return pack('I',len(data))+data

def build(manifest,out):
 root=manifest.parent.resolve();s=json.loads(manifest.read_text(encoding='utf8'))
 if out.exists():raise ValueError('Choose a new output filename')
 if set(s)!={'width','height','layers'}:raise ValueError('Expected width,height,layers')
 w,h=s['width'],s['height']
 if not all(type(x)is int and 1<=x<=8000 for x in [w,h]) or w*h>16000000:raise ValueError('Canvas limit: 8000px per side and 16M pixels')
 if not isinstance(s['layers'],list) or not 1<=len(s['layers'])<=200:raise ValueError('Need 1–200 layers, front to back')
 records=[];channels=[];prepared=[];names=set();manifest_layers=[]
 def asset(rel):
  if not isinstance(rel,str):raise ValueError('Asset path must be text')
  p=(root/rel).resolve()
  if not p.is_relative_to(root) or not p.is_file():raise ValueError('Missing asset or path outside manifest folder')
  return p
 for l in s['layers']:
  if not isinstance(l,dict) or set(l)-{'name','png','x','y','opacity','visible','mask'} or not {'name','png'}<=set(l):raise ValueError('Invalid layer fields')
  name=l['name']
  if not isinstance(name,str) or not name or len(name)>200 or name in names:raise ValueError('Layer names must be unique nonempty strings')
  names.add(name);im=Image.open(asset(l['png'])).convert('RGBA');lw,lh=im.size;x,y=l.get('x',0),l.get('y',0)
  if type(x)is not int or type(y)is not int or x<0 or y<0 or x+lw>w or y+lh>h:raise ValueError('Layer must fit canvas')
  opacity=l.get('opacity',255);visible=l.get('visible',True)
  if type(opacity)is not int or not 0<=opacity<=255 or not isinstance(visible,bool):raise ValueError('Invalid opacity/visibility')
  pix=[(-1,im.getchannel('A')),(0,im.getchannel('R')),(1,im.getchannel('G')),(2,im.getchannel('B'))];mask=None
  if 'mask'in l:
   mask=Image.open(asset(l['mask'])).convert('L')
   if mask.size!=im.size:raise ValueError('Mask size must equal layer size')
   pix.append((-2,mask));mask_info=pack('iiiiBB',y,x,y+lh,x+lw,0,0)+b'\0\0'
  else:mask_info=b''
  encoded=[(id,pack('H',3)+zlib.compress(predicted_plane(p),9)) for id,p in pix]
  ascii_name=name.encode('ascii','replace')[:255];pascal=bytes([len(ascii_name)])+ascii_name;pascal+=b'\0'*((-len(pascal))%4)
  uni=name.encode('utf-16be');unicode_data=pack('I',len(uni)//2)+uni;unicode_block=b'8BIMluni'+block(unicode_data);unicode_block+=b'\0'*(len(unicode_data)%2)
  extra=block(mask_info)+block(b'')+pascal+unicode_block
  record=pack('iiiiH',y,x,y+lh,x+lw,len(encoded))+b''.join(pack('hI',id,len(data)) for id,data in encoded)+b'8BIMnorm'+pack('BBBB',opacity,0,0 if visible else 2,0)+block(extra)
  records.append(record);channels.append(b''.join(data for _,data in encoded));prepared.append((im,mask,x,y,opacity,visible))
  manifest_layers.append({'name':name,'size':[lw,lh],'position':[x,y],'native_mask':mask is not None,'opacity':opacity,'visible':visible})
 comp=Image.new('RGBA',(w,h))
 for im,mask,x,y,opacity,visible in reversed(prepared):
  if not visible:continue
  im=im.copy();alpha=im.getchannel('A')
  if mask is not None:alpha=ImageChops.multiply(alpha,mask)
  if opacity!=255:alpha=alpha.point(lambda p:p*opacity//255)
  im.putalpha(alpha);comp.alpha_composite(im,(x,y))
 layer_info=pack('h',-len(records))+b''.join(reversed(records))+b''.join(reversed(channels));layer_info+=b'\0'*(len(layer_info)%2)
 layer_and_mask=block(layer_info)+block(b'')
 header=b'8BPS'+pack('H',1)+b'\0'*6+pack('HIIHH',4,h,w,8,3)
 icc=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes();resource=b'8BIM'+pack('H',1039)+b'\0\0'+block(icc);resource+=b'\0'*(len(icc)%2)
 data=header+block(b'')+block(resource)+block(layer_and_mask)+pack('H',3)+zlib.compress(b''.join(predicted_plane(comp.getchannel(c)) for c in ['R','G','B','A']),9)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);comp.save(out.with_suffix('.preview.png'))
 report={'format':'PSD v1 / 8-bit RGB / normal raster layers','size':[w,h],'layers':manifest_layers,'sha256':hashlib.sha256(data).hexdigest(),'native_photoshop_open':'unverified','native_after_effects_import':'unverified','brush_history':'not present; cannot reconstruct original strokes from a flattened image'}
 out.with_suffix('.qc.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');return report

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('manifest',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 try:r=build(a.manifest,a.out);print(json.dumps({'layers':len(r['layers']),'size':r['size'],'native_photoshop_open':'unverified'}))
 except (ValueError,OSError) as e:p.exit(1,str(e)+'\n')
