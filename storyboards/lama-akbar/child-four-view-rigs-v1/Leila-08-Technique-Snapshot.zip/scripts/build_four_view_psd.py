from pathlib import Path
import json,hashlib,shutil,os
from gi.repository import Gimp,Gio
ROOT=Path('/workspace/output/lama-child-four-view-rigs-v1')
def export(img,path,kind):
 p=Gimp.get_pdb().lookup_procedure('file-'+kind+'-export');c=p.create_config()
 for k,v in [('run-mode',Gimp.RunMode.NONINTERACTIVE),('image',img),('file',Gio.File.new_for_path(str(path))),('options',Gimp.ExportOptions())]:c.set_property(k,v)
 if kind=='psd':c.set_property('include-color-profile',True)
 if kind=='png':c.set_property('compression',9)
 result=p.run(c);assert result.index(0)==Gimp.PDBStatusType.SUCCESS,str(path)
def key(l):
 g,n=l['group'],l['name'];side='Near'if n.endswith('_L')else'Far'
 if g=='Body':
  if 'Hand_'in n:return side+'_Hand_Skin'
  if 'Arm_'in n or'Forearm_'in n:return side+'_Arm_Skin'
  if 'Thigh_'in n or'Shin_'in n or'BareFoot_'in n:return side+'_Leg_Skin'
  return'Basic_Clothes'
 if g=='Blouse':return'Blouse_'+side+'_Sleeve'if'Sleeve'in n else'Blouse_Torso'
 if g in ['Shoes','Socks']:return g+'_'+side
 return g
reports=json.loads((ROOT/'native-psd-qc.json').read_text()) if (ROOT/'native-psd-qc.json').exists() else {}
for view in os.environ.get('PSD_VIEWS','front,threequarter,side,back').split(','):
 R=ROOT/view;A=R/'art';m=json.loads((A/'layers.json').read_text());im=Gimp.Image.new(m['width'],m['height'],Gimp.ImageBaseType.RGB);im.set_color_profile(Gimp.ColorProfile.new_rgb_srgb());runs=[]
 for l in m['layers']:
  k=key(l)
  if not runs or runs[-1][0]!=k:runs.append((k,[]))
  runs[-1][1].append(l)
 for index,(name,items)in reversed(list(enumerate(runs))):
  g=Gimp.GroupLayer.new(im,('%02d_'%(index+1))+name);im.insert_layer(g,None,0)
  for l in reversed(items):
   layer=Gimp.file_load_layer(Gimp.RunMode.NONINTERACTIVE,im,Gio.File.new_for_path(str(A/l['png'])));im.insert_layer(layer,g,0);layer.set_name(l['name']);layer.set_offsets(l['x'],l['y'])
 path=R/('Leila-08-'+view+'.psd');export(im,path,'psd');im.delete();image=Gimp.file_load(Gimp.RunMode.NONINTERACTIVE,Gio.File.new_for_path(str(path)));lookup={}
 def collect(l):
  lookup[l.get_name()]=l
  if l.is_group():
   for child in l.get_children():collect(child)
 for l in image.get_layers():collect(l)
 assert all(l['name']in lookup for l in m['layers']);vis={k:l.get_visible()for k,l in lookup.items()}
 eye='Eye_R'if view in ['front','threequarter']else'Eye_L'
 cases={'normal':[],'body_barefoot':['Dress','Blouse','Socks','Shoes'],'no_dress':['Dress'],'no_socks':['Socks'],'no_shoes':['Shoes'],'no_footwear':['Socks','Shoes'],'no_eye_R':[eye],'no_glasses':['Glasses'],'blank_face':['Face','Glasses'],'no_hair':['Hair'],'bare_head':['Hair','Face','Glasses']}
 for name,hidden in cases.items():
  for k,l in lookup.items():l.set_visible(vis[k])
  for l in m['layers']:
   if l['group']in hidden or l['name']in hidden:lookup[l['name']].set_visible(False)
  export(image,R/'proof'/('native-'+name+'.png'),'png')
 image.delete();q={'application':'GIMP 3','psd_save_and_reopen':'passed','groups_in_stack_order':[n for n,items in runs],'leaf_layers':len(m['layers']),'visibility_cases':list(cases),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'native_photoshop':'not run','native_after_effects':'not available'};(R/'native-psd-qc.json').write_text(json.dumps(q,indent=2)+'\n');reports[view]=q;print('NATIVE PSD',view,'DONE',flush=True)
(ROOT/'native-psd-qc.json').write_text(json.dumps(reports,indent=2)+'\n')
