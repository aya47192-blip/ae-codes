from pathlib import Path
import json,math,shutil
import numpy as np
from PIL import Image,ImageDraw
from scipy import ndimage
from scipy.spatial import ConvexHull
ROOT=Path('/workspace/output/lama-child-four-view-rigs-v1');S=json.loads((ROOT/'generated-source-map.json').read_text());W,H=1200,1800;yy,xx=np.indices((H,W))
CFG={
'threequarter':dict(headbox=(438,125,844,610),center=625,torso=[(548,535),(701,540),(732,590),(704,710),(738,994),(468,994),(505,820),(541,680),(510,585)],shirt=(475,520,770,1065),shorts=(448,970,786,1175),near=((508,585),(451,806),(399,1012)),far=((743,596),(799,814),(860,1017)),hips=((527,1130),(686,1130)),knees=((512,1420),(671,1420)),ankles=((503,1650),(663,1650)),hands=((328,1020,442,1166),(825,1020,924,1166)),feet=((426,1630,635,1783),(611,1630,824,1783)),sock=((438,1510,646,1783),(615,1510,826,1783)),shoes=((426,1675,650,1788),(612,1670,834,1786)),face=[(534,208),(624,173),(735,176),(780,207),(796,270),(808,376),(804,437),(778,481),(704,503),(613,493),(556,463),(501,450),(455,415),(454,359),(488,340),(530,345)],eyes=[(590,299,682,382),(749,296,804,376)],brows=[(560,210,697,282),(724,213,808,279)],mouth=(676,412,755,445),nose=(709,354,755,404),ear=(496,395,70,61),bibsplit=810),
'side':dict(headbox=(528,129,846,600),center=634,torso=[(588,530),(681,550),(726,620),(733,950),(706,990),(537,990),(540,800),(545,632)],shirt=(523,527,742,1065),shorts=(522,965,746,1174),near=((602,595),(624,815),(626,1018)),far=((590,595),(612,815),(614,1018)),hips=((605,1130),(592,1130)),knees=((578,1425),(566,1425)),ankles=((557,1650),(545,1650)),hands=((583,1020,696,1165),(583,1020,696,1165)),feet=((493,1630,807,1786),(493,1630,807,1786)),sock=((495,1500,820,1785),(483,1500,808,1785)),shoes=((486,1663,826,1789),(474,1663,814,1789)),face=[(696,192),(757,179),(798,217),(807,279),(810,352),(843,374),(840,390),(820,401),(817,438),(800,470),(766,491),(694,497),(654,478),(623,448),(581,438),(568,386),(589,350),(632,344),(658,300),(666,251)],eyes=[(735,299,785,382)],brows=[(695,215,807,285)],mouth=(794,411,827,444),nose=(818,372,847,399),ear=(613,395,60,64),bibsplit=810),
'back':dict(headbox=(390,98,809,603),center=600,torso=[(481,531),(724,531),(715,680),(702,870),(748,988),(453,988),(490,870),(478,680)],shirt=(437,526,763,1070),shorts=(432,967,776,1176),near=((469,585),(406,802),(343,998)),far=((735,585),(796,802),(861,998)),hips=((516,1120),(682,1120)),knees=((509,1412),(690,1412)),ankles=((506,1645),(690,1645)),hands=((274,1002,371,1135),(831,1002,928,1135)),feet=((436,1627,576,1769),(626,1627,770,1769)),sock=((437,1493,579,1771),(625,1493,770,1771)),shoes=((425,1650,585,1774),(621,1650,780,1774)),face=[],eyes=[],brows=[],mouth=None,nose=None,ear=None,bibsplit=806)
}
def polygon(points):
 im=Image.new('L',(W,H));ImageDraw.Draw(im).polygon(points,fill=255);return np.array(im)>0
def disk(p,r):return (xx-p[0])**2+(yy-p[1])**2<=r*r
def ellipse(box):
 x0,y0,x1,y1=box;return ((xx-(x0+x1)/2)/max(1,(x1-x0)/2))**2+((yy-(y0+y1)/2)/max(1,(y1-y0)/2))**2<=1
def mask(im,v):
 a=np.array(im).copy();a[:,:,3]=(a[:,:,3].astype(float)*np.clip(v,0,1)).astype('uint8');a[a[:,:,3]==0,:3]=0;return Image.fromarray(a)
def clean(im,erode=0,largest=False):
 a=np.array(im.convert('RGBA'));v=a[:,:,3]>235
 if largest:
  lab,n=ndimage.label(v);sizes=np.bincount(lab.ravel());sizes[0]=0;v=lab==sizes.argmax()
 if erode:v=ndimage.binary_erosion(v,iterations=erode)
 a[:,:,3]=np.where(v,255,0);a[~v,:3]=0;return Image.fromarray(a)
def fit(im,box):
 o=Image.new('RGBA',(W,H));im=im.resize((box[2]-box[0],box[3]-box[1]),Image.Resampling.LANCZOS);o.alpha_composite(im,(box[0],box[1]));return o
def component(im,box,skin=False):
 a=np.array(im).copy();v=a[:,:,3]>230;reg=polygon([(box[0],box[1]),(box[2],box[1]),(box[2],box[3]),(box[0],box[3])]);v&=reg
 if skin:
  r,g,b=a[:,:,:3].transpose(2,0,1).astype(int);v&=(r-g>34)&(g-b>17)&(r>140)
 lab,n=ndimage.label(v);sz=np.bincount(lab.ravel());sz[0]=0;v=ndimage.binary_fill_holes(lab==sz.argmax());out=mask(im,v);return out.crop(out.getbbox())
def cell(atlas,col,row):
 w,h=atlas.size;im=atlas.crop((col*w//2,row*h//4,(col+1)*w//2,(row+1)*h//4));im=clean(im,1,True);return im.crop(im.getbbox())
def straight(im):
 a=np.array(im);out=np.zeros((a.shape[0],a.shape[1]*2,4),'uint8')
 for y,row in enumerate(a):
  xs=np.where(row[:,3]>5)[0]
  if len(xs):
   lo,hi=int(xs[0]),int(xs[-1])+1;start=out.shape[1]//2-(hi-lo)//2;out[y,start:start+hi-lo]=row[lo:hi]
 out=Image.fromarray(out);return out.crop(out.getbbox())
def along(im,p,q,width,top,bottom=0):
 p,q=np.array(p,float),np.array(q,float);v=q-p;L=np.linalg.norm(v);u=v/L;im=im.resize((round(width),round(L+top+bottom)),Image.Resampling.LANCZOS);im=im.rotate(math.degrees(math.atan2(u[0],u[1])),Image.Resampling.BICUBIC,expand=True);center=(p+q)/2+u*(bottom-top)/2;o=Image.new('RGBA',(W,H));o.alpha_composite(im,(round(center[0]-im.width/2),round(center[1]-im.height/2)));return o
skin_atlas=Image.open('/workspace/generated_images/exec-64575629-4775-4608-a20a-feb046dbc777.png').convert('RGBA')
def skinpaint(col,row):
 w,h=skin_atlas.size;im=clean(skin_atlas.crop((col*w//2,row*h//3,(col+1)*w//2,(row+1)*h//3)),0,True);im=im.crop(im.getbbox());w,h=im.size;return im.crop((int(w*.35),int(h*.25),int(w*.65),int(h*.75)))
paints={'UpperArm':skinpaint(0,0),'Forearm':skinpaint(1,0),'Thigh':skinpaint(0,1),'Shin':skinpaint(1,1)}
def limb(im,p,q,r0,r1,fade):
 p,q=np.array(p,float),np.array(q,float);u=q-p;L=np.linalg.norm(u);u/=L;t=(xx-p[0])*u[0]+(yy-p[1])*u[1];n=(xx-p[0])*(-u[1])+(yy-p[1])*u[0];rad=r0+(r1-r0)*np.clip(t/L,0,1);end=disk(q,r1);v=((t>=0)&(t<=L)&(abs(n)<=rad))|disk(p,r0)|end
 tex=im.resize((math.ceil(max(r0,r1)*2+6),math.ceil(L+r0+r1+2)),Image.Resampling.BICUBIC).convert('RGB').convert('RGBA');tex=tex.rotate(math.degrees(math.atan2(u[0],u[1])),Image.Resampling.BICUBIC,expand=True);center=(p+q)/2+u*(r1-r0)/2;o=Image.new('RGBA',(W,H));o.alpha_composite(tex,(round(center[0]-tex.width/2),round(center[1]-tex.height/2)));a=v.astype(float)
 if fade:a*=np.where(end,np.clip((L+r1*.90-t)/(r1*1.05),0,1),1)
 return mask(o,a)
heads=Image.open(S['heads']).convert('RGBA')
teal_atlas=Image.open('/workspace/generated_images/exec-05c73617-9585-4023-9f3a-2bfda031e33d.png').convert('RGBA')
def teal_piece(col,row):
 a=np.array(teal_atlas);lab,n=ndimage.label(a[:,:,3]>235);best=None;score=0
 for k in range(1,n+1):
  ys,xs=np.where(lab==k)
  if len(xs)<100:continue
  cx,cy=xs.mean(),ys.mean()
  if int(cx/(a.shape[1]/3))==col and (cy>420)==bool(row) and len(xs)>score:best=k;score=len(xs)
 assert best is not None
 a[:,:,3]=np.where(lab==best,255,0);a[a[:,:,3]==0,:3]=0;im=Image.fromarray(a);return im.crop(im.getbbox())
def build(view):
 c=CFG[view];R=ROOT/view;A=R/'art';(A/'assets').mkdir(exist_ok=True);P=R/'proof';P.mkdir(exist_ok=True);source=Image.open(A/'reference-cutout.png').convert('RGBA');base=clean(Image.open(S['base-'+view]).convert('RGBA').resize((W,H),Image.Resampling.LANCZOS));atlas=Image.open(S['atlas-'+view]).convert('RGBA');layers=[];bones={}
 def bone(name,p,parent):bones[name]={'pivot':list(p),'parent':parent}
 bone('Pelvis',(600,1100),None);bone('Torso',(600,585),'Pelvis');bone('Head',(625 if view!='back'else 600,520),'Torso')
 for side,key in [('L','near'),('R','far')]:
  sh,el,wr=c[key];bone('UpperArm_'+side,sh,'Torso');bone('Forearm_'+side,el,'UpperArm_'+side);bone('Hand_'+side,wr,'Forearm_'+side);i=0 if side=='L'else 1;bone('Thigh_'+side,c['hips'][i],'Pelvis');bone('Shin_'+side,c['knees'][i],'Thigh_'+side);bone('Foot_'+side,c['ankles'][i],'Shin_'+side)
 def add(name,im,group,bone,material=None,z=0):
  b=im.getbbox()
  if not b:raise ValueError('Empty '+view+'/'+name)
  fn='assets/'+name+'.png';im.crop(b).save(A/fn);layers.append({'name':name,'png':fn,'x':b[0],'y':b[1],'group':group,'bone':bone,'material':material or group,'visible':True,'z':z})
 # Head underpainting is genuinely reconstructed artwork, with reference paint
 # restored only outside the removable feature zones.
 idx=['threequarter','side','back'].index(view);hw,hh=heads.size;head=clean(heads.crop((idx*hw//3,0,(idx+1)*hw//3,hh)),1,True);head=head.crop(head.getbbox());under=fit(head,c['headbox']);a=np.array(source);r,g,b=a[:,:,:3].transpose(2,0,1).astype(int);alpha=a[:,:,3]>230;headarea=(yy<552)&alpha;feature=np.zeros((H,W),bool);features=[];zones=np.zeros((H,W),bool)
 if view!='back':
  face=polygon(c['face']);whiteall=(r>210)&(g>210)&(b>180)&(r-g<35)&alpha
  support=np.zeros((H,W),bool);apertures=np.zeros((H,W),bool)
  for i,box in enumerate(c['eyes']):
   x0,y0,x1,y1=box
   if view=='threequarter'and i==0:roi=(xx>=577)&(xx<=686)&(yy>=289)&(yy<=385)
   elif view=='threequarter':roi=ellipse((741,288,805,382))&(xx<=803)
   else:roi=(xx>=730)&(xx<=795)&(yy>=292)&(yy<=386)
   strongwhite=(r>225)&(g>225)&(b>210)&(r-g<25)&(g-b<40)
   dark=(r<155)&(g<110)&(b<105);inside=(strongwhite|dark)&roi&alpha
   ys,xs=np.where(inside);pts=np.stack([xs,ys],axis=1);hull=ConvexHull(pts);ap=polygon(pts[hull.vertices].tolist());apertures|=ap
   lash=(xx>=x0-22)&(xx<=x1+23)&(yy>=y0-32)&(yy<=y0+15)&dark
   eye=ndimage.binary_dilation(ap|lash,iterations=1)&alpha
   features.append(('Eye_'+('L'if i==0 else'R'),eye));feature|=eye;zones|=ndimage.binary_dilation(eye,iterations=4)
  if view=='threequarter':
   support=ellipse((563,275,715,405))|ellipse((725,271,840,403))
   support|=polygon([(699,305),(747,303),(747,335),(697,337)])|polygon([(478,312),(579,301),(581,330),(478,344)])|polygon([(810,291),(856,288),(856,324),(810,334)])
  else:
   support=ellipse((790,269,837,411));support|=polygon([(632,311),(802,301),(803,337),(632,344)])
  frames=support&(r>75)&(r<242)&(g>70)&(b>45)&(r-g<52)&(g-b<65)&~strongwhite&~apertures&alpha
  frames=ndimage.binary_dilation(frames,iterations=2)&support&~apertures&alpha
  features.append(('Glasses_Frame',frames));feature|=frames;zones|=frames
  for i,box in enumerate(c['brows']):
   x0,y0,x1,y1=box
   if view=='threequarter'and i==1:
    v=polygon([(733,253),(734,242),(741,234),(755,233),(771,237),(786,245),(797,256),(803,267),(789,260),(775,254),(756,253),(744,252)])&alpha
   else:
    roi=(xx>=x0-8)&(xx<=x1+12)&(yy>=y0-6)&(yy<=y1+7);v=roi&(r<190)&(g<140)&alpha;lab,n=ndimage.label(v)
    target=(624,257)if view=='threequarter'else(751,258);best=None;bestd=1e9
    for k in range(1,n+1):
     ys,xs=np.where(lab==k)
     if len(xs)<80:continue
     d=(xs.mean()-target[0])**2+(ys.mean()-target[1])**2
     if d<bestd:bestd=d;best=k
    assert best is not None
    v=ndimage.binary_dilation(lab==best,iterations=3)&alpha
   features.append(('Brow_'+('L'if i==0 else'R'),v));feature|=v;zones|=(xx>=x0-15)&(xx<=x1+15)&(yy>=y0-15)&(yy<=y1+15)
  for name,box in [('Nose',c['nose']),('Mouth',c['mouth'])]:
   x0,y0,x1,y1=box
   if name=='Mouth'and view=='threequarter':x0,y0,x1,y1=685,408,786,451
   v=(xx>=x0-4)&(xx<=x1+8)&(yy>=y0-4)&(yy<=y1+5)&(r<230)&(g<165)&(r-g>23)&alpha;lab,n=ndimage.label(v);sizes=np.bincount(lab.ravel());sizes[0]=0
   if sizes.max()>3:v=ndimage.binary_dilation(lab==sizes.argmax(),iterations=2)&alpha
   features.append((name,v));feature|=v;zones|=(xx>=x0-12)&(xx<=x1+12)&(yy>=y0-12)&(yy<=y1+12)
  ex,ey,erx,ery=c['ear'];ear=((xx-ex)/erx)**2+((yy-ey)/ery)**2<1
  brown=(r<230)&(g<165)&(b<145);innerhair=(r<150)&(g<115)&~ndimage.binary_dilation(feature,iterations=2)&~ear&((xx<590)|(yy<285));hair=headarea&((brown&~face)|innerhair)&~feature
  surface=face&headarea&~ndimage.binary_dilation(feature,iterations=2)&~hair
  # Partition ALL original head pixels exactly. The clean underpainting is
  # behind this partition, never allowed to extend outside the approved head.
  neck=(yy>=480)&(yy<584)&(xx>565)&(xx<729)&alpha&(r>180)&(r-g>42)&(g-b>19)
  complete=(headarea&((yy<518)|face|hair))|neck
  owned=np.zeros((H,W),bool);partition=[]
  for name,v in features:
   if name=='Glasses_Frame':continue
   v=v&~owned&complete;owned|=v;partition.append((name,v))
  glass=frames&~owned&complete;owned|=glass;partition.append(('Glasses_Frame',glass))
  hair&=~owned;surface=complete&~hair&~owned
  # Use the genuinely blank generated face as the complete underpainting.
  # Keeping any flattened source face here would bake missed iris/frame ink
  # into the base and defeat independent feature visibility.
  under=mask(under,complete)
  cleanface=face&complete
  nx0,ny0,nx1,ny1=c['nose'];cleanface&=~((xx>=nx0-18)&(xx<=nx1+18)&(yy>=ny0-12)&(yy<=ny1+12))
  under.alpha_composite(mask(base,cleanface))
  under.alpha_composite(mask(source,(ear|neck)&complete&~owned))
  # Spectacle overhang outside the anatomical head must reveal background,
  # not a skin-colored copy of the frame's old alpha silhouette.
  anatomical=(np.array(base)[:,:,3]>230)|ear|neck
  under=mask(under,anatomical)
  hairpaint=mask(base,complete&~face&(yy<550));hairpaint.alpha_composite(mask(source,hair))
  add('Head_Skin',under,'Head','Head',z=145);add('Hair_Paint',hairpaint,'Hair','Head',z=170)
  for name,v in partition:add(name,mask(source,v),'Glasses'if name=='Glasses_Frame'else'Face','Head',z=195 if name=='Glasses_Frame'else 190)
 else:
  complete=headarea&(yy<535);hair=complete&(g<177)&(b<150)&(r<235);under=mask(under,complete);under.alpha_composite(mask(source,complete&~hair));add('Head_Skin',under,'Head','Head',z=145);add('Hair_Paint',mask(source,hair),'Hair','Head',z=170)
 # Exact approved teal painting is retained and split only at the waist.
 teal=(r<145)&(g>r*1.08)&(b>r*1.08)&alpha&(yy>520)&(yy<1400);teal=ndimage.binary_closing(teal,iterations=2);holes=ndimage.binary_fill_holes(teal)&~teal;lab,n=ndimage.label(holes);sizes=np.bincount(lab.ravel());small=(sizes<6000);small[0]=False;teal|=small[lab]
 if view=='threequarter':teal|=disk((606,658),29)|disk((747,651),24)
 elif view=='side':teal|=disk((713,660),24)
 teal&=alpha;split=c['bibsplit'];bib=teal&(yy<=split+14);skirt=teal&(yy>=split-8)
 col=['threequarter','side','back'].index(view)
 sb=mask(source,skirt).getbbox();bp=mask(source,bib).getbbox();skirtpaint=fit(teal_piece(col,1),sb)
 ys,xs=np.where(skirt);points=np.stack([xs,ys],axis=1);hull=ConvexHull(points);hullmask=polygon(points[hull.vertices].tolist());skirtpaint=mask(skirtpaint,hullmask)
 # Discard the original contact shadow around each occluding hand as well as
 # the missing hand pixels; otherwise that shadow resembles a stuck fabric tab.
 keep=np.ones((H,W),float)
 regions={'threequarter':[(388,1090,105,152),(870,1080,65,130)],'side':[(636,1080,115,175)],'back':[(323,1060,74,130),(874,1060,74,130)]}[view]
 for cx,cy,rx,ry in regions:
  dist=np.sqrt(((xx-cx)/rx)**2+((yy-cy)/ry)**2);keep*=np.clip((dist-.82)/.30,0,1)
 skirtpaint.alpha_composite(mask(source,skirt*keep))
 bibpaint=fit(teal_piece(col,0),bp);bibpaint.alpha_composite(mask(source,bib))
 add('Dress_Bib_Straps',bibpaint,'Dress','Torso',z=133);add('Dress_Skirt',skirtpaint,'Dress','Pelvis',z=132)
 # Basic top reuses generated opaque garment texture and has no source arm ink.
 old=Image.open('/workspace/output/lama-akbar-child-rig-pilot-v6/art/assets/v6-Skin_Torso.png').convert('RGBA');ow,oh=old.size;paint=old.crop((int(ow*.3),int(oh*.45),int(ow*.7),int(oh*.7))).convert('RGB').convert('RGBA');torso=fit(paint,(430,510,790,1005));torso=mask(torso,polygon(c['torso']));add('Skin_Torso',torso,'Body','Torso','BasicTop',z=52)
 pants=fit(cell(atlas,1,3),c['shorts']);add('Basic_Shorts_Pelvis',pants,'Body','Pelvis','BasicShorts',z=50)
 shirtpaint=cell(atlas,0,0) if view=='back' else cell(Image.open(S['atlas-back']).convert('RGBA'),0,0)
 shirt=fit(shirtpaint,c['shirt'])
 if view=='threequarter':top=polygon([(527,521),(584,505),(702,527),(764,591),(770,675),(575,681),(544,613)])
 elif view=='side':top=polygon([(544,532),(600,520),(707,548),(741,598),(740,682),(671,671),(566,600)])
 else:top=polygon([(479,520),(586,512),(723,524),(740,661),(465,661)])
 top&=alpha&~teal;shirt.alpha_composite(mask(source,top))
 central=(yy<690)|bib;add('Blouse_Torso',mask(shirt,central),'Blouse','Torso',z=120);add('Blouse_SidePanels',mask(shirt,~central),'Blouse','Torso',z=119)
 for i,side in enumerate(['L','R']):
  near=i==0;sh,el,wr=c['near'if near else'far'];width=149 if view=='back'else (151 if near else 114);sleeve=along(straight(cell(atlas,1,0)if near else cell(atlas,0,1)),sh,wr,width,64,0);v=np.array(wr,float)-sh;v/=np.linalg.norm(v);projection=(xx-el[0])*v[0]+(yy-el[1])*v[1];joint=disk(el,58 if near else 47);sz=142 if near else 8
  add('Blouse_UpperSleeve_'+side,mask(sleeve,(projection<=0)|joint),'Blouse','UpperArm_'+side,z=sz);add('Blouse_ForeSleeve_'+side,mask(sleeve,(projection>=0)|joint),'Blouse','Forearm_'+side,z=sz-.1)
  rad=1 if near or view=='back'else.83
  for part,ba,bb,r0,r1,fade in [('UpperArm','UpperArm','Forearm',48,43,True),('Forearm','Forearm','Hand',43,27,False),('Thigh','Thigh','Shin',67,49,True),('Shin','Shin','Foot',49,35,False)]:
   z=35 if near else 4
   if part in ['UpperArm','Forearm']and near:z=140
   im=limb(paints[part],bones[ba+'_'+side]['pivot'],bones[bb+'_'+side]['pivot'],r0*rad,r1*rad,fade);add('Skin_'+part+'_'+side,im,'Body',ba+'_'+side,'Skin',z=z)
  hb=c['hands'][i]
  hand=component(source,(hb[0]-20,hb[1]+8,hb[2]+20,hb[3]+12),True)
  hand=fit(hand,hb);add('Skin_Hand_'+side,hand,'Body','Hand_'+side,'Skin',z=150 if near else 5)
  fb=c['feet'][i];search=(fb[0]-35,1600,fb[2]+20,1795);foot=component(base,search,True);foot=fit(foot,fb);add('Skin_BareFoot_'+side,foot,'Body','Foot_'+side,'Skin',z=37 if near else 6)
  sock=fit(cell(atlas,1,1)if near else cell(atlas,0,2),c['sock'][i]);ank=bones['Foot_'+side]['pivot'];cap=disk(ank,25);add('Sock_Calf_'+side,mask(sock,(yy<=ank[1])|cap),'Socks','Shin_'+side,z=75 if near else 7);add('Sock_Foot_'+side,mask(sock,(yy>=ank[1])|cap),'Socks','Foot_'+side,z=76 if near else 7.1)
  shoe=fit(cell(atlas,1,2)if near else cell(atlas,0,3),c['shoes'][i]);ar=np.array(shoe);rr,gg,bb=ar[:,:,:3].transpose(2,0,1).astype(int);cream=(rr-gg<48)&(gg>140)&(bb>100);shoe=mask(shoe,~cream);add('Shoe_'+side,shoe,'Shoes','Foot_'+side,z=88 if near else 7.2)
 layers.sort(key=lambda l:l['z'],reverse=True);m={'version':7,'width':W,'height':H,'view':view,'reference':'reference-cutout.png','body_source':S['base-'+view],'layers':layers,'bones':bones,'provenance':'Newly generated underpaint/garment reconstructions plus original colored-view pixels; front v6 technique adapted to projected pivots. No native AE execution.'};(A/'layers.json').write_text(json.dumps(m,indent=2)+'\n')
 for name,hidden in {'normal':(),'no_dress':('Dress',),'body_barefoot':('Dress','Blouse','Socks','Shoes'),'no_socks':('Socks',),'no_shoes':('Shoes',),'no_footwear':('Socks','Shoes'),'no_eye_R':('Eye_R'if view=='threequarter'else'Eye_L',),'no_glasses':('Glasses',),'blank_face':('Face','Glasses')}.items():
  o=Image.new('RGBA',(W,H))
  for l in reversed(layers):
   if l['group']in hidden or l['name']in hidden:continue
   o.alpha_composite(Image.open(A/l['png']).convert('RGBA'),(l['x'],l['y']))
  o.save(P/(name+'.png'))
 print(view,len(layers),'layers',flush=True)
if __name__=='__main__':
 import sys
 for v in sys.argv[1:]or CFG:build(v)
