from pathlib import Path
import json
import numpy as np
from PIL import Image
R=Path('/workspace/output/lama-child-four-view-rigs-v1');yy,xx=np.indices((1800,1200))
for view in ['threequarter','side']:
 A=R/view/'art';m=json.loads((A/'layers.json').read_text())
 for l in m['layers']:
  if l['name'] not in ['Eye_L','Eye_R','Glasses_Frame']:continue
  p=A/l['png'];im=Image.open(p).convert('RGBA');a=np.array(im);x,y=l['x'],l['y'];X=xx[y:y+im.height,x:x+im.width];Y=yy[y:y+im.height,x:x+im.width];keep=np.ones(X.shape,bool)
  if l['name'].startswith('Eye_'):
   keep &= Y>289
   if view=='threequarter' and l['name']=='Eye_R':keep &= (((X-779)/39)**2+((Y-340)/58)**2<1)|((Y>290)&(Y<318)&(X>748)&(X<804))
  elif view=='threequarter':
   e=((X-782)/57)**2+((Y-337)/64)**2
   keep &= ~((e<.77)&(X>798))
  a[:,:,3]=np.where(keep,a[:,:,3],0);Image.fromarray(a).save(p)
