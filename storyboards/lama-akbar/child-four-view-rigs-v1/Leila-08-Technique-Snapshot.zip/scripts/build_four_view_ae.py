from pathlib import Path
import json,copy,shutil,hashlib,subprocess
R=Path('/workspace/output/lama-child-four-view-rigs-v1');D=R/'master-scene-source';(D/'assets').mkdir(parents=True,exist_ok=True)
names={'front':'Front','threequarter':'Quarter','side':'Side','back':'Back'}
scene={'version':1,'name':'Leila_08_Four_Approved_Views','main':'Four_View_Review','strictFonts':False,'colorManagement':{'workingSpace':'sRGB IEC61966-2.1','bitsPerChannel':16,'linearize':False},'assets':[],'comps':[]}
contract={'version':1,'width':1920,'height':1080,'fps':30,'frames':1440,'colorManagement':scene['colorManagement'],'shots':[],'colors':[],'joints':[]};ui={};audit=[]
main={'id':'Four_View_Review','width':1920,'height':1080,'fps':30,'duration':48,'background':[.91,.905,.89],'layers':[],'markers':[]}
for index,(view,prefix)in enumerate(names.items()):
 src=R/view/'scene-source';s=json.loads((src/'scene.json').read_text());m=json.loads((R/view/'art/layers.json').read_text());assets={}
 for a in s['assets']:
  aid=prefix+'_'+a['id'];fn=prefix+'_'+Path(a['path']).name;shutil.copy2(src/a['path'],D/'assets'/fn);assets[a['id']]=aid;scene['assets'].append({'id':aid,'path':'assets/'+fn})
 cmap={'Leila_Motion_Test':prefix+'_Motion','Leila_Rig':prefix+'_Rig'}
 for original in s['comps']:
  c=copy.deepcopy(original);c['id']=cmap[c['id']]
  for l in c['layers']:
   if l['type']=='footage':l['source']=assets[l['source']]
  scene['comps'].append(c);ui[c['id']]={'view':view,'groups':{l['name']:l['group']for l in m['layers']}}
  for n,b in m['bones'].items():contract['joints'].append({'comp':c['id'],'layer':'CTRL_'+n,'parent':'CTRL_'+b['parent']if b['parent']else'Root','pivot':[0,0],'minRotation':-130,'maxRotation':130,'allowMirror':False,'allowNonUniformScale':False})
 cid=prefix+'_Motion';lid=prefix+'_Shot';start=index*12;main['layers'].append({'id':lid,'name':prefix+' / 12s editable rig test','type':'precomp','source':cid,'start':start,'in':start,'out':start+12,'properties':{'anchor':{'value':[960,540]},'position':{'value':[960,540]}}});main['markers'].append({'time':start,'text':view+' approved model angle; native execution not yet verified'})
 contract['shots'].append({'id':prefix,'comp':cid,'layer':lid,'inFrame':index*360,'outFrame':(index+1)*360,'reference':'Approved model sheet: '+view+'. Same v6 layer ownership and wardrobe technique; projected pivot/occlusion adaptations.','reviewFrames':[index*360+f for f in [0,20,40,75,105,135,165,205,245,260,290,359]]})
 poses=json.loads((R/view/'authored-poses.json').read_text());pel=m['bones']['Pelvis']['pivot']
 for f,p in enumerate(poses['poses']):
  for side in ['L','R']:
   if p['contact'][side]:
    v=p['targets'][side];audit.append({'comp':cid,'frame':f,'side':side,'expected':[960+(v[0]-pel[0])*.48,650+(v[1]-pel[1])*.48]})
scene['comps'].append(main);(D/'scene.json').write_text(json.dumps(scene,indent=2)+'\n');(D/'production.json').write_text(json.dumps(contract,indent=2)+'\n')
out=R/'After-Effects';subprocess.run(['python','/workspace/skills/editable-after-effects/scripts/generate.py',str(D/'scene.json'),'--production',str(D/'production.json'),'--out',str(out)],check=True)
p=out/'build_project.jsx';text=p.read_text();needle='        // Verify important native structure before saving; this is not a visual/render approval.'
block='''        // Four-view wardrobe extension. Native execution remains unverified.
        var VIEW_UI = '''+json.dumps(ui)+''';
        var GROUPS = ['Dress','Blouse','Socks','Shoes','Body','Hair','Head','Face','Glasses'];
        for(i=0;i<SCENE.comps.length;i++) {
            c=SCENE.comps[i];var conf=VIEW_UI[c.id];if(!conf)continue;
            var wardrobe=layers[c.id].Wardrobe;var parade=wardrobe.property('ADBE Effect Parade');
            for(var gi=0;gi<GROUPS.length;gi++) {
                if(!parade.canAddProperty('ADBE Checkbox Control'))fail('Checkbox control unavailable');
                var control=parade.addProperty('ADBE Checkbox Control');control.name='Show_'+GROUPS[gi];control.property(1).setValue(1);
            }
            for(j=0;j<c.layers.length;j++) {
                l=c.layers[j];if(l.type!=='footage')continue;var grp=conf.groups[l.id];if(!grp)continue;
                var opacity=layers[c.id][l.id].property('ADBE Transform Group').property('ADBE Opacity');
                opacity.expression='value * thisComp.layer("CTRL_Wardrobe").effect("Show_'+grp+'")(1)';
                if(l.id==='Blouse_SidePanels' && conf.view==='front')opacity.expression+=' * (1 - thisComp.layer("Dress / Dress_Bib_Straps").transform.opacity/100)';
                opacity.valueAtTime(0,false);if(opacity.expressionError)fail('Wardrobe expression failed: '+c.id+'/'+l.id+' '+opacity.expressionError);
            }
        }
'''
assert needle in text;p.write_text(text.replace(needle,block+needle))
auditjsx='''// Run inside After Effects only, after building and saving the project.
(function(){
 var targets='''+json.dumps(audit)+''';var comps={},probe=null,maxError=0;
 try {
  if(!app.project||!app.project.file)throw Error('Build and save the AEP first.');
  for(var i=1;i<=app.project.numItems;i++){var it=app.project.item(i);if(it instanceof CompItem)comps[it.name]=it;}
  for(i=0;i<targets.length;i++){
   var sm=targets[i],comp=comps[sm.comp];if(!comp)throw Error('Missing '+sm.comp);
   if(!probe||probe.containingComp!==comp){if(probe)probe.remove();probe=comp.layers.addNull();probe.name='TEMP_NATIVE_CONTACT_PROBE';}
   var prop=probe.property('ADBE Transform Group').property('ADBE Position');prop.expression='thisComp.layer("CTRL_Foot_'+sm.side+'").toComp([0,0])';
   var val=prop.valueAtTime(sm.frame/30,false);if(prop.expressionError)throw Error(prop.expressionError);
   var dx=val[0]-sm.expected[0],dy=val[1]-sm.expected[1],err=Math.sqrt(dx*dx+dy*dy);if(err>maxError)maxError=err;
  }
  if(probe){probe.remove();probe=null;}if(maxError>.75)throw Error('Contact transform drift '+maxError);
  var f=new File(app.project.file.parent.fsName+'/native-four-view-audit-'+(new Date().getTime())+'.txt');f.encoding='UTF-8';if(!f.open('w'))throw Error('Cannot write audit');
  f.write('Application=Adobe After Effects\\nVersion='+app.version+'\\nNativeContactSamples='+targets.length+'\\nMaxContactErrorPx='+maxError+'\\nNativeRender=not_run\\nVisualAndEditabilityApproval=pending');f.close();alert('Native contact transforms passed. Visual review and native rendering remain required.');
 }catch(e){if(probe)probe.remove();alert('Native audit FAILED: '+e.toString());}
}());
'''
(out/'audit_native_project.jsx').write_text(auditjsx)
files={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest()for p in out.rglob('*')if p.is_file()and p.name!='manifest.json'};(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
print('Master source, 8 editable view comps + review timeline, and native audit builder ready; AE execution pending.')
