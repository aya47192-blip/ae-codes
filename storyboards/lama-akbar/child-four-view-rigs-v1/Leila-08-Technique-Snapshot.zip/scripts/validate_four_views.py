from pathlib import Path
import json,hashlib,sys,copy
import numpy as np
from PIL import Image,ImageDraw
from scipy import ndimage
from psd_tools import PSDImage
R=Path('/workspace/output/lama-child-four-view-rigs-v1');yy,xx=np.indices((1800,1200));allq={}
freeze=json.loads((R/'art-freeze-manifest.json').read_text())
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in freeze.items()),'Art changed after freeze'
renderer=Path('/workspace/work/animate_four_view.py').read_text();prefix=renderer[:renderer.index('# Measure actual FK ankle positions')];prefix=prefix[:prefix.index("if '--review-only' in sys.argv:")]
for view in ['front','threequarter','side','back']:
 V=R/view;A=V/'art';P=V/'proof';m=json.loads((A/'layers.json').read_text());layers=m['layers'];q={'view':view,'layers':len(layers),'bones':len(m['bones']),'anatomical_occurrences':{}}
 assert len({l['name']for l in layers})==len(layers)
 masks={}
 for l in layers:
  im=Image.open(A/l['png']).convert('RGBA');a=np.array(im);o=np.zeros((1800,1200),bool);x,y=l['x'],l['y'];h,w=a.shape[:2];o[y:y+h,x:x+w]=a[:,:,3]>240;masks[l['name']]=o
 for side in ['L','R']:
  for part in ['UpperArm','Forearm','Hand','Thigh','Shin','BareFoot']:
   name='Skin_'+part+'_'+side;q['anatomical_occurrences'][name]=sum(l['name']==name for l in layers);assert q['anatomical_occurrences'][name]==1
  for cloth,skin in [('Blouse_UpperSleeve','Skin_UpperArm'),('Blouse_ForeSleeve','Skin_Forearm'),('Sock_Calf','Skin_Shin'),('Sock_Foot','Skin_BareFoot'),('Shoe','Skin_BareFoot')]:
   assert next(l for l in layers if l['name']==cloth+'_'+side)['bone']==next(l for l in layers if l['name']==skin+'_'+side)['bone']
 q['wardrobe_uses_corresponding_anatomical_bones']=True
 q['no_active_whole_body_backdrop']=not any('reference'in l['name'].lower()or'full_body'in l['name'].lower()for l in layers);assert q['no_active_whole_body_backdrop']
 q['blouse_front_side_duplicate_pixels']=int((masks['Blouse_Torso']&masks['Blouse_SidePanels']).sum());assert q['blouse_front_side_duplicate_pixels']==0
 # Real PSD, independently read; check ordering, RLE channel compression and
 # actual native visibility exports rather than trusting layer counts alone.
 psd=PSDImage.open(V/('Leila-08-'+view+'.psd'));leaves=[l for l in psd.descendants()if not l.is_group()];assert psd.size==(1200,1800)
 assert [l.name for l in reversed(leaves)]==[l['name']for l in layers],view+' PSD order'
 assert all(int(ch.compression)==1 for l in leaves for ch in l._channels)
 q['psd_reader']='psd-tools';q['rle_verified']=True;q['native_psd_export_and_reopen']='GIMP'
 native=np.array(Image.open(P/'native-normal.png').convert('RGBA')).astype(int);expected=np.array(Image.open(P/'normal.png').convert('RGBA')).astype(int);q['native_composite_mae_8bit']=float(abs(native-expected).mean());assert q['native_composite_mae_8bit']<1
 q['hide_features']={}
 for feature,case in [('Eye_R'if'Eye_R'in masks else'Eye_L','no_eye_R'),('Glasses_Frame','no_glasses')]:
  if feature not in masks:continue
  core=ndimage.binary_erosion(masks[feature],iterations=3)
  if feature=='Glasses_Frame':core&=ndimage.binary_erosion(masks['Head_Skin'],iterations=3)
  a=np.array(Image.open(P/('native-'+case+'.png')).convert('RGBA'));op=int((a[:,:,3][core]>=250).sum());n=int(core.sum());q['hide_features'][feature]={'tested_core_pixels':n,'opaque_underpaint_pixels':op};assert op==n,(view,feature,'underpaint holes',n-op)
 a=np.array(Image.open(P/'native-no_footwear.png').convert('RGBA'));b=np.array(Image.open(P/'native-body_barefoot.png').convert('RGBA'));q['footwear_off_matches_bare_body']=bool(np.array_equal(a[yy>1450],b[yy>1450]));assert q['footwear_off_matches_bare_body']
 sock_in_shoe=0
 for l in layers:
  if l['group']!='Shoes':continue
  a=np.array(Image.open(A/l['png']).convert('RGBA'));r,g,b=a[:,:,:3].transpose(2,0,1).astype(int);sock_in_shoe+=int(((r-g<28)&(g>185)&(b>155)&(a[:,:,3]>240)).sum())
 q['sock_like_pixels_baked_in_shoes']=sock_in_shoe;assert sock_in_shoe==0
 # View-specific local ownership tests. In a strict side projection an old
 # near-hand footprint may be covered by the real far hand/body; do not turn
 # an empty test core into a spurious pass.
 saved=sys.argv;sys.argv=['ownership_probe',str(V)];ns={'__name__':'ownership_probe'};exec(compile(prefix,'animate_four_view.py','exec'),ns);sys.argv=saved;render=ns['render'];M=ns['M'];original=M['layers']
 def isolated(names,f,pose=None):
  M['layers']=[l for l in original if l['name']in names]
  try:return np.array(render(f,body_only=True,override_pose=pose))[:,:,3]
  finally:M['layers']=original
 hand=isolated(['Skin_Hand_L'],135);others=isolated([l['name']for l in original if l['group']=='Body'and l['name']!='Skin_Hand_L'],135);core=ndimage.binary_erosion(hand>245,iterations=3)&(others<20);moved=np.array(render(165,body_only=True))[:,:,3];n=int(core.sum());remaining=int((moved[core]>30).sum())
 q['vacated_near_hand']={'core_pixels':n,'remaining_pixels':remaining,'status':'passed'if n>50 and remaining==0 else'not_applicable_due_to_projection'if n<=50 else'failed'}
 assert n<=50 or remaining==0,(view,'stationary hand',remaining)
 probe=copy.deepcopy(ns['poses'][135])
 for side in ['L','R']:probe['angles']['Thigh_'+side]=70;probe['angles']['Shin_'+side]=-20;probe['angles']['Foot_'+side]=-50
 old=isolated(['Skin_Shin_L','Skin_Shin_R'],135);core=ndimage.binary_erosion(old>245,iterations=3)&(np.indices(old.shape)[0]>800)&(np.indices(old.shape)[0]<915);lift=np.array(render(135,body_only=True,override_pose=probe))[:,:,3];remaining=int((lift[core]>30).sum());q['both_legs_vacated']={'core_pixels':int(core.sum()),'remaining_pixels':remaining};assert remaining==0,(view,'stationary shin',remaining)
 render(135,body_only=True,override_pose=probe).save(P/'both-leg-ownership-probe.png')
 q['local_fk_contact']=json.loads((V/'surrogate-motion-qc.json').read_text());assert q['local_fk_contact']['max_planted_foot_drift_comp_pixels']<.75
 q['native_photoshop']='not executed';q['native_after_effects']='not available';q['production_approval']='pending native application/visual/editability checks; local diagnostic only';(V/'verification.json').write_text(json.dumps(q,indent=2)+'\n');allq[view]=q;print('VERIFIED',view,flush=True)
(R/'verification.json').write_text(json.dumps(allq,indent=2)+'\n')
# Native hide/show sheets; transparent checkerboard is only a proof backdrop.
for view in allq:
 P=R/view/'proof';out=Image.new('RGB',(1800,1200),'#ddd');d=ImageDraw.Draw(out)
 for i,(case,label)in enumerate([('normal','Clothed'),('no_dress','Dress off / full blouse'),('body_barefoot','Basic top + shorts / barefoot'),('no_socks','Socks off'),('no_shoes','Shoes off'),('no_footwear','All footwear off')]):
  x,y=(i%3)*600,(i//3)*600;im=Image.open(P/('native-'+case+'.png')).convert('RGBA');im.thumbnail((580,550));out.paste(im,(x+(600-im.width)//2,y+35),im);d.text((x+12,y+10),view+' / '+label,fill='black')
 out.save(P/'wardrobe-proof.jpg',quality=93)
print('All four independent PSD and local ownership checks completed.')
