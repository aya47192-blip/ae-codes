from pathlib import Path
import sys,json
import numpy as np
from PIL import Image
from scipy import ndimage
sys.path.insert(0,'/workspace/work')
from build_four_view_art import ROOT,S,CFG,W,H,xx,yy,fit,mask,clean,heads,polygon,ellipse
BOX={'threequarter':(426,95,816,565),'side':(488,95,818,565)}
NECK={'threequarter':[(580,486),(668,489),(678,574),(579,574)],'side':[(583,482),(668,482),(665,565),(570,565)]}
def full(A,l):
 out=Image.new('RGBA',(W,H));out.alpha_composite(Image.open(A/l['png']).convert('RGBA'),(l['x'],l['y']));return out
for view in ['threequarter','side']:
 V=ROOT/view;A=V/'art';m=json.loads((A/'layers.json').read_text());source=Image.open(A/'reference-cutout.png').convert('RGBA');base=clean(Image.open(S['base-'+view]).resize((W,H),Image.Resampling.LANCZOS));a=np.array(source);r,g,b=a[:,:,:3].transpose(2,0,1).astype(int);alpha=a[:,:,3]>230
 feat=np.zeros((H,W),bool);gl=np.zeros((H,W),bool);eye=np.zeros((H,W),bool)
 for l in m['layers']:
  if l['group']not in ['Face','Glasses']:continue
  q=np.array(full(A,l))[:,:,3]>0;feat|=q
  if l['group']=='Glasses':gl|=q
  if l['name'].startswith('Eye_'):eye|=ndimage.binary_dilation(ndimage.binary_erosion(q,iterations=3),iterations=2)
 c=CFG[view];ex,ey,rx,ry=c['ear'];ear=((xx-ex)/rx)**2+((yy-ey)/ry)**2<1;neck=polygon(NECK[view]);face_roi=ndimage.binary_dilation(polygon(c['face'])|ear,iterations=22)&(yy<515)
 warm=face_roi&alpha&(r>200)&(g>110)&(b>80)&(r-g>42)&(g-b>15)&~ndimage.binary_dilation(gl,iterations=1)
 lab,n=ndimage.label(warm);sizes=np.bincount(lab.ravel());keep=sizes>300;keep[0]=False;warm&=keep[lab]
 shape=ndimage.binary_fill_holes(ndimage.binary_closing(warm,iterations=3));shape=ndimage.binary_dilation(shape,iterations=1)|eye
 if view=='threequarter':
  optics=ellipse((563,275,715,405))|ellipse((725,271,840,403));optics|=polygon([(478,312),(856,288),(856,335),(478,344)]);inner=polygon([(470,375),(505,370),(528,394),(514,423),(480,418),(465,400)]);jaw=(yy>450)&(xx>560)&(xx<813);earfront=ear&(xx>525)
 else:
  optics=ellipse((790,269,837,411))|polygon([(632,311),(802,301),(803,337),(632,344)]);inner=polygon([(581,375),(610,368),(636,384),(639,411),(619,426),(590,419),(579,398)]);jaw=(yy>430)&(xx>660)&(xx<839);earfront=ear&(xx>638)
 brown=(r<235)&(g<175)&(b<150)
 material=alpha&(yy<552)&~shape&~feat&~optics&((yy<490)|((r<190)&(g<145)&(b<130)))
 curls=alpha&(r<245)&(g<185)&(b<160)&~ndimage.binary_dilation(feat,iterations=2)&~optics&~inner&((yy<300)|earfront)
 material|=curls;material&=~(jaw&ndimage.binary_dilation(shape,iterations=6));featureguard=polygon(c['face'])&(xx>(570 if view=='threequarter'else 710))&(yy>255)&(yy<320);material&=~featureguard
 # The no-glasses source supplies hair behind lens/temple areas; never copy
 # skin or a flattened jaw silhouette into the hair underpainting.
 ba=np.array(base);br,bg,bb=ba[:,:,:3].transpose(2,0,1).astype(int);underhair=optics&~shape&(yy<552)&(br<235)&(bg<175)&(bb<145)&(ba[:,:,3]>230)
 underhair&=~featureguard;hair=mask(base,underhair);hair.alpha_composite(mask(source,material))
 idx=0 if view=='threequarter'else 1;hw,hh=heads.size;t=clean(heads.crop((idx*hw//3,0,(idx+1)*hw//3,hh)),1,True);t=t.crop(t.getbbox());head=fit(t,BOX[view]);cutoff=620 if view=='threequarter'else 660
 has=shape.any(axis=1);right=np.where(shape,np.arange(W)[None,:],-1).max(axis=1);right=np.interp(np.arange(H),np.where(has)[0],right[has]);rowfill=xx<=right[:,None]+2
 head=mask(head,((yy<500)|neck)&((xx<cutoff)|(yy<335)|rowfill))
 tw,th=t.size;patch=t.crop((int(tw*.40),int(th*.22),int(tw*.60),int(th*.36))).convert('RGB').convert('RGBA');bounds=Image.fromarray((shape*255).astype('uint8')).getbbox();fill=fit(patch,bounds);head.alpha_composite(mask(fill,(shape|polygon(c['face']))&(np.array(head)[:,:,3]<250)))
 copy=warm&~ndimage.binary_dilation(feat,iterations=3)&~optics&~material
 # Keep the approved skin color/blush, not any flattened facial feature ink.
 nx0,ny0,nx1,ny1=c['nose'];mx0,my0,mx1,my1=c['mouth'];copy&=~((xx>=nx0-15)&(xx<=nx1+18)&(yy>=ny0-12)&(yy<=ny1+12));copy&=~((xx>=mx0-15)&(xx<=mx1+25)&(yy>=my0-10)&(yy<=my1+10))
 dots=shape&~warm&~feat&~optics&~material&(yy>360)&(yy<485)&(xx>(565 if view=='threequarter'else 680));lab,n=ndimage.label(dots);sizes=np.bincount(lab.ravel());small=sizes<25;small[0]=False;copy|=small[lab]
 head.alpha_composite(mask(source,copy));head.alpha_composite(mask(source,inner&~feat))
 boundary=ndimage.binary_dilation(shape,iterations=3)&~ndimage.binary_erosion(shape,iterations=3)&jaw&alpha&~material&~feat&~optics&(r<235)&(g<180);head.alpha_composite(mask(source,boundary))
 for name,im in [('Head_Skin',head),('Hair_Paint',hair)]:
  l=next(l for l in m['layers']if l['name']==name);box=im.getbbox();fn='assets/complete-'+name+'.png';im.crop(box).save(A/fn);l.update(png=fn,x=box[0],y=box[1])
 (A/'layers.json').write_text(json.dumps(m,indent=2)+'\n')
 cases={'normal':(),'no_dress':('Dress',),'body_barefoot':('Dress','Blouse','Socks','Shoes'),'no_socks':('Socks',),'no_shoes':('Shoes',),'no_footwear':('Socks','Shoes'),'no_eye_R':('Eye_R'if view=='threequarter'else'Eye_L',),'no_glasses':('Glasses',),'blank_face':('Face','Glasses'),'no_hair':('Hair',),'bare_head':('Hair','Face','Glasses')}
 for case,hidden in cases.items():
  out=Image.new('RGBA',(W,H))
  for l in reversed(m['layers']):
   if l['name']in hidden or l['group']in hidden:continue
   out.alpha_composite(Image.open(A/l['png']).convert('RGBA'),(l['x'],l['y']))
  out.save(V/'proof'/(case+'.png'))
 print('Final projected head material ownership',view,flush=True)
