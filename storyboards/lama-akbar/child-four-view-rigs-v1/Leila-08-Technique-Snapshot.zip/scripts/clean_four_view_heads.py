from pathlib import Path
import json,sys
import numpy as np
from PIL import Image
from scipy import ndimage
sys.path.insert(0,'/workspace/work')
from build_four_view_art import ROOT,S,CFG,W,H,xx,yy,fit,mask,clean,heads,polygon
FRONT='/workspace/generated_images/exec-7f9c8514-4e4a-498d-9824-35816ec7f455.png'
BOX={'front':(346,135,869,610),'threequarter':(426,95,816,565),'side':(488,95,818,565),'back':(390,90,809,570)}
NECK={'front':[(574,537),(655,537),(659,585),(574,585)],'threequarter':[(580,486),(668,489),(678,574),(579,574)],'side':[(583,482),(668,482),(665,565),(570,565)],'back':[(559,493),(641,493),(646,536),(557,536)]}
def plate(A,l):
 o=Image.new('RGBA',(W,H));o.alpha_composite(Image.open(A/l['png']).convert('RGBA'),(l['x'],l['y']));return o
def biggest(v):
 lab,n=ndimage.label(v);sz=np.bincount(lab.ravel());sz[0]=0;return lab==sz.argmax()
for view in ['front','threequarter','side','back']:
 V=ROOT/view;A=V/'art';m=json.loads((A/'layers.json').read_text());h=next(l for l in m['layers']if l['name']=='Head_Skin');hair=next(l for l in m['layers']if l['name']=='Hair_Paint');ref=V/'reference';ref.mkdir(exist_ok=True)
 if not(ref/'head-before-scalp-cleanup.png').exists():plate(A,h).save(ref/'head-before-scalp-cleanup.png');plate(A,hair).save(ref/'hair-before-scalp-cleanup.png')
 hairpaint=Image.open(ref/'hair-before-scalp-cleanup.png').convert('RGBA')
 if view=='front':
  raw=clean(Image.open(FRONT),1,True);template=raw.crop(raw.getbbox());source=Image.open(ref/'head-before-scalp-cleanup.png').convert('RGBA');original=source.copy();scope=(yy>300)&(yy<552)
 else:
  i=['threequarter','side','back'].index(view);hw,hh=heads.size;raw=clean(heads.crop((i*hw//3,0,(i+1)*hw//3,hh)),1,True);template=raw.crop(raw.getbbox());source=clean(Image.open(S['base-'+view]).convert('RGBA').resize((W,H),Image.Resampling.LANCZOS));original=Image.open(A/'reference-cutout.png').convert('RGBA');scope=(yy>170)&(yy<511)
 under=fit(template,BOX[view]);neck=polygon(NECK[view]);limit=550 if view=='front'else 515 if view=='back'else 500;under=mask(under,(yy<limit)|neck)
 a=np.array(source);r,g,b=a[:,:,:3].transpose(2,0,1).astype(int);oa=np.array(original);rr,gg,bb=oa[:,:,:3].transpose(2,0,1).astype(int)
 if view!='back':
  warm=scope&(a[:,:,3]>230)&(r>200)&(g>110)&(b>80)&(r-g>25)&(g-b>15)
  main=biggest(warm);shape=ndimage.binary_fill_holes(ndimage.binary_closing(main,iterations=2));holes=shape&~warm;lab,n=ndimage.label(holes);sizes=np.bincount(lab.ravel());small=sizes<=50;small[0]=False;copy=main|small[lab]
  if view!='front':
   cutoff=620 if view=='threequarter'else 660;under=mask(under,(xx<cutoff)|(yy<260)|shape|neck)
   x0,y0,x1,y1=CFG[view]['nose'];copy&=~((xx>=x0-18)&(xx<=x1+18)&(yy>=y0-12)&(yy<=y1+12))
  # Do not bake any of the original hair texture into the new face.
  copy&=np.array(hairpaint)[:,:,3]<20
  if view=='front':copy&=(xx>402)&(xx<814)
  tw,th=template.size;swatch=template.crop((int(tw*.40),int(th*.22),int(tw*.60),int(th*.36))).convert('RGB').convert('RGBA');bounds=Image.fromarray((shape*255).astype('uint8')).getbbox()
  if bounds:
   # Fill alpha gaps under ALL facial features; keep the complete scalp shape.
   fill=fit(swatch,bounds);under.alpha_composite(mask(fill,shape&(np.array(under)[:,:,3]<250)))
  under.alpha_composite(mask(source,copy))
  if view!='front':
   ex,ey,rx,ry=CFG[view]['ear'];ear=((xx-ex)/rx)**2+((yy-ey)/ry)**2<1
   inner=polygon([(470,375),(505,370),(528,394),(514,423),(480,418),(465,400)])if view=='threequarter'else polygon([(581,375),(610,368),(636,384),(639,411),(619,426),(590,419),(579,398)])
   es=ear&(oa[:,:,3]>230)&(rr>210)&(gg>145)&(bb>105)&(rr-gg>28)&(rr-gg<85);es=ndimage.binary_fill_holes(biggest(es))&ear
   under.alpha_composite(mask(original,inner))
   fringe=ear&~ndimage.binary_dilation(es|inner,iterations=1)&(rr<230)&(gg<170)&(bb<145)&(oa[:,:,3]>230);hairpaint.alpha_composite(mask(original,fringe))
  else:
   dark=(a[:,:,3]>230)&(r<190)&(g<140)&(b<110)&((yy<300)|((yy>350)&((xx<430)|(xx>790))))
   hairpaint.alpha_composite(mask(source,dark));under.alpha_composite(mask(original,neck))
 for layer,im,name in [(h,under,'Head_Skin'),(hair,hairpaint,'Hair_Paint')]:
  box=im.getbbox();fn='assets/complete-'+name+'.png';im.crop(box).save(A/fn);layer.update(png=fn,x=box[0],y=box[1])
 m['head_underpainting']='Complete generated bald skull and neck, connected clear-skin plate; no copied dark hair in scalp. Features remain independent.';(A/'layers.json').write_text(json.dumps(m,indent=2)+'\n')
 cases={'normal':(),'no_dress':('Dress',),'body_barefoot':('Dress','Blouse','Socks','Shoes'),'no_socks':('Socks',),'no_shoes':('Shoes',),'no_footwear':('Socks','Shoes'),'no_eye_R':('Eye_R'if view in ['front','threequarter']else'Eye_L',),'no_glasses':('Glasses',),'blank_face':('Face','Glasses'),'no_hair':('Hair',),'bare_head':('Hair','Face','Glasses')}
 for case,hidden in cases.items():
  out=Image.new('RGBA',(W,H))
  for l in reversed(m['layers']):
   if l['name']in hidden or l['group']in hidden:continue
   out.alpha_composite(Image.open(A/l['png']).convert('RGBA'),(l['x'],l['y']))
  out.save(V/'proof'/(case+'.png'))
 print('Complete scalp and face',view,flush=True)
