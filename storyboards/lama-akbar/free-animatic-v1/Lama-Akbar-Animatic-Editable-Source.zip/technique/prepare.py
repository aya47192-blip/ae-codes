from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,shutil,hashlib,math
R=Path('/workspace/output/lama-akbar-free-animatic-v1');S=Path('/workspace/output/lama-akbar-storyboard-v2');W=Path('/workspace/work/lama-free-animatic');D=json.loads((S/'storyboard.json').read_text());V=json.loads((S/'preproduction/production-readiness.json').read_text())
BG=(247,241,231);FPS=30;SIZE=1080;CENTER=(540,466);MAXART=880
static={'K04','K08','K09','K10','K12','K17','K18','K19','K22','K25','K26','K27','K28','K29','K34','K35'}
pull={'K06','K11','K15','K20','K24','K30','K33'}
scene={'version':1,'name':'Lama_Akbar_Free_Animatic','main':'Animatic_Clean','strictFonts':False,'colorManagement':{'workingSpace':'sRGB IEC61966-2.1','bitsPerChannel':16,'linearize':False},'assets':[],'comps':[]}
main={'id':'Animatic_Clean','width':SIZE,'height':SIZE,'fps':FPS,'duration':90,'background':[x/255 for x in BG],'layers':[],'markers':[]}
review={'id':'Animatic_Dialogue_Review','width':SIZE,'height':SIZE,'fps':FPS,'duration':90,'background':[x/255 for x in BG],'layers':[],'markers':[{'time':0,'text':'Animatic: still panels + camera + procedural sound. Captions are written dialogue, not spoken audio.'}]}
contract={'version':1,'width':SIZE,'height':SIZE,'fps':FPS,'frames':2700,'colorManagement':scene['colorManagement'],'shots':[],'colors':[],'joints':[]}
plan=[]
def val(x):return {'value':x}
def keys(a,b,t):return {'keys':[{'time':0,'value':a,'ease':'bezier','influence':33.333},{'time':t,'value':b,'ease':'bezier','influence':33.333}]}
for f in D['frames']:
 k=f['id'];src=S/f['image'];dst=R/'assets/art'/(k+'.jpg');shutil.copy2(src,dst);im=Image.open(src).convert('RGB');iw,ih=im.size;artscale=MAXART/max(iw,ih);pic=im.resize((round(iw*artscale),round(ih*artscale)),Image.Resampling.LANCZOS);canvas=Image.new('RGB',(SIZE,SIZE),BG);canvas.paste(pic,(CENTER[0]-pic.width//2,CENTER[1]-pic.height//2));canvas.save(W/'canvases'/(k+'.png'))
 z0,z1=(1,1)if k in static else(1.024,1)if k in pull else(1,1.024);n=f['out_frame']-f['in_frame'];last=(n-1)/FPS
 scene['assets'].append({'id':k+'_Art','path':'assets/art/'+k+'.jpg'})
 c={'id':k+'_Shot','width':SIZE,'height':SIZE,'fps':FPS,'duration':f['duration'],'background':[x/255 for x in BG],'markers':[{'time':0,'text':f['title']+' / '+f['scene']}],'layers':[
 {'id':'Illustration','name':k+' / approved flattened storyboard illustration','type':'footage','source':k+'_Art','parent':'Camera','motionBlur':False,'properties':{'anchor':val([iw/2,ih/2]),'position':val([0,CENTER[1]-540]),'scale':val([100*artscale]*2)}},
 {'id':'Camera','name':'CTRL_Camera_Only_No_Character_Rig','type':'null','properties':{'anchor':val([0,0]),'position':val([540,540]),'scale':val([z0*100]*2)if z0==z1 else keys([z0*100]*2,[z1*100]*2,last)}}]}
 scene['comps'].append(c);main['layers'].append({'id':k,'name':k+' / '+f['title'],'type':'precomp','source':c['id'],'start':f['start_seconds'],'in':f['start_seconds'],'out':f['end_seconds'],'properties':{'anchor':val([540,540]),'position':val([540,540])}})
 main['markers'].append({'time':f['start_seconds'],'text':k+' / '+f['title']})
 contract['shots'].append({'id':k,'comp':c['id'],'layer':k,'inFrame':f['in_frame'],'outFrame':f['out_frame'],'reference':'Approved storyboard v2 '+k+'; no redrawing, no character/limb animation. '+f['visual'],'reviewFrames':[f['in_frame'],(f['in_frame']+f['out_frame'])//2,f['out_frame']-1]})
 plan.append({**f,'z0':z0,'z1':z1,'frames':n,'last_key_seconds':last,'art_source_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'source_size':[iw,ih],'base_fit_scale':artscale,'canvas':str(W/'canvases'/(k+'.png'))})
# Caption rasters are separate optional layers; they do not alter the paintings.
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';reg=ImageFont.truetype(font,34);small=ImageFont.truetype(font,24)
def wrap(s,width):
 out=[];line=''
 for word in s.split():
  t=(line+' '+word).strip()
  if reg.getlength(t,direction='rtl')>width and line:out.append(line);line=word
  else:line=t
 if line:out.append(line)
 return out
captions=[]
for v in V['dialogue_cues']:
 im=Image.new('RGBA',(1000,134));dr=ImageDraw.Draw(im);dr.text((500,3),v['speaker'],font=small,anchor='ma',direction='rtl',language='ar',fill='#7d6557');lines=wrap(v['text'],980);assert len(lines)<=2
 for j,line in enumerate(lines):dr.text((500,37+j*44),line,font=reg,anchor='ma',direction='rtl',language='ar',fill='#263d3c')
 fn='assets/captions/'+v['id']+'.png';im.save(R/fn);scene['assets'].append({'id':v['id']+'_Caption','path':fn});a=round(v['planned_in_seconds']*FPS)/FPS;b=round(v['planned_out_seconds']*FPS)/FPS
 review['layers'].append({'id':v['id'],'name':v['speaker']+' / written dialogue review','type':'footage','source':v['id']+'_Caption','in':a,'out':b,'properties':{'anchor':val([0,0]),'position':val([40,934])}});captions.append({**v,'in':a,'out':b,'png':fn})
for name in ['Ambience','Foley']:
 fn='assets/audio/'+name+'.wav';scene['assets'].append({'id':'Audio_'+name,'path':fn});main['layers'].append({'id':'Audio_'+name,'name':'SFX / '+name+' / procedural temporary sound, no voices','type':'footage','source':'Audio_'+name,'properties':{'position':val([540,540])}})
scene['comps'].append(main);review['layers'].append({'id':'Clean_Timeline','name':'Complete 36-shot clean animatic + SFX','type':'precomp','source':'Animatic_Clean','properties':{'anchor':val([540,540]),'position':val([540,540])}});scene['comps'].append(review)
(R/'scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2)+'\n');(R/'production.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2)+'\n');(R/'camera-and-shot-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n');(R/'dialogue-review-cues.json').write_text(json.dumps(captions,ensure_ascii=False,indent=2)+'\n')
def tc(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
srt='\n\n'.join(f"{i+1}\n{tc(v['in'])} --> {tc(v['out'])}\n{v['speaker']}: {v['text']}"for i,v in enumerate(captions))+'\n';(R/'Dialogue-Review-AR.srt').write_text(srt)
req={'width':SIZE,'height':SIZE,'fps':FPS,'frames':2700,'codec':'h264','pixelFormats':['yuv420p'],'colorPrimaries':'bt709','colorTransfer':'bt709','colorSpace':'bt709','audio':{'required':True,'sampleRate':48000,'channels':2,'matchDuration':True,'toleranceSeconds':.05},'reviewFrames':[30,315,600,855,1215,1365,1575,1770,1995,2070,2325,2580,2670]};(R/'render-requirements.json').write_text(json.dumps(req,indent=2)+'\n')
(R/'production-brief.json').write_text(json.dumps({'version':1,'duration_seconds':90,'width':SIZE,'height':SIZE,'fps':FPS,'frames':2700,'shots':36,'approved_reference':'../lama-akbar-storyboard-v2/storyboard.json','purpose':'User explicitly accepted a no-extra-cost still-panel animatic fallback after video/speech generation was plan-gated.','preserve':'Exact original artwork copied unchanged; fit full panels on paper matte, no limbs cropped, no new characters or drawing.','motion':'Only restrained 0–2.4% camera scale; contact/pose-critical panels held still. No character rig/walk/lip-sync claimed.','sound':'Procedural temporary ambience and foley, no music or spoken voices.','dialogue':'Optional raster captions and SRT from exact approved script, planned windows only.','native_ae':'Builder source only; AE unavailable, not natively executed.','layers':'Each storyboard image is still a flattened illustration. Camera controls, paper background, caption rasters and two sound stems are independently editable; internal characters and scene objects are not separated.','format_note':'Square review preserves whole approved panels; widescreen final layout remains a different future task.'},ensure_ascii=False,indent=2)+'\n')
print('Prepared 36 unchanged paintings, selective camera moves, 11 optional dialogue rasters, 38 native-source comps and locked90s contract')
