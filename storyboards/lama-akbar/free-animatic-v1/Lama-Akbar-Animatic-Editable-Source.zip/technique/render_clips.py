from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,json
R=Path('/workspace/output/lama-akbar-free-animatic-v1');W=Path('/workspace/work/lama-free-animatic');P=json.loads((R/'camera-and-shot-plan.json').read_text())
def render(p):
 k=p['id'];n=p['frames'];t=f'on/{n-1}';ease=f'({t})*({t})*(3-2*({t}))';z=f"{p['z0']}+({p['z1']-p['z0']})*({ease})";vf=f"scale=2160:2160:flags=lanczos,zoompan=z='{z}':x='(iw-iw/zoom)/2':y='(ih-ih/zoom)/2':d={n}:s=1080x1080:fps=30,format=gbrpf32le,zscale=matrixin=gbr:transferin=iec61966-2-1:primariesin=bt709:rangein=full:matrix=bt709:transfer=bt709:primaries=bt709:range=limited,format=yuv420p"
 out=W/'clips'/(k+'.mp4');cmd=['ffmpeg','-y','-v','error','-threads','1','-i',p['canvas'],'-vf',vf,'-frames:v',str(n),'-an','-c:v','libx264','-threads','2','-preset','fast','-crf','23','-maxrate','900k','-bufsize','1800k','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-video_track_timescale','15360',str(out)]
 result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 if result.returncode:raise RuntimeError(k+' '+result.stderr[-3000:])
 print('RENDERED',k,n,'frames',flush=True);return k
if __name__=='__main__':
 import sys
 if '--test' in sys.argv:render(P[0]);raise SystemExit
 with ThreadPoolExecutor(max_workers=3)as pool:
  for f in as_completed([pool.submit(render,p)for p in P]):f.result()
 (W/'concat.txt').write_text(''.join("file '"+str(W/'clips'/(p['id']+'.mp4'))+"'\n"for p in P))
 print('All36 clips rendered,2700 frames',flush=True)
