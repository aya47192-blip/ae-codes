from pathlib import Path
import subprocess,json
R=Path('/workspace/output/lama-akbar-free-animatic-v1');W=Path('/workspace/work/lama-free-animatic')
clean=R/'Lama-Akbar-Animatic-Clean.mp4';review=R/'Lama-Akbar-Animatic-Dialogue-Review.mp4'
cmd=['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(W/'concat.txt'),'-i',str(R/'proof/Local-SFX-Mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','96k','-ar','48000','-ac','2','-t','90','-movflags','+faststart',str(clean)]
subprocess.run(cmd,check=True);print('CLEAN animatic assembled',clean.stat().st_size,flush=True)
cues=json.loads((R/'dialogue-review-cues.json').read_text());cmd=['ffmpeg','-y','-v','error','-threads','2','-i',str(clean)]
for v in cues:cmd+=['-loop','1','-framerate','30','-i',str(R/v['png'])]
filters=[];last='0:v'
for i,v in enumerate(cues,1):
 out='o'+str(i);filters.append(f"[{last}][{i}:v]overlay=40:934:enable='gte(t,{v['in']})*lt(t,{v['out']})':shortest=1[{out}]");last=out
cmd+=['-filter_complex_threads','2','-filter_complex',';'.join(filters),'-map','['+last+']','-map','0:a:0','-c:v','libx264','-threads','3','-preset','fast','-crf','23','-maxrate','900k','-bufsize','1800k','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-c:a','copy','-t','90','-movflags','+faststart',str(review)]
subprocess.run(cmd,check=True);print('DIALOGUE REVIEW assembled',review.stat().st_size,flush=True)
