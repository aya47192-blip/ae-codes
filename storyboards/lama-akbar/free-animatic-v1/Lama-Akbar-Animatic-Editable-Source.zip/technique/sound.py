from pathlib import Path
import numpy as np
from scipy import signal
import wave,json
R=Path('/workspace/output/lama-akbar-free-animatic-v1');SR=48000;N=90*SR;rng=np.random.default_rng(71126);amb=np.zeros(N,np.float64);foley=np.zeros(N,np.float64);events=[]
def noise(n,lo=0,hi=12000):
 x=rng.standard_normal(n)
 if lo and hi:x=signal.sosfilt(signal.butter(2,[lo,hi],btype='bandpass',fs=SR,output='sos'),x)
 elif hi:x=signal.sosfilt(signal.butter(2,hi,fs=SR,output='sos'),x)
 x=x/(np.std(x)+1e-9);return x
def envelope(n,fade=.05):
 y=np.ones(n);a=min(round(fade*SR),n//2)
 if a:y[:a]=np.sin(np.linspace(0,np.pi/2,a))**2;y[-a:]=np.cos(np.linspace(0,np.pi/2,a))**2
 return y
def add(track,x,t,name):
 p=round(t*SR);end=min(N,p+len(x));track[p:end]+=x[:end-p];events.append(dict(event=name,start=t,end=end/SR))
# Gentle room air stays continuous across editorial cuts; no music or fake speech.
add(amb,noise(N,70,1000)*.0022*envelope(N,.8),0,'quiet room air / synthetic placeholder')
for a,b,level in [(15,21,.004),(21,27,.003),(42,49,.0028),(68,90,.0025)]:
 n=round((b-a)*SR);add(amb,noise(n,120,1700)*level*envelope(n,.4),a,'soft air / location transition')
# Rain during the university night, easing toward dawn.
n=round(15*SR);rain=noise(n,700,11000)*.006;rain*=np.linspace(1,.18,n)*envelope(n,.6);add(amb,rain,27,'quiet night rain fades toward dawn')
# Sparse non-melodic bird chirps, short filtered frequency sweeps.
for t in [1.2,5.7,9.3,14.2,69.8,74.8,80.8,88.4]:
 dur=.16+rng.random()*.09;tt=np.arange(round(dur*SR))/SR;f0=rng.uniform(2300,3500);f1=f0+rng.uniform(400,1000);x=signal.chirp(tt,f0,dur,f1,method='quadratic')*.0028*np.sin(np.pi*np.linspace(0,1,len(tt)))**2;add(amb,x,t,'distant synthetic bird chirp')
def tap(t,amp=.045,low=True,name='soft contact'):
 dur=.15;tt=np.arange(round(dur*SR))/SR;x=noise(len(tt),50 if low else 500,900 if low else 5500)*np.exp(-tt/(.024 if low else .014))*amp;add(foley,x,t,name)
def paper(t,dur=.35,amp=.012,name='paper movement'):
 n=round(dur*SR);tt=np.arange(n)/SR;x=noise(n,900,9000);shape=np.sin(np.pi*np.linspace(0,1,n))**2*(.35+.65*np.sin(2*np.pi*13*tt)**2);add(foley,x*shape*amp,t,name)
def pencil(t,dur):
 n=round(dur*SR);tt=np.arange(n)/SR;x=noise(n,1700,10000);pulse=(.35+.65*np.sin(2*np.pi*7.7*tt+np.sin(tt*3))**2)*envelope(n,.035);add(foley,x*pulse*.005,t,'pencil scratch / synthetic placeholder')
for a,b in [(.5,2.3),(3.15,4.5),(27.3,28.9),(34.2,35.0),(36.4,37.0),(83.3,84.8),(85.6,86.7),(87.4,89.4)]:pencil(a,b-a)
paper(12.9,.3,.017,'notebook closing');paper(14.1,.4,.013,'schoolbag fabric');tap(17.7,.065,True,'notebook lands');paper(21.35,.25,.012,'notebook pickup')
for t in [15.2,15.7,16.2,16.7,25.2,25.65,26.1]:tap(t,.029,True,'illustrative footstep cue, no actual walk animation')
for t in [28.8,30.7,31.3,33.1]:paper(t,.22,.011,'cardboard work')
tap(38.7,.014,False,'pencil roll');tap(38.86,.009,False,'pencil roll settle')
# A restrained phone ring motivates the office age transition.
for a in [42.25,42.75]:
 dur=.27;tt=np.arange(round(dur*SR))/SR;x=(np.sin(2*np.pi*1420*tt)+.45*np.sin(2*np.pi*2180*tt))*.018;x*=np.exp(-tt/1)*envelope(len(tt),.025);add(foley,x,a,'desk phone bell cue')
tap(44.05,.018,False,'phone receiver lift');paper(45.4,.5,.008,'office plans');tap(47.2,.016,True,'phone receiver down');paper(49.3,.5,.008,'drawing paper');pencil(53.1,.4);paper(57.5,.3,.012,'old notebook handled');tap(60.7,.018,True,'notebook closing');tap(62.1,.023,True,'wooden toy contact');paper(64.0,.55,.006,'clothes shift');tap(71.7,.018,True,'wooden train set on table');paper(76.0,.45,.014,'old notebook opening');paper(77.2,.45,.008,'old page turn')
# Chair scrape: non-tonal filtered texture, not music.
n=round(.7*SR);scr=noise(n,150,2500)*.008*envelope(n,.1);add(foley,scr,80.7,'chair slide into sunlight')
# Gentle final falloff, no abrupt chopped tail.
amb[-round(.65*SR):]*=np.linspace(1,0,round(.65*SR));foley[-round(.35*SR):]*=np.linspace(1,0,round(.35*SR));mix=amb+foley;peak=float(np.max(np.abs(mix)));gain=min(1,.80/max(peak,1e-9));amb*=gain;foley*=gain;mix*=gain
for name,x in [('Ambience',amb),('Foley',foley)]:
 with wave.open(str(R/'assets/audio'/(name+'.wav')),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(24000);w.writeframes((np.clip(signal.resample_poly(x,1,2),-1,1)*32767).astype('<i2').tobytes())
st=np.stack([mix,mix],axis=1)
with wave.open(str(R/'proof/Local-SFX-Mix.wav'),'wb')as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((st*32767).astype('<i2').tobytes())
q={'duration':90,'sample_rate':SR,'channels_mix':2,'stems':2,'stem_sample_rate':24000,'origin':'Deterministic locally synthesized sound placeholders, not field recordings or AI speech','spoken_dialogue':False,'music':False,'peak':float(np.max(np.abs(mix))),'rms':float(np.sqrt(np.mean(mix**2))),'event_count':len(events),'events':events};(R/'sound-design.json').write_text(json.dumps(q,indent=2)+'\n');print('Prepared temporary ambience and foley:',q['event_count'],'events; peak',q['peak'])
