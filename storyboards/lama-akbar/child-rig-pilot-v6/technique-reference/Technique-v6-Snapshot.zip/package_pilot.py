from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path('/workspace/output/lama-akbar-child-rig-pilot-v6');m=json.loads((R/'art/layers.json').read_text());q=json.loads((R/'verification.json').read_text());mq=q['motion'];decode=json.loads((R/'proof/render-decode-final.json').read_text());assert decode['passed'];assert q['no_static_duplicate_anatomy_probe'].startswith('passed');assert q['stocking_like_pixels_baked_in_shoes']==0
q['decode_report']='proof/render-decode-final.json';q['native_project_delivered']=False;q['scope']='one child pilot, not approved for character-wide rollout';(R/'verification.json').write_text(json.dumps(q,indent=2)+'\n')
# Replace obsolete first-draft coverage numbers with final physical-part and motion evidence.
owner={'physical_part_occurrences':q['anatomical_occurrences'],'no_active_whole_body_backdrop':q['no_active_whole_body_reference'],'skin_overlap_outside_joint_regions_pixels':q['skin_to_skin_overlap_outside_joints_pixels'],'garment_torso_sleeve_projection_overlap_pixels':q['projected_sleeve_torso_overlap_pixels'],'projection_note':'Complete sleeves may occlude torso fabric at rest. This is not a second sleeve printed on torso; vacated-region renders test that distinction.','vacated_hand_remaining_pixels':mq['vacated_left_hand_remaining_pixels'],'vacated_sleeve_remaining_pixels':mq['vacated_left_sleeve_remaining_pixels'],'vacated_shin_remaining_pixels':mq['vacated_left_shin_remaining_pixels'],'foot_contact_error_pixels_local':mq['max_planted_foot_drift_comp_pixels'],'native_after_effects':'not available, not run','rollout_approved':False}
(R/'source-ownership-qc.json').write_text(json.dumps(owner,indent=2)+'\n')
# Real native AEP is intentionally absent until AE can execute the builder.
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (R/'after-effects').rglob('*')if p.is_file()}
(R/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def evidence(path):
 p=R/path;return{'path':path,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
checks={n:{'status':'pending','reason':'After Effects native execution and/or native visual approval unavailable.'}for n in ['source_contract','native_structure','rig_visual','storyboard_visual','rendered_color','render_decode','editability','audio_sync']}
checks['source_contract']={'status':'passed','review':'Frame contract and asset/bone hierarchy validated by the provided generator; wardrobe extension parsed only.','evidence':[evidence('after-effects/validation.json')]if(R/'after-effects/validation.json').exists()else[evidence('after-effects/production.json')]}
checks['render_decode']={'status':'passed','review':'Only the local surrogate H264 diagnostic was decoded, not an AE production render.','evidence':[evidence('proof/render-decode-final.json')]}
checks['audio_sync']={'status':'not_applicable','reason':'No audio requested or delivered'}
final={'version':1,'artifacts':{'source_manifest':evidence('source-manifest.json'),'video':evidence('proof/local-rig-diagnostic-bt709.mp4')},'checks':checks,'delivery_status':'DRAFT BUILDER / STATIC PSD + LOCAL DIAGNOSTIC; NO NATIVE AEP'}
(R/'final-evidence.json').write_text(json.dumps(final,indent=2)+'\n')
shutil.copyfile(R/'proof/local-rig-diagnostic-bt709.mp4',R/'Leila-08-Local-Rig-Test-v6.mp4')
for original,name in [('wardrobe-proof.jpg','Leila-08-Wardrobe-Proof-v6.jpg'),('face-proof.jpg','Leila-08-Face-Proof-v6.jpg'),('motion-contact.jpg','Leila-08-Motion-Contact-v6.jpg')]:shutil.copyfile(R/'proof'/original,R/name)
def add(z,p,name):
 info=zipfile.ZipInfo(name,(2026,11,5,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=8)
with zipfile.ZipFile(R/'Leila-08-Photoshop-Pilot-v6.zip','w')as z:
 for fn in ['Leila-08-Single-Owner-Pilot-v6.psd','README-AR.txt','verification.json','native-psd-qc.json','source-ownership-qc.json','Leila-08-Wardrobe-Proof-v6.jpg','Leila-08-Face-Proof-v6.jpg']:add(z,R/fn,fn)
with zipfile.ZipFile(R/'Leila-08-AE-Builder-v6.zip','w')as z:
 for p in sorted((R/'after-effects').rglob('*')):
  if p.is_file():add(z,p,str(p.relative_to(R/'after-effects')))
 add(z,R/'README-AR.txt','README-AR.txt');add(z,R/'authored-poses.json','authored-poses.json');add(z,R/'verification.json','verification.json')
with zipfile.ZipFile(R/'Leila-08-Layer-Sources-v6.zip','w')as z:
 add(z,R/'art/layers.json','layers.json')
 for l in m['layers']:add(z,R/'art'/l['png'],l['png'])
 add(z,R/'README-AR.txt','README-AR.txt')
base='https://raw.githubusercontent.com/aya47192-blip/ae-codes/refs/heads/storyboard/lama-curly-layered-psd-v1/storyboards/lama-akbar/child-rig-pilot-v6/'
readme='''# عينة الطفلة — v6

**عينة واحدة للمراجعة، وليست اعتمادًا احترافيًا نهائيًا أو ملف AEP محفوظًا.** After Effects غير موجود هنا؛ الفيديو اختبار حركة محلي، واختبارات PSD أُجريت في GIMP ثم قُرئت ببرنامج مستقل.

- [فيديو الاختبار المحلي — 12 ثانية]('''+base+'''Leila-08-Local-Rig-Test-v6.mp4)
- [تحميل PSD الحقيقي داخل ZIP]('''+base+'''Leila-08-Photoshop-Pilot-v6.zip)
- [مصدر بناء مشروع After Effects — JSX + PNG]('''+base+'''Leila-08-AE-Builder-v6.zip)
- [مصادر طبقات الرسم]('''+base+'''Leila-08-Layer-Sources-v6.zip)
- [صور تبديل الملابس](Leila-08-Wardrobe-Proof-v6.jpg)
- [صور إخفاء العين والنضارة](Leila-08-Face-Proof-v6.jpg)

كل طرف له أجزاء واحدة مرتبطة بالمفاصل. لا توجد صورة جسم كامل ثابتة تحت الأجزاء المتحركة. الشراب غير مرسوم على الجلد أو على الأحذية. البلوزة والفستان والشرابات والجزم مجموعات مستقلة، والأكمام وأجزاء الشراب تتبع عظام الجلد نفسها. الكفوف كاملة بدون فصل أصابع.

الاختبارات المحلية لم ترصد إيدًا أو كمًا أو ساقًا ثابتة باقية في أماكنها بعد تحريكها في وضعيات الفحص. هذه اختبارات محددة وليست ضمانًا لكل الحركات. نهايات المفاصل أُعيد رسمها لتسمح بالتداخل؛ تقييم التشريح وتشطيب التحريك والقماش داخل After Effects لا يزال مطلوبًا. الريج أمامي؛ القرفصاء والخطوات الجانبية اختباران وليسا إثباتًا لجلوس واقعي أو فيلم كامل.

لتكوين AEP: فكّي ضغط حزمة **AE Builder** بالكامل، افتحي مشروعًا فارغًا في After Effects وشغّلي `build_project.jsx` من File → Scripts → Run Script File، ثم احفظي باسم جديد. كومب `Leila_Rig` للتحكم اليدوي، و`Leila_Motion_Test` للاختبار. مفاتيح الملابس في `CTRL_Wardrobe`. يمكن بعد ذلك تشغيل `audit_native_project.jsx` لفحص حسابات القدم من داخل البرنامج. لا يوجد AEP مزيف أو فيديو مُدّعى أنه رندر AE.

[تفاصيل الاستخدام](README-AR.txt) · [التحقق والقيود](verification.json) · [حالة اعتماد الإنتاج](production-gate.json)

المناطق المخفية وأجزاء المفاصل مرسومة بمساعدة توليد الصور، والطبقات Raster. باقي الشخصيات لم تُعتمد بهذا البناء ولم يُعمّم عليها.
'''
(R/'README.md').write_text(readme)
files=['README.md','README-AR.txt','verification.json','source-ownership-qc.json','final-evidence.json','Leila-08-Photoshop-Pilot-v6.zip','Leila-08-AE-Builder-v6.zip','Leila-08-Layer-Sources-v6.zip','Leila-08-Local-Rig-Test-v6.mp4','Leila-08-Wardrobe-Proof-v6.jpg','Leila-08-Face-Proof-v6.jpg','Leila-08-Motion-Contact-v6.jpg']
queue=[]
for fn in files:
 b=(R/fn).read_bytes();queue.append({'filename':fn,'bytes':len(b),'expected_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'sha256':hashlib.sha256(b).hexdigest()})
(R/'upload-queue.json').write_text(json.dumps(queue,indent=2)+'\n');print([(x['filename'],x['bytes'])for x in queue],flush=True)
