from pathlib import Path
import json,math
import numpy as np
from PIL import Image,ImageDraw
from scipy import ndimage
R=Path('/workspace/output/lama-akbar-child-rig-pilot-v6');A=R/'art';m=json.loads((A/'layers.json').read_text());W,H=1200,1800;yy,xx=np.indices((H,W));bones=m['bones']
skin_atlas=Image.open('/workspace/generated_images/exec-64575629-4775-4608-a20a-feb046dbc777.png').convert('RGBA')
def skin_cell(col,row):
 w,h=skin_atlas.size;im=skin_atlas.crop((col*w//2,row*h//3,(col+1)*w//2,(row+1)*h//3));ar=np.array(im);lab,n=ndimage.label(ar[:,:,3]>235);sizes=np.bincount(lab.ravel());sizes[0]=0;ar[:,:,3]=np.where(lab==sizes.argmax(),255,0);im=Image.fromarray(ar);return im.crop(im.getbbox())
paints={'UpperArm':skin_cell(0,0),'Forearm':skin_cell(1,0),'Thigh':skin_cell(0,1),'Shin':skin_cell(1,1)}
def full(l):
 o=Image.new('RGBA',(W,H));o.alpha_composite(Image.open(A/l['png']).convert('RGBA'),(l['x'],l['y']));return o
def find(name):return next(l for l in m['layers']if l['name']==name)
def replace(name,im):
 l=find(name);b=im.getbbox();assert b;fn='assets/v6-'+name+'.png';im.crop(b).save(A/fn);l.update(png=fn,x=b[0],y=b[1])
def mask(im,alpha):
 a=np.array(im).copy();a[:,:,3]=(a[:,:,3]*np.clip(alpha,0,1)).astype('uint8');a[a[:,:,3]==0,:3]=0;return Image.fromarray(a)
# Exact joint circles share center/radius between adjacent bones. The prior
# resize moved the painted cap centers away from the bone pivots.
def limb(source,p,q,r0,r1,fade_end=True):
 p=np.array(p,float);q=np.array(q,float);v=q-p;length=np.linalg.norm(v);u=v/length
 t=((xx-p[0])*u[0]+(yy-p[1])*u[1]);n=(xx-p[0])*(-u[1])+(yy-p[1])*u[0]
 radius=r0+(r1-r0)*np.clip(t/length,0,1)
 shaft=(t>=0)&(t<=length)&(abs(n)<=radius)
 start=(xx-p[0])**2+(yy-p[1])**2<=r0*r0
 end=(xx-q[0])**2+(yy-q[1])**2<=r1*r1
 shape=shaft|start|end
 # Existing generated paint, retargeted into a rig mask; no drawn replacement.
 source=source.crop(source.getbbox());sw,sh=source.size
 tile=source.crop((int(sw*.35),int(sh*.25),int(sw*.65),int(sh*.75)))
 assert np.array(tile)[:,:,3].min()>240,'Paint sample contains transparent background'
 lengthpx=math.ceil(length+r0+r1);widthpx=math.ceil(max(r0,r1)*2+4)
 tex=tile.resize((widthpx,lengthpx),Image.Resampling.BICUBIC).convert('RGB').convert('RGBA')
 angle=math.degrees(math.atan2(u[0],u[1]));tex=tex.rotate(angle,Image.Resampling.BICUBIC,expand=True)
 center=(p+q)/2+u*(r1-r0)/2;o=Image.new('RGBA',(W,H));o.alpha_composite(tex,(round(center[0]-tex.width/2),round(center[1]-tex.height/2)))
 alpha=shape.astype(float)
 if fade_end:
  # Fade ONLY the distal end inside the matching proximal circle below it.
  f=np.clip((length+r1*.90-t)/(r1*1.05),0,1)
  alpha*=np.where(end,f,1)
 return mask(o,alpha)
for side in ['L','R']:
 for part,a,b,r0,r1 in [('UpperArm','UpperArm','Forearm',48,43),('Forearm','Forearm','Hand',43,29),('Thigh','Thigh','Shin',72,50),('Shin','Shin','Foot',50,34)]:
  name='Skin_'+part+'_'+side;replace(name,limb(paints[part],bones[a+'_'+side]['pivot'],bones[b+'_'+side]['pivot'],r0,r1,part in ['UpperArm','Thigh']))
# Remove disconnected hair specks and narrow skin slivers from the base torso.
torso=full(find('Skin_Torso'));ar=np.array(torso);out=np.zeros((H,W),bool)
for y in range(574,1056):
 row=ar[y,:,3]>200;lab,n=ndimage.label(row);k=lab[606]
 if k:out[y]=lab==k
replace('Skin_Torso',mask(torso,out))

# The clothing atlas is an actual image edit. Each cell is independently
# segmented and fitted into the existing character coordinates.
atlas=Image.open('/workspace/work/lama-child-rig-v6/garments-fixed.png').convert('RGBA');aw,ah=atlas.size
def cell(col,row):
 im=atlas.crop((col*aw//2,row*ah//2,(col+1)*aw//2,(row+1)*ah//2));a=np.array(im);lab,n=ndimage.label(a[:,:,3]>235);sizes=np.bincount(lab.ravel());sizes[0]=0;keep=lab==sizes.argmax();keep=ndimage.binary_erosion(keep,iterations=1);a[:,:,3]=np.where(keep,255,0);a[a[:,:,3]==0,:3]=0;im=Image.fromarray(a);return im.crop(im.getbbox())
def fit(im,box):
 o=Image.new('RGBA',(W,H));im=im.resize((box[2]-box[0],box[3]-box[1]),Image.Resampling.LANCZOS);o.alpha_composite(im,(box[0],box[1]));return o
replace('Blouse_Torso',fit(cell(0,0),(390,586,812,1145)))
# In the pinafore outfit the blouse sides are tucked underneath the dress.
# Separate disjoint side fabric from the central front; AE wardrobe masking
# exposes it again with the dress off. This is fabric, never a second sleeve.
shirt=full(find('Blouse_Torso'));bib=np.array(full(find('Dress_Bib_Straps')))[:,:,3]>0
central=(yy<700)|bib
replace('Blouse_Torso',mask(shirt,central))
if not any(l['name']=='Blouse_SidePanels'for l in m['layers']):
 l=find('Blouse_Torso').copy();l.update(name='Blouse_SidePanels',semantic='disjoint blouse side fabric; tucked under pinafore in AE',material='BlouseSideFabric');m['layers'].insert(m['layers'].index(find('Blouse_Torso'))+1,l)
replace('Blouse_SidePanels',mask(shirt,~central))
replace('Basic_Shorts_Pelvis',fit(cell(1,0),(434,1015,775,1167)))
for side,col in [('L',0),('R',1)]:
 # Retain the original toe/foot placement and use the new flat cuff painting.
 calf=full(find('Sock_Calf_'+side));foot=full(find('Sock_Foot_'+side));whole=calf.copy();whole.alpha_composite(foot);box=whole.getbbox();im=fit(cell(col,1),box)
 ankle=bones['Foot_'+side]['pivot'];x,y=ankle;r=25
 disc=(xx-x)**2+(yy-y)**2<=r*r
 # Calf paint ends at the joint; no rigid rectangular tail beyond it.
 upper=(yy<=y)|disc;lower=(yy>=y)|disc
 replace('Sock_Calf_'+side,mask(im,upper))
 replace('Sock_Foot_'+side,mask(im,lower))
(A/'layers.json').write_text(json.dumps(m,indent=2)+'\n')
for name,hidden in {'normal':(),'no_dress':('Dress',),'body_barefoot':('Dress','Blouse','Socks','Shoes'),'no_socks':('Socks',),'no_shoes':('Shoes',),'no_footwear':('Socks','Shoes'),'no_eye_R':('Eye_R',),'no_glasses':('Glasses',),'blank_face':('Face','Glasses')}.items():
 o=Image.new('RGBA',(W,H))
 for l in reversed(m['layers']):
  if l['group']in hidden or l['name']in hidden:continue
  o.alpha_composite(Image.open(A/l['png']).convert('RGBA'),(l['x'],l['y']))
 o.save(R/'proof'/(name+'.png'))
print('v6 parts rebuilt: pivot-centered joint masks, sleeveless torso, fabric-only shorts, front cuffs.')
