from pathlib import Path
import json,hashlib
from gi.repository import Gimp,Gio
R=Path('/workspace/output/lama-akbar-child-rig-pilot-v6');A=R/'art';m=json.loads((A/'layers.json').read_text());im=Gimp.Image.new(m['width'],m['height'],Gimp.ImageBaseType.RGB);im.set_color_profile(Gimp.ColorProfile.new_rgb_srgb())
groups={};order=list(dict.fromkeys(l['group']for l in m['layers']))
for name in reversed(order):
 g=Gimp.GroupLayer.new(im,name);im.insert_layer(g,None,0);groups[name]=g
for l in reversed(m['layers']):
 layer=Gimp.file_load_layer(Gimp.RunMode.NONINTERACTIVE,im,Gio.File.new_for_path(str(A/l['png'])));im.insert_layer(layer,groups[l['group']],0);layer.set_name(l['name']);layer.set_offsets(l['x'],l['y'])
def export(img,path,kind):
 p=Gimp.get_pdb().lookup_procedure('file-'+kind+'-export');c=p.create_config()
 for k,v in [('run-mode',Gimp.RunMode.NONINTERACTIVE),('image',img),('file',Gio.File.new_for_path(str(path))),('options',Gimp.ExportOptions())]:c.set_property(k,v)
 if kind=='psd':c.set_property('include-color-profile',True)
 if kind=='png':c.set_property('compression',9)
 result=p.run(c);assert result.index(0)==Gimp.PDBStatusType.SUCCESS
path=R/'Leila-08-Single-Owner-Pilot-v6.psd';export(im,path,'psd');im.delete();image=Gimp.file_load(Gimp.RunMode.NONINTERACTIVE,Gio.File.new_for_path(str(path)))
lookup={}
def collect(l):
 lookup[l.get_name()]=l
 if l.is_group():
  for child in l.get_children():collect(child)
for l in image.get_layers():collect(l)
assert all(l['name']in lookup for l in m['layers'])
vis={k:v.get_visible()for k,v in lookup.items()}
cases={'normal':[],'body_barefoot':['Dress','Blouse','Socks','Shoes'],'no_dress':['Dress'],'no_socks':['Socks'],'no_shoes':['Shoes'],'no_footwear':['Socks','Shoes'],'no_eye_R':['Eye_R'],'no_glasses':['Glasses'],'blank_face':['Face','Glasses']}
for name,hidden in cases.items():
 for k,l in lookup.items():l.set_visible(vis[k])
 for k in hidden:lookup[k].set_visible(False)
 export(image,R/'proof'/('native-'+name+'.png'),'png')
image.delete();report={'native_application':'GIMP 3.0.4','save_reopen':'passed','native_visibility_cases':list(cases),'groups':order,'leaf_layers':len(m['layers']),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'native_photoshop':'not run','native_after_effects':'not available','no_complete_hidden_reference_layer':True}
(R/'native-psd-qc.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
