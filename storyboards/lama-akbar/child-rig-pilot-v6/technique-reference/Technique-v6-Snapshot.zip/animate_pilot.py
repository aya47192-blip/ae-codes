from pathlib import Path
import math,json,copy,hashlib,subprocess
import numpy as np
from PIL import Image,ImageDraw
R=Path('/workspace/output/lama-akbar-child-rig-pilot-v6');A=R/'art';M=json.loads((A/'layers.json').read_text());bones=M['bones'];FPS=30;N=360;SCALE=.48
for p in [R/'scene-source',R/'proof'/'frames']:p.mkdir(parents=True,exist_ok=True)
def ease(a,b,t):t=max(0,min(1,t));t=t*t*(3-2*t);return a+(b-a)*t
def solve(side,hip_shift,target):
 hip=np.array(bones['Thigh_'+side]['pivot'],float)+hip_shift;knee=np.array(bones['Shin_'+side]['pivot'],float);resthip=np.array(bones['Thigh_'+side]['pivot'],float);ank=np.array(bones['Foot_'+side]['pivot'],float)
 u=knee-resthip;v=ank-knee;l1=np.linalg.norm(u);l2=np.linalg.norm(v);dv=np.array(target)-hip;dist=np.linalg.norm(dv);d=min(l1+l2-.001,max(abs(l1-l2)+.001,dist));base=math.atan2(dv[1],dv[0]);phi=math.acos(max(-1,min(1,(l1*l1+d*d-l2*l2)/(2*l1*d))))
 theta=base+(phi if side=='L'else -phi);kj=hip+l1*np.array([math.cos(theta),math.sin(theta)]);sv=np.array(target)-kj
 rot1=math.degrees(theta-math.atan2(u[1],u[0]));rot2=math.degrees(math.atan2(sv[1],sv[0])-math.atan2(v[1],v[0]))-rot1
 return rot1,rot2,-rot1-rot2

def pose(f):
 ang={b:0. for b in bones};rootx=0.;down=0.;target={s:np.array(bones['Foot_'+s]['pivot'],float)for s in ['L','R']};contact={'L':False,'R':False}
 if 145<=f<190:
  amount=ease(0,1,(f-145)/15)if f<160 else 1 if f<174 else ease(1,0,(f-174)/16)
  ang['UpperArm_L']=65*amount;ang['Forearm_L']=60*amount;ang['Hand_L']=-10*amount;ang['Head']=-3*amount
 if 180<=f<240:
  contact={'L':True,'R':True}
  down=ease(0,92,(f-180)/20)if f<200 else 92 if f<212 else ease(92,18,(f-212)/28)
  ang['Torso']=ease(0,5,down/92);ang['Head']=-ang['Torso']*.45
 if 240<=f<300:
  step=(f-240)//15;t=((f-240)%15)/14.;rootx=(f-240)/59*100;down=18+8*math.sin(math.pi*t)**2
  if step==0:target['R']+=np.array([50*ease(0,1,t),-32*math.sin(math.pi*t)]);contact['L']=True
  elif step==1:
   target['R'][0]+=50;target['L']+=np.array([50*ease(0,1,t),-32*math.sin(math.pi*t)]);contact['R']=True
  elif step==2:
   target['L'][0]+=50;target['R']+=np.array([50+50*ease(0,1,t),-32*math.sin(math.pi*t)]);contact['L']=True
  else:
   target['R'][0]+=100;target['L']+=np.array([50+50*ease(0,1,t),-32*math.sin(math.pi*t)]);contact['R']=True
  swing=8*math.sin((f-240)*math.pi/15);ang['UpperArm_L']=swing;ang['UpperArm_R']=-swing;ang['Forearm_L']=4;ang['Forearm_R']=-4
 if f>=300:
  rootx=100;down=ease(18,0,(f-300)/22)
  for s in target:target[s][0]+=100
 if f>=180:
  for s in ['L','R']:
   a,b,c=solve(s,np.array([rootx,down]),target[s]);ang['Thigh_'+s]=a;ang['Shin_'+s]=b;ang['Foot_'+s]=c
 return {'angles':ang,'root_x':rootx,'pelvis_down':down,'targets':{s:p.tolist()for s,p in target.items()},'contact':contact}
poses=[pose(f)for f in range(N)]
# Source contract was selected for a 12s single-character stress test, not the 90s film.
source={'version':1,'name':'Leila_08_Single_Owner_Pilot','main':'Leila_Motion_Test','colorManagement':{'workingSpace':'sRGB IEC61966-2.1','bitsPerChannel':16,'linearize':False},'strictFonts':False,'assets':[],'comps':[]}
for i,l in enumerate(M['layers']):
 l['asset']='Art'+str(i);source['assets'].append({'id':l['asset'],'path':str(Path('../art')/l['png'])})
# The generator requires assets within the scene root. Copy only active cropped art.
import shutil
ss=R/'scene-source';(ss/'assets').mkdir(exist_ok=True)
for i,l in enumerate(M['layers']):
 dest=ss/'assets'/Path(l['png']).name;shutil.copyfile(A/l['png'],dest);source['assets'][i]['path']='assets/'+dest.name

def props(v):return{'value':v}
def keys(vals):return{'keys':[{'time':i/FPS,'value':v,'ease':'linear'}for i,v in enumerate(vals)]}
visibility={}
for f in range(N):
 visibility[f]={'Dress':not(90<=f<150 or 180<=f<240),'Blouse':not(120<=f<150 or 180<=f<240),'Shoes':not(30<=f<150 or 180<=f<240),'Socks':not(60<=f<150 or 180<=f<240),'Body':True,'Hair':True,'Head':True,'Glasses':not(30<=f<60),'Face':not(45<=f<60)}
for static,cid in [(False,'Leila_Motion_Test'),(True,'Leila_Rig')]:
 comp={'id':cid,'width':1920,'height':1080,'fps':FPS,'duration':N/FPS,'background':[.91,.905,.89],'layers':[],'markers':[{'time':f/FPS,'text':txt}for f,txt in [(0,'Single-owner pilot. AE native execution pending.'),(30,'Shoes off: complete socks'),(60,'Socks + shoes off: barefoot'),(90,'Dress off: complete blouse'),(120,'Base body and basic shorts, barefoot'),(150,'Raised arm / bent elbow test'),(180,'Crouch, planted feet'),(240,'Four alternating planted-foot steps'),(300,'Wardrobe restored; settle')]]}
 for l in M['layers']:
  pivot=bones[l['bone']]['pivot'];op=[100 if visibility[f].get(l['group'],True) else 0 for f in range(N)]
  if l['name']=='Eye_R':op=[0 if 15<=f<30 else op[f]for f in range(N)]
  comp['layers'].append({'id':l['name'],'name':l['group']+' / '+l['name'],'type':'footage','source':l['asset'],'parent':'CTRL_'+l['bone'],'motionBlur':False,'properties':{'anchor':props([pivot[0]-l['x'],pivot[1]-l['y']]),'position':props([0,0]),'opacity':props(100)if static else keys(op)}})
 comp['layers'].append({'id':'Wardrobe','name':'CTRL_Wardrobe','type':'null','properties':{'anchor':props([0,0]),'position':props([0,0])}})
 comp['layers'].append({'id':'Root','name':'CTRL_Root','type':'null','properties':{'anchor':props([0,0]),'position':props([960,650])if static else keys([[960+p['root_x']*SCALE,650]for p in poses]),'scale':props([SCALE*100,SCALE*100])}})
 for name,b in bones.items():
  parent=b['parent'];pivot=np.array(b['pivot'],float)
  offset=(pivot-np.array(bones[parent]['pivot'])).tolist()if parent else[0,0]
  position=props(offset)
  if name=='Pelvis'and not static:position=keys([[0,p['pelvis_down']]for p in poses])
  comp['layers'].append({'id':'CTRL_'+name,'name':'CTRL_'+name,'type':'null','parent':'CTRL_'+parent if parent else'Root','properties':{'anchor':props([0,0]),'position':position,'rotation':props(0)if static else keys([p['angles'][name]for p in poses])}})
 source['comps'].append(comp)
(ss/'scene.json').write_text(json.dumps(source,indent=2)+'\n')
# One contiguous test window, with explicitly bounded authored rotations and pivots.
contract={'version':1,'width':1920,'height':1080,'fps':FPS,'frames':N,'colorManagement':source['colorManagement'],'shots':[{'id':'Pilot','comp':'Leila_Motion_Test','inFrame':0,'outFrame':N,'reference':'User approved one child pilot before all characters. Test no duplicates, barefoot base, garment switches, arm bend, crouch and stepping. Preserve approved curly heroine.','reviewFrames':[0,20,40,75,105,135,165,205,245,260,290,359]}],'colors':[],'joints':[]}
for cid in ['Leila_Motion_Test','Leila_Rig']:
 for name,b in bones.items():
  contract['joints'].append({'comp':cid,'layer':'CTRL_'+name,'parent':'CTRL_'+b['parent']if b['parent']else'Root','pivot':[0,0],'minRotation':-130,'maxRotation':130,'allowMirror':False,'allowNonUniformScale':False})
(ss/'production.json').write_text(json.dumps(contract,indent=2)+'\n')
(R/'authored-poses.json').write_text(json.dumps({'fps':FPS,'frames':N,'scale':SCALE,'poses':poses},indent=2)+'\n')
import sys
if '--source-only' in sys.argv:
 print('Source regenerated for current art; existing diagnostic retained.');sys.exit(0)
# FK renderer is independent of AE runtime. It renders the same source transforms only.
def rot(a):
 a=math.radians(a);c,s=math.cos(a),math.sin(a);return np.array([[c,-s,0],[s,c,0],[0,0,1.]])
def trans(x,y):return np.array([[1.,0,x],[0,1.,y],[0,0,1.]])
def matrices(p,scale=SCALE,origin=(960,650)):
 root=trans(origin[0]+p['root_x']*scale,origin[1])@np.diag([scale,scale,1.]);out={}
 def mat(name):
  if name in out:return out[name]
  b=bones[name];parent=b['parent'];offset=np.array(b['pivot'])-np.array(bones[parent]['pivot'])if parent else np.array([0,p['pelvis_down']])
  out[name]=(mat(parent)if parent else root)@trans(*offset)@rot(p['angles'][name]);return out[name]
 for b in bones:mat(b)
 return out
images={l['name']:Image.open(A/l['png']).convert('RGBA')for l in M['layers']}
def render(f,force_hidden=(),body_only=False,diagnostic=True,only_group=None,override_pose=None):
 p=override_pose if override_pose is not None else poses[f];mats=matrices(p);out=Image.new('RGBA',(1920,1080),(233,232,227,255));transparent=Image.new('RGBA',(1920,1080))
 for l in reversed(M['layers']):
  if l['group']in force_hidden or(body_only and l['group']!='Body')or(only_group is not None and l['group']!=only_group):continue
  if not body_only and only_group is None and not visibility[f].get(l['group'],True):continue
  if l['name']=='Eye_R' and 15<=f<30 and not body_only:continue
  if l['name']=='Blouse_SidePanels' and only_group is None and visibility[f]['Dress'] and 'Dress' not in force_hidden:continue
  im=images[l['name']];pivot=bones[l['bone']]['pivot'];local=trans(l['x']-pivot[0],l['y']-pivot[1]);T=mats[l['bone']]@local
  corners=T@np.array([[0,im.width,0,im.width],[0,0,im.height,im.height],[1,1,1,1]])
  x0=max(0,math.floor(corners[0].min())-2);y0=max(0,math.floor(corners[1].min())-2);x1=min(1920,math.ceil(corners[0].max())+2);y1=min(1080,math.ceil(corners[1].max())+2)
  if x1<=x0 or y1<=y0:continue
  inv=np.linalg.inv(T);ic=inv@trans(x0,y0);crop=im.transform((x1-x0,y1-y0),Image.Transform.AFFINE,tuple(ic[:2].flatten()),Image.Resampling.BICUBIC)
  transparent.alpha_composite(crop,(x0,y0))
 if body_only or only_group is not None:return transparent
 out.alpha_composite(transparent)
 if diagnostic:
  d=ImageDraw.Draw(out);d.rectangle((0,0,1920,65),fill='#222831');d.text((30,20),'LOCAL RIG DIAGNOSTIC - NOT AN AFTER EFFECTS RENDER',fill='white',stroke_width=0)
  stage='Dressed rest'if f<30 else'Complete socks / face switches'if f<60 else'Bare feet - no hidden socks'if f<90 else'Complete blouse - dress off'if f<120 else'Basic body / shorts - barefoot'if f<150 else'Arm and elbow bend'if f<180 else'Crouch / planted feet'if f<240 else'Alternating planted-foot steps'if f<300 else'Return to dressed hold'
  d.text((30,1030),stage+' | frame '+str(f),fill='#222831')
 return out.convert('RGB')
# Measure actual FK ankle positions against authored world targets on stance frames.
errors=[]
for f,p in enumerate(poses):
 mats=matrices(p)
 for side in ['L','R']:
  if p['contact'][side]:
   actual=mats['Foot_'+side]@np.array([0,0,1.]);expected=(np.array(p['targets'][side])-np.array(bones['Pelvis']['pivot']))*SCALE+np.array([960,650]);errors.append(float(np.linalg.norm(actual[:2]-expected)))
qc={'pipeline':'Python/Pillow FK surrogate, not After Effects','frames':N,'fps':FPS,'planted_foot_samples':len(errors),'max_planted_foot_drift_comp_pixels':max(errors)if errors else None,'native_after_effects':'not run','visual_approval':'pending inspection','source_ownership_qc':'source-ownership-qc.json'}
(R/'surrogate-motion-qc.json').write_text(json.dumps(qc,indent=2)+'\n')
# Render all frames through the same transparent RGBA layers, no full-body backdrop.
proc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1920x1080','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',str(R/'proof'/'local-rig-diagnostic.mp4')],stdin=subprocess.PIPE)
review=[0,20,40,75,105,135,165,205,245,260,290,359]
for f in range(N):
 im=render(f);proc.stdin.write(im.tobytes())
 if f in review:im.save(R/'proof'/'frames'/('%03d.png'%f))
 if f%60==0:print('FRAME',f,flush=True)
proc.stdin.close();assert proc.wait()==0
contact=Image.new('RGB',(1920,1440),'white');d=ImageDraw.Draw(contact)
for i,f in enumerate(review):
 im=Image.open(R/'proof'/'frames'/('%03d.png'%f));im.thumbnail((640,360));contact.paste(im,((i%3)*640,(i//3)*360))
contact.save(R/'proof'/'motion-contact.jpg',quality=90)
# Explicit vacated-hand test on an unclothed moving body: no stationary hand can remain.
rest=render(135,body_only=True);moved=render(165,body_only=True);ra=np.array(rest)[:,:,3];ma=np.array(moved)[:,:,3];core=(ra>245)&np.indices(ra.shape)[1].__lt__(850)&(np.indices(ra.shape)[0]>610)&(np.indices(ra.shape)[0]<685)
qc['vacated_left_hand_region_pixels']=int(core.sum());qc['vacated_left_hand_remaining_pixels']=int((ma[core]>30).sum())
# Vacated garment footprint: a sleeve must not remain printed on the shirt torso.
rs=np.array(render(0,only_group='Blouse'))[:,:,3];ms=np.array(render(165,only_group='Blouse'))[:,:,3]
gy,gx=np.indices(rs.shape);region=(gx>813)&(gx<854)&(gy>553)&(gy<598)&(rs>245)
qc['vacated_left_sleeve_core_pixels']=int(region.sum());qc['vacated_left_sleeve_remaining_pixels']=int((ms[region]>30).sum())
# A separate ownership probe lifts the left leg while leaving the rest of the rig alone.
probe=copy.deepcopy(poses[135]);probe['angles']['Thigh_L']=45;probe['angles']['Shin_L']=-70;probe['angles']['Foot_L']=25
restbody=np.array(render(135,body_only=True))[:,:,3];lift=render(135,body_only=True,override_pose=probe);lift.save(R/'proof'/'leg-ownership-probe.png')
lifta=np.array(lift)[:,:,3];region=(gx>899)&(gx<918)&(gy>820)&(gy<875)&(restbody>245)
qc['vacated_left_shin_core_pixels']=int(region.sum());qc['vacated_left_shin_remaining_pixels']=int((lifta[region]>30).sum())
qc['visual_scope']='Local diagnostic only. Native AE visual approval remains pending.'
(R/'surrogate-motion-qc.json').write_text(json.dumps(qc,indent=2)+'\n');print(json.dumps(qc),flush=True)
