from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image,ImageDraw
from scipy import ndimage
from psd_tools import PSDImage
R=Path('/workspace/output/lama-akbar-child-rig-pilot-v6');A=R/'art';P=R/'proof';m=json.loads((A/'layers.json').read_text());yy,xx=np.indices((1800,1200))

def mask(l):
 a=np.array(Image.open(A/l['png']).convert('RGBA'));out=np.zeros((1800,1200),bool);x,y=l['x'],l['y'];h,w=a.shape[:2];out[y:y+h,x:x+w]=a[:,:,3]>240;return out
masks={l['name']:mask(l)for l in m['layers']}
def rgba(l):
 out=Image.new('RGBA',(1200,1800));out.alpha_composite(Image.open(A/l['png']).convert('RGBA'),(l['x'],l['y']));return np.array(out)
def disk(p,r):return(xx-p[0])**2+(yy-p[1])**2<=r*r
q={'status':'source and static PSD checks; AE native and final visual approval pending','anatomical_occurrences':{},'parts':len(m['layers']),'bones':len(m['bones'])}
assert len(set(l['name']for l in m['layers']))==len(m['layers'])
for side in ['L','R']:
 for part in ['UpperArm','Forearm','Hand','Thigh','Shin','BareFoot']:
  name='Skin_'+part+'_'+side;assert sum(l['name']==name for l in m['layers'])==1;q['anatomical_occurrences'][name]=1
for side in ['L','R']:
 for cloth,skin in [('Blouse_UpperSleeve','Skin_UpperArm'),('Blouse_ForeSleeve','Skin_Forearm'),('Sock_Calf','Skin_Shin'),('Sock_Foot','Skin_BareFoot'),('Shoe','Skin_BareFoot')]:
  a=next(l for l in m['layers']if l['name']==cloth+'_'+side);b=next(l for l in m['layers']if l['name']==skin+'_'+side);assert a['bone']==b['bone']
q['all_garment_parts_share_corresponding_skin_bone']=True
# A complete reference plate is not part of the renderable graph.
q['no_active_whole_body_reference']=not any('reference'in l['name'].lower()or'base_body'in l['name'].lower()for l in m['layers']);assert q['no_active_whole_body_reference']
# Basic garments occlude skin by design; only actual skin-to-skin overlap is relevant to duplicate-limb tests.
count=np.zeros((1800,1200),'uint8');allowed=np.zeros_like(count,bool)
for name,b in m['bones'].items():
 if name not in ['Head','Torso','Pelvis']:allowed|=disk(b['pivot'],90)
for l in m['layers']:
 if l['group']=='Body'and l['material']not in ['BasicTop','BasicShorts']:count+=masks[l['name']]
q['skin_to_skin_overlap_outside_joints_pixels']=int(((count>1)&~allowed).sum())
# Unlike anatomy, sleeve and torso fabric can legitimately overlap in the projection at rest.
# Record that overlap explicitly, and rely on the vacated-sleeve motion probe to reject a printed stationary sleeve.
q['projected_sleeve_torso_overlap_pixels']=int(sum((masks['Blouse_Torso']&masks['Blouse_'+part+'_'+side]).sum()for part in ['UpperSleeve','ForeSleeve']for side in ['L','R']))
bodycream=0;shoecream=0;glassesdark=0
for l in m['layers']:
 a=rgba(l);r,g,b=a[:,:,0].astype(int),a[:,:,1].astype(int),a[:,:,2].astype(int)
 cream=(r-g<28)&(g>185)&(b>155)&(a[:,:,3]>240)
 if l['group']=='Body':bodycream+=int((cream&(yy>1450)).sum())
 if l['group']=='Shoes':shoecream+=int(cream.sum())
 if l['group']=='Glasses':glassesdark+=int(((a[:,:,:3].max(2)<105)&(a[:,:,3]>240)).sum())
q['stocking_like_pixels_in_body_below_knees']=bodycream;q['stocking_like_pixels_baked_in_shoes']=shoecream;q['dark_eyelash_ink_in_glasses']=glassesdark
# Native GIMP exported/reopened PSD must preserve every source leaf, group and normal composition.
psd=PSDImage.open(R/'Leila-08-Single-Owner-Pilot-v6.psd');leaves=[l for l in psd.descendants()if not l.is_group()]
assert [l.name for l in reversed(leaves)]==[l['name']for l in m['layers']]
assert psd.size==(1200,1800);assert all(int(c.compression)==1 for l in leaves for c in l._channels)
q['independent_psd_reader']='psd-tools 1.26.0';q['rle_channels_verified']=True
actual=np.array(Image.open(P/'native-normal.png').convert('RGBA')).astype(int);expected=np.array(Image.open(P/'normal.png').convert('RGBA')).astype(int)
q['native_vs_asset_mean_absolute_error_8bit']=float(np.abs(actual-expected).mean());assert q['native_vs_asset_mean_absolute_error_8bit']<1
q['feature_hide_tests']={}
for feature,case in [('Eye_R','no_eye_R'),('Glasses_Frame','no_glasses')]:
 core=ndimage.binary_erosion(masks[feature],iterations=3);a=np.array(Image.open(P/('native-'+case+'.png')).convert('RGBA'))
 if feature=='Eye_R':assert np.all(a[:,:,3][core]>=250)
 q['feature_hide_tests'][feature]={'opaque_core_pixels':int((a[:,:,3][core]>=250).sum()),'tested_core_pixels':int(core.sum())}
# Cases must reveal the same underlying bare-body foot pixels, not a second stocking drawn into the body.
a=np.array(Image.open(P/'native-no_footwear.png').convert('RGBA'));b=np.array(Image.open(P/'native-body_barefoot.png').convert('RGBA'));region=yy>1450
q['bare_footwear_hide_matches_body_base']=bool(np.array_equal(a[region],b[region]));assert q['bare_footwear_hide_matches_body_base']
q['native_photoshop']='not run';q['native_after_effects']='unavailable';q['motion']=json.loads((R/'surrogate-motion-qc.json').read_text())
assert q['motion']['vacated_left_hand_remaining_pixels']==0
assert q['motion']['vacated_left_sleeve_remaining_pixels']==0
assert q['motion']['vacated_left_shin_remaining_pixels']==0
assert q['motion']['max_planted_foot_drift_comp_pixels']<.75
q['no_static_duplicate_anatomy_probe']='passed in local renderer only'
q['professional_native_rig_approval']='pending; do not generalize to other characters yet'
(R/'verification.json').write_text(json.dumps(q,indent=2)+'\n')
# Actual native visibility proof, composited against checkerboard solely for inspection.
contact=Image.new('RGB',(1800,1200),'white');d=ImageDraw.Draw(contact)
cases=[('normal','Dressed'),('no_dress','Dress off'),('body_barefoot','Basic body / barefoot'),('no_socks','Socks off / shoes on'),('no_shoes','Shoes off / socks on'),('no_footwear','Socks + shoes off')]
for i,(case,label)in enumerate(cases):
 x=(i%3)*600;y=(i//3)*600
 for gy in range(y+25,y+595,16):
  for gx in range(x,x+600,16):d.rectangle((gx,gy,min(gx+15,x+599),min(gy+15,y+594)),fill='#eee'if((gx-x)//16+(gy-y)//16)%2 else'#d2d2d2')
 im=Image.open(P/('native-'+case+'.png')).convert('RGBA');im.thumbnail((580,555));contact.paste(im,(x+(600-im.width)//2,y+30),im);d.text((x+10,y+5),label,fill='black')
contact.save(P/'wardrobe-proof.jpg',quality=92)
face=Image.new('RGB',(1800,650),'#eee');d=ImageDraw.Draw(face)
for i,(case,label)in enumerate([('normal','Normal'),('no_eye_R','Eye + all lashes off'),('no_glasses','Glasses off'),('blank_face','All face features off')]):
 im=Image.open(P/('native-'+case+'.png')).convert('RGBA').crop((380,250,850,590));im.thumbnail((440,550));face.paste(im,(i*450,40),im);d.text((i*450+10,10),label,fill='black')
face.save(P/'face-proof.jpg',quality=93)
print(json.dumps(q,indent=2),flush=True)
