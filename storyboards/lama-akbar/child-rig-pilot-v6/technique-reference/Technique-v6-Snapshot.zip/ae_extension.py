from pathlib import Path
import json,hashlib
R=Path('/workspace/output/lama-akbar-child-rig-pilot-v6');P=R/'after-effects';m=json.loads((R/'art/layers.json').read_text())
p=P/'build_project.jsx';text=p.read_text();needle='        // Verify important native structure before saving; this is not a visual/render approval.'
config={l['name']:l['group']for l in m['layers']}
block='''        // Task-specific wardrobe UI: tested only when this script runs in AE.
        var V4_MATERIALS = '''+json.dumps(config)+''';
        var V4_GROUPS = ['Dress','Blouse','Socks','Shoes','Body','Hair','Head','Face','Glasses'];
        for(i=0;i<SCENE.comps.length;i++) {
            c=SCENE.comps[i];var wardrobe=layers[c.id].Wardrobe;
            var parade=wardrobe.property('ADBE Effect Parade');
            for(var gi=0;gi<V4_GROUPS.length;gi++) {
                if(!parade.canAddProperty('ADBE Checkbox Control')) fail('Checkbox control unavailable in this AE installation.');
                var control=parade.addProperty('ADBE Checkbox Control');control.name='Show_'+V4_GROUPS[gi];control.property(1).setValue(1);
            }
            for(j=0;j<c.layers.length;j++) {
                l=c.layers[j];if(l.type!=='footage')continue;
                var grp=V4_MATERIALS[l.id];if(!grp)continue;
                var opacity=layers[c.id][l.id].property('ADBE Transform Group').property('ADBE Opacity');
                opacity.expression='value * thisComp.layer("CTRL_Wardrobe").effect("Show_'+grp+'")(1)';
                if(l.id==='Blouse_SidePanels')opacity.expression+=' * (1 - thisComp.layer("Dress / Dress_Bib_Straps").transform.opacity/100)';
                opacity.valueAtTime(0,false);if(opacity.expressionError)fail('Wardrobe expression failed: '+l.id+' '+opacity.expressionError);
            }
        }
'''
assert needle in text;text=text.replace(needle,block+needle)
p.write_text(text)
# Native audit uses AE's actual expression evaluator to measure ankle transforms.
pose=json.loads((R/'authored-poses.json').read_text());targets=[]
for frame,item in enumerate(pose['poses']):
 for side in ['L','R']:
  if item['contact'][side]:
   v=item['targets'][side];targets.append({'frame':frame,'side':side,'expected':[960+(v[0]-606)*.48,650+(v[1]-1100)*.48]})
audit='''// Run ONLY inside After Effects after build_project.jsx has saved the project.
(function(){
 var targets='''+json.dumps(targets)+''';
 var comp=null,report={application:'Adobe After Effects',version:app.version,status:'not_completed',native_render:'not_run',visual_rig:'pending',samples:[]};
 var probe=null;
 try {
  if(!app.project || !app.project.file)throw Error('Build and save the pilot AEP first.');
  for(var i=1;i<=app.project.numItems;i++)if(app.project.item(i) instanceof CompItem && app.project.item(i).name==='Leila_Motion_Test')comp=app.project.item(i);
  if(!comp)throw Error('Pilot composition not found.');
  if(comp.width!==1920 || comp.height!==1080 || comp.frameRate!==30)throw Error('Unexpected composition settings.');
  var keys={};for(i=1;i<=comp.numLayers;i++){var n=comp.layer(i).name;if(keys[n])throw Error('Duplicate layer name '+n);keys[n]=true;}
  probe=comp.layers.addNull();probe.name='TEMP_NATIVE_COORDINATE_PROBE';var prop=probe.property('ADBE Transform Group').property('ADBE Position');var maxError=0;
  for(i=0;i<targets.length;i++){
   var sample=targets[i];prop.expression='thisComp.layer("CTRL_Foot_'+sample.side+'").toComp([0,0])';
   var val=prop.valueAtTime(sample.frame/30,false);if(prop.expressionError)throw Error(prop.expressionError);
   var dx=val[0]-sample.expected[0],dy=val[1]-sample.expected[1],err=Math.sqrt(dx*dx+dy*dy);if(err>maxError)maxError=err;
   report.samples.push({frame:sample.frame,side:sample.side,actual:[val[0],val[1]],expected:sample.expected,error:err});
  }
  probe.remove();probe=null;report.max_contact_error_pixels=maxError;if(maxError>.75)throw Error('Native ankle drift exceeds tolerance: '+maxError);
  report.status='native_structure_and_contact_transforms_passed';
  var out=new File(app.project.file.parent.fsName+'/native-audit-'+(new Date().getTime())+'.txt');
  out.encoding='UTF-8';if(!out.open('w'))throw Error('Cannot write native audit.');var lines=['Application=Adobe After Effects','Version='+app.version,'NativeStructure=passed','MaxContactErrorPx='+maxError,'NativeRender=not_run','VisualRig=pending'];for(var si=0;si<report.samples.length;si++){var sm=report.samples[si];lines.push('frame='+sm.frame+' side='+sm.side+' actual='+sm.actual.join(',')+' expected='+sm.expected.join(',')+' error='+sm.error);}out.write(lines.join('\\n'));out.close();
  comp.openInViewer();alert('Native transform audit passed. Written: '+out.fsName+'\\nVisual rig review, native rendering and editability approval are still required.');
 }catch(e){if(probe)probe.remove();alert('Native audit FAILED: '+e.toString());}
}());
'''
(P/'audit_native_project.jsx').write_text(audit)
# Rehash generated package after the explicit, documented extension.
files={str(f.relative_to(P)):hashlib.sha256(f.read_bytes()).hexdigest()for f in P.rglob('*')if f.is_file()and f.name!='manifest.json'}
(P/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
print('Added native wardrobe controls and runtime audit. AE execution remains unverified.')
