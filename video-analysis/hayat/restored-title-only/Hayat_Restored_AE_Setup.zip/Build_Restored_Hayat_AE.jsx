/* Run from After Effects: File > Scripts > Run Script File. */
(function(){
 var root=new File($.fileName).parent;
 var movie=new File(root.fsName+'/Hayat_Restored_TitleOnly_1152x632.mp4');
 if(!movie.exists){movie=new File(root.fsName+'/media/Hayat_Restored_TitleOnly_1152x632.mp4');}
 if(!movie.exists){movie=File.openDialog('Choose Hayat_Restored_TitleOnly_1152x632.mp4');}
 if(!movie){return;}
 try{
  var project=app.newProject();if(!project){return;}
  app.beginUndoGroup('Build restored Hayat project');project.bitsPerChannel=16;
  var footage=project.importFile(new ImportOptions(movie));
  var comp=project.items.addComp('HAYAT_RESTORED_TITLE_ONLY',1152,632,1,3861/30,30);
  var clip=comp.layers.add(footage);clip.name='Restored film - original frame timing';
  clip.property('ADBE Transform Group').property('ADBE Position').setValue([576,316]);
  var adjust=comp.layers.addSolid([1,1,1],'Additional editable color controls',1152,632,1,3861/30);adjust.adjustmentLayer=true;
  var effects=adjust.property('ADBE Effect Parade');
  var keys=['ADBE Exposure2','ADBE HUE SATURATION','ADBE Brightness & Contrast 2'];
  for(var i=0;i<keys.length;i++){try{effects.addProperty(keys[i]);}catch(ignored){}}
  comp.comment='Restored/cleaned footage is baked into the MP4. Neutral additional native effects above it. No reconstructed character animation layers; 30fps source-frame timing retained, end credits trimmed.';
  comp.openInViewer();var path=new File(root.fsName+'/Hayat_Restored_Edit.aep');var n=2;
  while(path.exists){path=new File(root.fsName+'/Hayat_Restored_Edit_'+n+'.aep');n++;}
  project.save(path);app.endUndoGroup();alert('Native AEP created: '+path.fsName);
 }catch(e){try{app.endUndoGroup();}catch(ignored){}alert('Project setup did not finish: '+e.toString());}
}());
