/* Run from File > Scripts > Run Script File. Creates an AEP locally.
   Editing overlays are copies above intact video, not recovered production layers. */
(function(){
 var root=new File($.fileName).parent;
 var movie=new File(root.fsName+'/Video2_Final_1920x1080.mp4');
 if(!movie.exists)movie=File.openDialog('Choose Video2_Final_1920x1080.mp4');
 if(!movie)return;
 var begun=false;
 try{
  var p=app.newProject();if(!p)return;
  app.beginUndoGroup('Build Video2 lightweight project');begun=true;
  p.bitsPerChannel=8;try{p.workingSpace='';}catch(ignored){}
  var f=p.importFile(new ImportOptions(movie));
  if(f.width!==1920||f.height!==1080||Math.abs(f.duration-37.716)>0.15)throw new Error('Choose the final 1920x1080 movie from this package.');
  var W=f.width,H=f.height,D=f.duration,F=30000/1001;
  function comp(name){var c=p.items.addComp(name,W,H,1,D,F);c.motionBlur=false;c.frameBlending=false;c.resolutionFactor=[4,4];return c;}
  function identity(l){l.startTime=0;l.stretch=100;l.motionBlur=false;l.blendingMode=BlendingMode.NORMAL;try{l.frameBlendingType=FrameBlendingType.NO_FRAME_BLEND;}catch(ignored){}return l;}
  var edit=comp('01_EDIT_VIDEO2');
  var base=identity(edit.layers.add(f));base.name='BASE_INTACT_FINAL_VIDEO';
  base.comment='Intact final video and only active audio track. Do not delete. Overlays above are same-time video regions, not separated original artwork.';
  function region(name,start,end,box){
   var l=identity(edit.layers.add(f));l.name=name;l.audioEnabled=false;
   l.inPoint=Math.max(0,start-3.336670);l.outPoint=Math.min(D,end-3.336670);
   var m=l.property('ADBE Mask Parade').addProperty('ADBE Mask Atom');m.maskMode=MaskMode.ADD;
   var s=new Shape();s.vertices=[[box[0],box[1]],[box[2],box[1]],[box[2],box[3]],[box[0],box[3]]];s.inTangents=[[0,0],[0,0],[0,0],[0,0]];s.outTangents=s.inTangents;s.closed=true;
   m.property('ADBE Mask Shape').setValue(s);m.property('ADBE Mask Feather').setValue([0,0]);
   var e=m.property('ADBE Mask Offset');if(e)e.setValue(0);
   l.comment='Visible wall region from the same frame. Hiding this overlay reveals the same region in the intact base. It does not erase objects.';
  }
  region('WALLPAPER_LEFT_WIDE_MIRROR',3.637,6.14,[20,20,500,1050]);
  region('WALLPAPER_RIGHT_WIDE_MIRROR',3.637,6.14,[1350,20,1890,1050]);
  region('WALLPAPER_LEFT_MIRROR_ACTION',8.7,17.8,[20,20,500,1050]);
  region('PINK_WALL_RIGHT_DOOR',19.7,22.4,[1550,20,1890,1050]);
  edit.comment='No character isolation or new animation. Original final movie remains complete. 8bpc, quarter-resolution preview, no added GPU effects or automatic render probes.';
  var ref=comp('02_FINAL_VIDEO_REFERENCE');identity(ref.layers.add(f));
  var check=comp('03_DIFFERENCE_CHECK_EXPECT_BLACK');
  var a=check.layers.add(ref);a.audioEnabled=false;
  var b=check.layers.add(edit);b.audioEnabled=false;b.blendingMode=BlendingMode.DIFFERENCE;
  check.comment='Manual check: unedited source-copy overlays should produce black across the timeline. Native AE was not available to validate this project here.';
  edit.workAreaStart=0;edit.workAreaDuration=Math.min(5,D);edit.openInViewer();
  var dest=new File(root.fsName+'/Video2_Lightweight.aep');var n=2;while(dest.exists){dest=new File(root.fsName+'/Video2_Lightweight_'+n+'.aep');n++;}
  base.locked=true; // Last write to base: comments and names are already finished.
  p.save(dest);app.endUndoGroup();begun=false;
  alert('AEP saved: '+dest.fsName+'\nOpen composition 01_EDIT_VIDEO2. Preview is Quarter; final export can be Full.');
 }catch(e){if(begun){try{app.endUndoGroup();}catch(ignored){}}alert('Setup did not finish: '+e.toString()+'\nLine '+e.line);}
}());
