// Optional: add Main to the render queue; no automatic render or overwrite.
(function(){
try {var main=null;if(!app.project)throw new Error("Open the generated AEP first.");
for(var i=1;i<=app.project.numItems;i++){var item=app.project.item(i);if(item instanceof CompItem && item.name==="Main")main=item;}
if(!main)throw new Error("Main composition not found.");
app.project.renderQueue.items.add(main);app.project.renderQueue.showWindow(true);
alert("Main added to Render Queue. Choose the output module, new filename and codec before rendering.");
}catch(e){alert(e.toString());}
}());
