from pathlib import Path
import json,math,wave,shutil
import numpy as np
from art import Draw,girl,rgb,val,keys,C
ROOT=Path(__file__).parent;FPS=24;TITLE='علامة في الزحمة'
SHOTS=[(12,'الصورة','ليلى تجرح سلمى بكلمة عن الوحمة؛ سلمى تخفيها وتبتعد.'),(10,'الطفلة التايهة','سلمى تلاحظ طفلة بتبكي وتسألها عن أمها.'),(10,'البوابة','الطفلة تجري ناحية امرأة تشبه أمها، باتجاه ممر خدمة.'),(10,'لحظة الإنقاذ','سلمى تمسك يد الطفلة قبل الممر، والموظف يوقف العربة.'),(10,'في أمان','المدرّسة تصل، وترافقهما لنقطة المساعدة؛ الأم تبحث بعيدًا.'),(13,'العلامة','الأم تصف الوحمة للأمن؛ الموظف يتعرف على سلمى.'),(13,'اللقاء','الأم تصل، تحتضن طفلتها وتشكر سلمى.'),(12,'مكان في الصورة','ليلى تعتذر وتفسح مكانًا؛ سلمى تختار الظهور في الصورة.')]

def text(d,name,content,x,y,size=46,color='ink',parent=None):return d.text(name,content,x,y,size,color,'center',parent)
def cue(d,content,start,end):
 if not any(l['name']=='SUB_Background' for l in d.c['layers']):d.rect('SUB_Background',960,994,1920,172,'ink')
 lines=content.split('\n')
 for j,line in enumerate(lines):
  t=text(d,'TXT_Dialogue',line,960,980+j*60 if len(lines)>1 else 1008,47,'paper');t['in']=round(start*24)/24;t['out']=round(end*24)/24

def fair(d,loc='hall'):
 d.rect('BG_Base',960,540,1920,1080,'cream');d.rect('Floor',960,846,1920,468,'D8CBB6')
 for x in range(160,1920,400):
  d.rect('Column',x,390,50,570,'D1C9BB');d.rect('Ceiling_Light',x+120,105,180,12,'paper',4)
 if loc=='hall':
  for x,col in [(300,'teal'),(960,'navy'),(1620,'green')]:
   d.rect('Booth_Back',x,420,510,430,col,22);d.rect('Booth_Sign',x,244,430,82,'paper',10);text(d,'Booth_Label','كتب وحكايات',x,269,44)
   for k in range(7):
    height=110+(k%3)*22;d.rect('Book',x-185+k*60,476-height/2,43,height,['pink','gold','blue'][k%3],4)
   d.rect('Counter',x,655,540,135,'B79D7F',12)
 elif loc=='service':
  d.rect('Public_Sign',420,255,620,100,'paper',15);text(d,'Public_Label','معرض الكتاب',420,285,62)
  d.rect('Service_Door',1500,450,550,510,'647281',18);d.rect('Gate_Leaf',1715,450,115,480,'blue',8)
  d.rect('Service_Sign',1500,215,470,95,'gold',12);text(d,'Service_Label','للعاملين فقط',1500,247,54)
  d.rect('Boundary',1240,800,14,190,'gold');d.path('Floor_Safety_Line',[(1240,800),(1870,800)],stroke='gold',width=12,closed=False)
 elif loc=='help':
  d.rect('Help_Wall',960,380,1750,470,'sky',25);d.rect('Help_Plate',1100,235,660,110,'teal',15);text(d,'Help_Label','نقطة المساعدة',1100,270,68,'paper')
  d.rect('Help_Desk',1420,720,620,200,'B79D7F',18);d.rect('Radio_Base',1500,580,75,105,'ink',12);d.rect('Radio_Antenna',1485,505,7,55,'ink')
 elif loc=='security':
  d.rect('Security_Wall',960,350,1700,450,'blue',22);d.rect('Security_Plate',1100,225,550,110,'navy',12);text(d,'Security_Label','استعلامات وأمن',1100,264,62,'paper')
  d.rect('Security_Desk',1350,750,700,160,'B79D7F',18);d.rect('Radio',1370,585,80,105,'ink',12);d.rect('Antenna',1360,503,7,60,'ink')
 # A few low-contrast distant crowd silhouettes without faces.
 if loc=='hall':
  for x in [80,1810]:d.ellipse('Crowd_Head',x,470,70,85,'A9A898');d.rect('Crowd_Body',x,590,95,155,'A9A898',30)

def character(d,name,x,scale=1,who='salma',emotion='neutral',cover=False,y=880):
 g=girl(d,name,x,y,scale,who,emotion,cover)
 # Two subtle head/body gestures. Every control remains a native 2D Null.
 g['head']['properties']['rotation']=keys([(0,-2),(d.c['duration']*.5,0),(d.c['duration'],0)])
 return g

def point(g,side='R',time=1,end=3):
 a,e=g['arms'][side];a['properties']['rotation']=keys([(0,0),(time,-80 if side=='R' else 80),(end,-80 if side=='R' else 80),(end+1,0)])
 e['properties']['rotation']=keys([(0,0),(time,-20 if side=='R' else 20),(end,-20 if side=='R' else 20),(end+1,0)])
def blink(d,g,name,start):
 # Eyelids are native shape overlays under the head; no zero-scale singularity.
 for x in [-30,30]:
  l=d.ellipse(name+'_Eyelid',x,-10,34,24,'skin',g['head']['id']);l['properties']['scale']=keys([(0,[100,.1]),(start,[100,.1]),(start+.125,[100,100]),(start+.25,[100,.1])])
def move(g,start,end,t0,t1):g['root']['properties']['position']=keys([(0,start),(t0,start),(t1,end)]) if t0>0 else keys([(0,start),(t1,end)])
def running(g,t0,t1,phase=0):
 # Stylized cutout run, explicit hip/knee/arm keys; no claim to an IK solver.
 for side,sign in [('L',1),('R',-1)]:
  hip=[(0,0)];knee=[(0,0)];arm=[(0,0)]
  if t0>0:hip.append((t0,0));knee.append((t0,0));arm.append((t0,0))
  for k,t in enumerate(np.arange(t0+.25,t1,.25)):
   swing=sign*(28 if k%2==0 else -28);hip.append((float(t),swing));knee.append((float(t),-max(0,swing)*1.2));arm.append((float(t),-swing*1.4))
  hip.append((t1,0));knee.append((t1,0));arm.append((t1,0))
  g['hips'][side]['properties']['rotation']=keys(hip);g['knees'][side]['properties']['rotation']=keys(knee);g['arms'][side][0]['properties']['rotation']=keys(arm)
def cart(d,x,y):
 g=d.null('PROP_Book_Cart',(x,y));pid=g['id']
 for cx in [-95,95]:d.ellipse('Cart_Wheel',cx,48,55,55,'ink',pid)
 d.rect('Cart_Base',0,7,270,40,'navy',8,pid);d.rect('Cart_Handle',140,-85,20,190,'ink',6,pid)
 for k,col in enumerate(['pink','gold','blue','teal']):d.rect('Box_of_Books',0,-35-k*50,225,43,col,5,pid)
 return g

comps=[];continuity=[]
for i,(dur,title,desc) in enumerate(SHOTS,1):
 d=Draw('Shot%02d'%i,dur)
 if i==1:
  fair(d);s=character(d,'Salma',780,1.05);l=character(d,'Laila',1120,1.05,'bully');character(d,'Classmate',1480,.96,'mira')
  text(d,'TXT_Film_Title',TITLE,960,115,77)
  point(l,'L',1,3);s['head']['properties']['rotation']=keys([(0,0),(3,0),(5,7),(dur,7)])
  hair=d.path('Salma_Hair_Front',[(-4,-85),(65,-85),(88,-20),(79,102),(27,88),(23,18)],'hair',parent=s['head']['id']);hair['properties']['opacity']=keys([(0,0),(4,0),(5,100)])
  move(s,[780,880],[430,880],7,10);blink(d,s,'Salma',2)
  cue(d,'ليلى: إنتِ هتتصوري كده؟',.5,3.3);cue(d,'طب داري اللي في وشك ده.',3.3,6.7);cue(d,'ضحكة قصيرة... وسلمى تنسحب من الصورة.',7,12)
 elif i==2:
  fair(d);s=character(d,'Salma',1130,1.1,emotion='sad',cover=True);kid=character(d,'Child',740,.64,'mira','sad')
  s['head']['properties']['rotation']=keys([(0,0),(2,9),(dur,9)]);point(s,'L',3,5)
  for x in [-30,30]:tear=d.ellipse('Child_Tear',x,28,10,20,'blue',kid['head']['id']);tear['properties']['opacity']=keys([(0,0),(1,100),(6,100),(8,0)])
  cue(d,'سلمى: إنتِ تايهة؟',1,5);cue(d,'الطفلة: مش لاقية ماما.',5,10)
 elif i==3:
  fair(d,'service');child=character(d,'Child',570,.64,'mira','neutral');s=character(d,'Salma',280,1.05,cover=True)
  # Safe public side is x<1240. Child stops at the boundary; no vehicle impact.
  move(child,[570,880],[1170,880],1,6);running(child,1,6)
  move(s,[280,880],[900,880],2,8);running(s,2,8)
  trolley=cart(d,1740,795);trolley['properties']['position']=keys([(0,[1740,795]),(3,[1740,795]),(9,[1430,795]),(10,[1430,795])])
  cue(d,'الطفلة: ماما!',0,2.2);cue(d,'سلمى: استني! مش من هنا!',2.2,7);cue(d,'بوابة خدمة... وعربة نقل بتقترب.',7,10)
 elif i==4:
  fair(d,'service');s=character(d,'Salma',940,1.05,cover=False);child=character(d,'Child',1170,.64,'mira','sad');worker=character(d,'Worker',1510,1.18,'teacher')
  # Extend Salma's right arm to the child's left hand; retain separate shoulder/elbow controls.
  a,e=s['arms']['R'];a['properties']['rotation']=keys([(0,0),(.75,-85),(5,-85),(6,-35),(10,-35)]);e['properties']['rotation']=keys([(0,0),(.75,-5),(5,-5),(6,0),(10,0)])
  child['arms']['L'][0]['properties']['rotation']=keys([(0,0),(.75,75),(5,75),(6,20),(10,20)])
  move(child,[1170,880],[1110,880],1,4);trolley=cart(d,1650,795);trolley['properties']['position']=keys([(0,[1650,795]),(1.5,[1480,795]),(10,[1480,795])])
  point(worker,'L',1,3)
  book=d.rect('PROP_Falling_Book',1450,610,90,25,'red',3);book['properties']['position']=keys([(0,[1450,610]),(1,[1450,610]),(2,[1400,835]),(10,[1400,835])]);book['properties']['rotation']=keys([(0,0),(1,0),(2,25)])
  gate=d.rect('Closing_Gate',1290,490,60,490,'blue',8);gate['properties']['scale']=keys([(0,[10,100]),(3,[10,100]),(5,[100,100])])
  cue(d,'الموظف: استنوا مكانكم!',0,3);cue(d,'سلمى: خليكي معايا... إنتِ بأمان.',3,10)
 elif i==5:
  fair(d,'help');s=character(d,'Salma',600,1.05);child=character(d,'Child',840,.64,'mira');t=character(d,'Teacher',1120,1.16,'teacher');character(d,'Help_Staff',1560,1.08,'mom')
  t['head']['properties']['rotation']=keys([(0,0),(2,-5),(dur,-5)]);point(t,'L',2,5)
  cue(d,'المدرّسة: هنفضل معاها هنا لحد ما نوصل لأهلها.',0,6);cue(d,'وفي ناحية تانية... أمها لسه بتدور.',6,10)
 elif i==6:
  fair(d,'security');mother=character(d,'Mother',620,1.25,'mom','sad');character(d,'Security',1430,1.16,'teacher')
  # First half at security, second half reveals the matching mark at help desk.
  cue(d,'الأم: كانت معاها بنت بشعر غامق...',0,4.5);cue(d,'وعندها علامة حمرا جنب عينها.',4.5,8.5);cue(d,'صوت اللاسلكي: أيوه، هما عند نقطة المساعدة.',8.5,13)
  # Separate editable identification inset, not surveillance zoom or a supernatural effect.
  inset=d.null('IDENTIFICATION_Inset',(1070,520));iid=inset['id'];inset['properties']['opacity']=keys([(0,0),(7,0),(8,100)])
  d.rect('Inset_Paper',0,0,330,330,'paper',25,iid)
  d.ellipse('Inset_Hair',0,-5,190,210,'hair',iid);d.ellipse('Inset_Face',0,6,150,180,'skin',iid)
  d.path('Inset_Birthmark',[(15,-37),(38,-46),(58,-31),(52,-5),(61,24),(43,47),(23,39),(12,16)],'red',parent=iid)
  for xx in [-30,30]:d.ellipse('Inset_Eye',xx,-9,12,16,'ink',iid)
  text(d,'Inset_Label','سلمى',0,140,48,'ink',iid)
 elif i==7:
  fair(d,'help');s=character(d,'Salma',510,1.05,emotion='neutral');child=character(d,'Child',950,.64,'mira','happy');mother=character(d,'Mother',1180,1.17,'mom','happy');character(d,'Teacher',1550,1.06,'teacher')
  move(mother,[1330,880],[1120,880],0,4);mother['arms']['L'][0]['properties']['rotation']=keys([(0,0),(3,65),(7,65),(10,0)])
  child['arms']['R'][0]['properties']['rotation']=keys([(0,0),(3,-60),(7,-60),(10,0)])
  move(child,[950,880],[1000,880],1,4);blink(d,s,'Salma',8)
  cue(d,'الأم: حبيبتي! كنتِ فين؟',0,4);cue(d,'الموظف: وصفك لسلمى وصلنا ليكم بسرعة.',4,8.5);cue(d,'الأم: شكرًا إنك فضلتي جنب بنتي.',8.5,13)
 elif i==8:
  fair(d);s=character(d,'Salma',620,1.08,emotion='neutral');l=character(d,'Laila',1130,1.06,'bully','sad');character(d,'Classmate',1500,.98,'mira','happy')
  move(l,[1130,880],[1230,880],6,8);move(s,[620,880],[865,880],8,10)
  s['head']['properties']['rotation']=keys([(0,5),(5,5),(9,0)]);l['head']['properties']['rotation']=keys([(0,7),(5,0),(12,0)])
  text(d,'TXT_End_Title',TITLE,960,118,77)
  cue(d,'ليلى: أنا غلطت لما قلت لك تخبيها.',0,5);cue(d,'فيه مكان جنبنا... لو حابة.',5,8);cue(d,'الاختلاف مش دعوة للأذى.',8,12)
 # Important film action is cutout keyframing, not flattened video or a proprietary rig plugin.
 d.c['markers']=[{'time':0,'text':f'STB{i:02d} | {title} | {desc}'}];comps.append(d.finish())

start=0;shots=[];main={'id':'Main','width':1920,'height':1080,'fps':24,'duration':90,'layers':[],'markers':[]}
for i,((dur,title,desc),c) in enumerate(zip(SHOTS,comps),1):
 main['layers'].append({'id':f'SHOT_{i:02d}','name':f'{i:02d}_{title}','type':'precomp','source':c['id'],'start':start,'in':start,'out':start+dur,'properties':{'position':val([960,540]),'anchor':val([960,540]),'scale':val([100,100])}})
 main['markers'].append({'time':start,'text':f'STB{i:02d} | {title}'})
 shots.append({'id':f'STB{i:02d}','comp':c['id'],'layer':f'SHOT_{i:02d}','inFrame':start*24,'outFrame':(start+dur)*24,'reference':f'storyboard/shot_{i:02d}.png','reviewFrames':[start*24,(start+dur//2)*24,(start+dur)*24-1]});start+=dur
assert start==90
main['layers'].append({'id':'Audio','name':'AUDIO_Original_Music_And_Foley_NO_VOICES','type':'footage','source':'Soundtrack','in':0,'out':90,'properties':{}})
cm={'workingSpace':'sRGB IEC61966-2.1','bitsPerChannel':16,'linearize':False}
scene={'version':1,'name':'Alama_Fi_Elzahma_Editable_90s','main':'Main','strictFonts':True,'colorManagement':cm,'assets':[{'id':'Soundtrack','path':'assets/soundtrack.wav'}],'comps':[main]+comps}
colors=[];joints=[]
for c in comps:
 for l in c['layers']:
  if l['name'].endswith('_Birthmark_FIXED'):colors.append({'comp':c['id'],'layer':l['id'],'property':'fill','rgb':rgb('red')})
  if any(n in l['name'] for n in ['Shoulder_','Elbow_','Hip_','Knee_']):joints.append({'comp':c['id'],'layer':l['id'],'parent':l.get('parent'),'pivot':[0,0],'minRotation':-145,'maxRotation':145,'allowMirror':False,'allowNonUniformScale':False})
prod={'version':1,'width':1920,'height':1080,'fps':24,'frames':2160,'colorManagement':cm,'shots':shots,'colors':colors,'joints':joints}
(ROOT/'scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2));(ROOT/'production.json').write_text(json.dumps(prod,ensure_ascii=False,indent=2));(ROOT/'shotlist.json').write_text(json.dumps(SHOTS,ensure_ascii=False,indent=2))
# Original guide music + designed foley. This is not voiced dialogue or lip-sync.
a=ROOT/'assets';a.mkdir(exist_ok=True);sr=44100;audio=np.zeros(sr*90,dtype=np.float32);rng=np.random.default_rng(23)
for onset in np.arange(0,90,2.5):
 notes=([220,261.63,329.63] if onset<22 else [196,220,293.66] if onset<42 else [261.63,329.63,392])
 for j,f in enumerate(notes):
  off=onset+j*.35;n=min(int(3*sr),len(audio)-int(off*sr));t=np.arange(n)/sr;audio[int(off*sr):int(off*sr)+n]+=.024*np.sin(2*np.pi*f*t)*(1-np.exp(-t*30))*np.exp(-t*1.8)
for off,amp,decay in [(32.8,.12,65),(35,.06,70),(77.7,.08,90),(88,.1,80)]:
 n=int(.18*sr);t=np.arange(n)/sr;audio[int(off*sr):int(off*sr)+n]+=rng.normal(0,1,n)*np.exp(-t*decay)*amp
# Wheel friction, radio static, room tone; no synthetic spoken words.
for off,length,amp in [(27,4,.007),(59,2,.012)]:
 n=int(length*sr);t=np.arange(n)/sr;env=np.sin(np.linspace(0,np.pi,n))**2;audio[int(off*sr):int(off*sr)+n]+=rng.normal(0,1,n)*env*amp
fade=np.minimum(np.arange(len(audio))/sr/1.5,(len(audio)-np.arange(len(audio)))/sr/2);audio*=np.clip(fade,0,1)
with wave.open(str(a/'soundtrack.wav'),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(sr);f.writeframes((np.clip(audio,-1,1)*32767).astype('<i2').tobytes())
print('Created',len(comps),'shots,',sum(len(c['layers']) for c in comps),'editable layers, 2160 frames/90 seconds.')
