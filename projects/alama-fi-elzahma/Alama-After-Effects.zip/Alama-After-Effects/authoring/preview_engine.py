from pathlib import Path
import math,json,subprocess,sys,time
from PIL import Image,ImageDraw,ImageFont
TITLE='علامة في الزحمة'
SHOTS=[]
ROOT=Path(__file__).parent;S=json.loads((ROOT/'scene.json').read_text());COMPS={c['id']:c for c in S['comps']};SIZE=(960,540);FACTOR=.5
FONT='/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf'

def evaluate(p,t,default):
 if not p:return default
 if 'value'in p:return p['value']
 a=p['keys']
 if t<=a[0]['time']:return a[0]['value']
 for k,n in zip(a,a[1:]):
  if k['time']<=t<=n['time']:
   f=(t-k['time'])/(n['time']-k['time'])
   if k.get('ease')=='hold':return k['value']
   if k.get('ease','bezier')=='bezier':f=f*f*(3-2*f)
   x,y=k['value'],n['value'];return [i+(j-i)*f for i,j in zip(x,y)] if isinstance(x,list) else x+(y-x)*f
 return a[-1]['value']
def mm(a,b):
 aa,ab,ac,ad,ae,af=a;ba,bb,bc,bd,be,bf=b
 return (aa*ba+ac*bb,ab*ba+ad*bb,aa*bc+ac*bd,ab*bc+ad*bd,aa*be+ac*bf+ae,ab*be+ad*bf+af)
def transform(m,p):return (m[0]*p[0]+m[2]*p[1]+m[4],m[1]*p[0]+m[3]*p[1]+m[5])
def color(v,a=1):return tuple(round(c*255) for c in v)+(int(max(0,min(1,a))*255),)
textcache={};geomcache={};fontcache={}
def text_bitmap(l):
 key=(l['text'],l['fontSize'],tuple(l['color']),l['align'])
 if key in textcache:return textcache[key]
 f=fontcache.setdefault(l['fontSize'],ImageFont.truetype(FONT,l['fontSize']))
 tmp=Image.new('RGBA',(1900,300));dr=ImageDraw.Draw(tmp)
 anchor='ms' if l['align']=='center' else 'rs' if l['align']=='right' else 'ls'
 x=950 if l['align']=='center' else 1850 if l['align']=='right' else 50
 dr.text((x,170),l['text'],font=f,fill=color(l['color']),anchor=anchor,direction='rtl',language='ar',spacing=12)
 box=tmp.getbbox();im=tmp.crop(box);offset=(box[0]-x,box[1]-170)
 textcache[key]=(im,offset);return im,offset

def frame(comp,t,outsize=SIZE):
 scale=outsize[0]/1920;image=Image.new('RGB',outsize,'#243343');draw=ImageDraw.Draw(image,'RGBA');ls={l['id']:l for l in comp['layers']};memo={}
 def world(l):
  if l['id']in memo:return memo[l['id']]
  p=l['properties'];pos=evaluate(p.get('position'),t,[0,0]);s=evaluate(p.get('scale'),t,[100,100]);a=math.radians(evaluate(p.get('rotation'),t,0));anchor=evaluate(p.get('anchor'),t,[0,0]);co=math.cos(a);si=math.sin(a)
  m=(co*s[0]/100,si*s[0]/100,-si*s[1]/100,co*s[1]/100,0,0);ap=transform(m,anchor);m=m[:4]+(pos[0]-ap[0],pos[1]-ap[1]);alpha=evaluate(p.get('opacity'),t,100)/100
  if l.get('parent'):
   par,pa=world(ls[l['parent']]);m=mm(par,m);alpha*=pa
  memo[l['id']]=(m,alpha);return m,alpha
 for l in reversed(comp['layers']):
  if l['type']=='null' or not l.get('in',0)<=t<l.get('out',comp['duration']):continue
  m,alpha=world(l)
  if alpha<=0:continue
  if l['type']=='shape':
   g=l['geometry'];typ=g['type'];key=json.dumps(g,sort_keys=True)
   if key not in geomcache:
    if typ=='ellipse':pts=[(g['size'][0]/2*math.cos(i*math.tau/48),g['size'][1]/2*math.sin(i*math.tau/48)) for i in range(48)]
    elif typ=='rect':
     w,h=g['size'];r=min(g.get('radius',0),w/2,h/2)
     if r:
      pts=[]
      for cx,cy,deg in [(w/2-r,-h/2+r,-90),(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180)]:
       pts.extend((cx+r*math.cos(math.radians(deg+k*90/8)),cy+r*math.sin(math.radians(deg+k*90/8))) for k in range(9))
     else:pts=[(-w/2,-h/2),(w/2,-h/2),(w/2,h/2),(-w/2,h/2)]
    else:pts=g['vertices']
    geomcache[key]=pts
   pts=[tuple(x*scale for x in transform(m,p)) for p in geomcache[key]]
   if 'fill'in l:draw.polygon(pts,fill=color(evaluate(l['properties'].get('fill'),t,l['fill']),alpha))
   if 'stroke'in l:
    stroke=l['stroke'];closed=g.get('closed',True);path=pts+[pts[0]] if closed else pts
    width=max(1,round(stroke['width']*scale*math.hypot(m[0],m[1])));draw.line(path,fill=color(stroke['color'],alpha),width=width,joint='curve')
  elif l['type']=='text':
   bitmap,off=text_bitmap(l);sx=math.hypot(m[0],m[1])*scale;sy=math.hypot(m[2],m[3])*scale
   size=(max(1,round(bitmap.width*sx)),max(1,round(bitmap.height*sy)));bit=bitmap.resize(size,Image.Resampling.LANCZOS)
   if alpha<.999:bit.putalpha(bit.getchannel('A').point(lambda v:int(v*alpha)))
   x,y=transform(m,off);image.paste(bit,(round(x*scale),round(y*scale)),bit)
 return image
