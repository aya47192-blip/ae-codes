from pathlib import Path
import math,json
from fix_contact import solve
from preview_engine import evaluate
p=Path(__file__).parent;s=json.loads((p/'scene.json').read_text());c=next(c for c in s['comps'] if c['id']=='Shot07');ls={l['name']:l for l in c['layers']}
for name,side,scale in [('Mother','L',1.17),('Child','R',.64)]:
 upper=[{'time':0,'value':0,'ease':'bezier'}];lower=[{'time':0,'value':0,'ease':'bezier'}]
 for f in range(72,169):
  t=f/24;root=ls[name+'_ROOT'];x,y=evaluate(root['properties']['position'],t,[0,0]);a,b=solve(x,y,scale,side,(1020,665))
  upper.append({'time':t,'value':a,'ease':'linear'});lower.append({'time':t,'value':b,'ease':'linear'})
 for seq in [upper,lower]:seq.append({'time':9,'value':0,'ease':'bezier'})
 ls[name+'_Shoulder_'+side]['properties']['rotation']={'keys':upper};ls[name+'_Elbow_'+side]['properties']['rotation']={'keys':lower}
ls['Mother_HEAD']['properties']['rotation']={'keys':[{'time':0,'value':0,'ease':'bezier'},{'time':3,'value':-8,'ease':'bezier'},{'time':8,'value':-8,'ease':'bezier'},{'time':10,'value':0,'ease':'bezier'}]}
child=[l for l in c['layers'] if l['name'].startswith('Child_')];c['layers']=[l for l in c['layers'] if not l['name'].startswith('Child_')]
index=next(i for i,l in enumerate(c['layers']) if l['name']=='SUB_Background')+1;c['layers'][index:index]=child
(p/'scene.json').write_text(json.dumps(s,ensure_ascii=False,indent=2));spec=json.loads((p/'production.json').read_text())
for j in spec['joints']:
 if j['comp']=='Shot07':j['minRotation']=-180;j['maxRotation']=180
(p/'production.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2))
print('Adjusted adult styling, reunion contact poses and child foreground order.')
