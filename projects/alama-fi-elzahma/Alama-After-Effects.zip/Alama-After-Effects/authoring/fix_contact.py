import math,json
from pathlib import Path
p=Path(__file__).parent;scene=json.loads((p/'scene.json').read_text());c=next(c for c in scene['comps'] if c['id']=='Shot04');layers={l['name']:l for l in c['layers']}
def solve(x,y,s,side,target):
 dx=(target[0]-x)/s-(77 if side=='R' else -77);dy=(target[1]-y)/s+287
 L1,L2=80,77;cs=(dx*dx+dy*dy-L1*L1-L2*L2)/(2*L1*L2);assert -1<=cs<=1
 options=[]
 for sign in [-1,1]:
  elbow=sign*math.acos(cs);upper=math.atan2(dy,dx)-math.atan2(L2*math.sin(elbow),L1+L2*math.cos(elbow))-math.pi/2
  upper=(math.degrees(upper)+180)%360-180;elbow=math.degrees(elbow);options.append((upper,elbow))
 return min(options,key=lambda a:max(abs(a[0]),abs(a[1])))
def pose(name,side,s,xfunction):
 upper=[];lower=[]
 upper.append({'time':0,'value':0,'ease':'bezier'});lower.append({'time':0,'value':0,'ease':'bezier'})
 for f in range(18,121):
  t=f/24;a,b=solve(xfunction(t),880,s,side,(1080,650))
  upper.append({'time':t,'value':a,'ease':'linear'});lower.append({'time':t,'value':b,'ease':'linear'})
 for seq in [upper,lower]:seq.append({'time':6,'value':0,'ease':'bezier'})
 layers[name+'_Shoulder_'+side]['properties']['rotation']={'keys':upper};layers[name+'_Elbow_'+side]['properties']['rotation']={'keys':lower}
 # Verify world hand centers at every contact key.
 worst=0
 for a,b in zip(upper[1:-1],lower[1:-1]):
  t=a['time'];u=math.radians(a['value']);e=math.radians(b['value']);xx=xfunction(t)+(77 if side=='R' else -77)*s-80*s*math.sin(u)-77*s*math.sin(u+e);yy=880-287*s+80*s*math.cos(u)+77*s*math.cos(u+e)
  worst=max(worst,math.hypot(xx-1080,yy-650))
 print(name,'baked contact residual',worst,'pixels; angular range',min(k['value'] for k in upper+lower),max(k['value'] for k in upper+lower))
 assert worst<.001
pose('Salma','R',1.05,lambda t:940)
def childx(t):
 f=min(1,max(0,(t-1)/3));return 1170-60*f*f*(3-2*f)
pose('Child','L',.64,childx)
(p/'scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2))
prod=json.loads((p/'production.json').read_text())
for j in prod['joints']:
 if j['comp']=='Shot04':j['minRotation']=-180;j['maxRotation']=180
(p/'production.json').write_text(json.dumps(prod,ensure_ascii=False,indent=2))
