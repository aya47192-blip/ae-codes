from pathlib import Path
import json,subprocess
from PIL import Image,ImageDraw,ImageFont
from preview_engine import frame,COMPS,ROOT,FONT
shots=json.loads((ROOT/'shotlist.json').read_text());board=ROOT/'storyboard';board.mkdir(exist_ok=True)
review=[7,5,6,2.5,4,10,6,10]
for n,(item,t) in enumerate(zip(shots,review),1):frame(COMPS[f'Shot{n:02d}'],t).save(board/f'shot_{n:02d}.png')
canvas=Image.new('RGB',(1920,1320),'#f5eedc');draw=ImageDraw.Draw(canvas);font=ImageFont.truetype(FONT,36)
for i,item in enumerate(shots):
 im=Image.open(board/f'shot_{i+1:02d}.png').resize((640,360));x=i%3*640;y=i//3*440;canvas.paste(im,(x,y));draw.text((x+610,y+413),f'{i+1:02d}  {item[1]}',font=font,anchor='rs',direction='rtl',fill='#243343')
canvas.save(ROOT/'storyboard.png')
video=ROOT/'preview-90s.mp4';cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x540','-r','24','-i','-','-i',str(ROOT/'assets/soundtrack.wav'),'-c:v','libx264','-threads','2','-preset','fast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-ar','44100','-ac','1','-t','90','-movflags','+faststart','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',str(video)]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
try:
 for n,item in enumerate(shots,1):
  c=COMPS[f'Shot{n:02d}']
  for f in range(int(c['duration']*24)):p.stdin.write(frame(c,f/24).tobytes())
  print('Rendered shot',n,flush=True)
 p.stdin.close();assert p.wait()==0
except BaseException:p.kill();raise
print('Surrogate preview complete; not a native AE render.',flush=True)
