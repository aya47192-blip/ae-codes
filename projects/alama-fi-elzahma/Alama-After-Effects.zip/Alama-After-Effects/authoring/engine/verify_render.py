#!/usr/bin/env python3
"""Inspect and fully decode an actual render. Metadata checks do not establish visual quality."""
import argparse,json,math,subprocess,shutil
from fractions import Fraction
from pathlib import Path

def run(args):
    return subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=False)

def inspect(path,spec):
    errors=[];checks={};result={'passed':False,'visual_review':'unverified','storyboard_match':'unverified','rig_review':'unverified'}
    required=['width','height','fps','frames','codec']
    if not isinstance(spec,dict) or not all(k in spec for k in required):raise ValueError('Render spec needs width,height,fps,frames,codec')
    if not all(type(spec[k]) is int and spec[k]>0 for k in ['width','height','frames']) or not isinstance(spec['codec'],str) or not spec['codec']:raise ValueError('Invalid render requirements')
    fps=float(spec['fps']);
    if not math.isfinite(fps) or fps<=0:raise ValueError('Invalid fps')
    if not shutil.which('ffprobe') or not shutil.which('ffmpeg'):raise RuntimeError('ffprobe and ffmpeg are required')
    probe=run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(path.resolve())])
    if probe.returncode:result['errors']=['ffprobe failed: '+probe.stderr[-4000:]];return result
    data=json.loads(probe.stdout);videos=[s for s in data['streams'] if s['codec_type']=='video'];audios=[s for s in data['streams'] if s['codec_type']=='audio']
    if len(videos)!=1:result['errors']=['Expected exactly one video stream'];return result
    v=videos[0]
    def ck(name,ok):checks[name]=bool(ok);errors.extend([] if ok else [name])
    ck('dimensions',v.get('width')==spec['width'] and v.get('height')==spec['height'])
    try:actual_fps=float(Fraction(v.get('avg_frame_rate','0/1')))
    except (ValueError,ZeroDivisionError):actual_fps=0
    ck('fps',abs(actual_fps-fps)<.001)
    ck('decoded_frame_count',str(v.get('nb_read_frames'))==str(spec['frames']))
    ck('codec',v.get('codec_name')==spec['codec'])
    try:duration=float(v.get('duration',data.get('format',{}).get('duration','nan')))
    except ValueError:duration=float('nan')
    ck('duration',math.isfinite(duration) and abs(duration-spec['frames']/fps)<=max(.5/fps,.002))
    if 'pixelFormats' in spec:ck('pixel_format',v.get('pix_fmt') in spec['pixelFormats'])
    for key,tag in [('colorSpace','color_space'),('colorTransfer','color_transfer'),('colorPrimaries','color_primaries'),('colorRange','color_range')]:
        if key in spec:ck(key,v.get(tag)==spec[key])
    if 'audio' in spec:
        a=spec['audio'];ck('audio_presence',bool(audios) if a.get('required') else not audios if a.get('forbidden') else True)
        if audios:
            av=audios[0]
            if 'sampleRate' in a:ck('audio_sample_rate',str(av.get('sample_rate'))==str(a['sampleRate']))
            if 'channels' in a:ck('audio_channels',av.get('channels')==a['channels'])
            if a.get('matchDuration'):
                try:ad=float(av['duration'])
                except (KeyError,ValueError):ad=float('nan')
                ck('audio_duration',math.isfinite(ad) and abs(ad-spec['frames']/fps)<=a.get('toleranceSeconds',.05))
    timestamps=run(['ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','csv=p=0',str(path.resolve())])
    times=[]
    if timestamps.returncode==0:
        for line in timestamps.stdout.splitlines():
            first=line.split(',')[0].strip()
            if first:
                try:times.append(float(first))
                except ValueError:pass
    ck('constant_frame_cadence',len(times)==spec['frames'] and all(math.isfinite(t) for t in times) and all(abs((b-a)-1/fps)<max(.0001,.001/fps) for a,b in zip(times,times[1:])))
    decode=run(['ffmpeg','-v','error','-xerror','-i',str(path.resolve()),'-map','0:v:0','-map','0:a?','-f','null','-'])
    ck('full_decode',decode.returncode==0)
    result.update(passed=not errors,checks=checks,errors=errors,observed={'video':v,'audio':audios},decode_errors=decode.stderr[-4000:])
    result['scope']='Metadata and decode integrity only. Listen/watch and compare frames to storyboard; valid holds/black shots must not be auto-rejected.'
    return result

def contact_sheet(path,frames,fps,out):
    from PIL import Image,ImageDraw
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        images=[]
        for n,frame in enumerate(frames):
            target=Path(td)/f'{n}.png'
            r=run(['ffmpeg','-v','error','-i',str(path.resolve()),'-vf',f'select=eq(n\\,{frame}),scale=480:-1','-frames:v','1',str(target)])
            if r.returncode or not target.exists():raise RuntimeError('Could not extract frame '+str(frame))
            image=Image.open(target).convert('RGB');images.append((frame,image))
        width=480;cellh=max(im.height for _,im in images)+30;cols=min(3,len(images));rows=math.ceil(len(images)/cols)
        sheet=Image.new('RGB',(cols*width,rows*cellh),'#222222');draw=ImageDraw.Draw(sheet)
        for i,(frame,image) in enumerate(images):
            x=(i%cols)*width;y=(i//cols)*cellh;sheet.paste(image,(x,y));draw.text((x+8,y+image.height+5),f'frame {frame} / {frame/fps:.3f}s',fill='white')
        sheet.save(out)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('video',type=Path);p.add_argument('requirements',type=Path);p.add_argument('--report',type=Path,required=True);p.add_argument('--contact-sheet',type=Path);a=p.parse_args()
    try:
        if a.report.exists() or (a.contact_sheet and a.contact_sheet.exists()):raise ValueError('Choose new report/contact-sheet filenames')
        spec=json.loads(a.requirements.read_text());result=inspect(a.video,spec)
        if a.contact_sheet and result.get('observed'):
            frames=spec.get('reviewFrames',[0,spec['frames']//2,spec['frames']-1])
            if not isinstance(frames,list) or not frames or not all(type(f) is int and 0<=f<spec['frames'] for f in frames):raise ValueError('Invalid reviewFrames')
            contact_sheet(a.video,frames,float(spec['fps']),a.contact_sheet)
            result['contact_sheet']=str(a.contact_sheet)
        a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(result,indent=2)+'\n');print('Technical render check: '+('passed' if result['passed'] else 'failed')+'; visual/rig review remains unverified')
        raise SystemExit(0 if result['passed'] else 1)
    except (ValueError,RuntimeError,OSError) as e:p.exit(1,str(e)+'\n')
