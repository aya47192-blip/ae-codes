#!/usr/bin/env python3
"""Validate a scene and package a portable editable After Effects JSX builder. Stdlib only."""
import argparse, json, math, re, shutil, hashlib
from pathlib import Path, PurePosixPath

class SceneError(ValueError): pass

def require(ok, message):
    if not ok: raise SceneError(message)

def number(v, lo=-1e7, hi=1e7):
    return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and lo<=v<=hi

def vec(v,n,lo=-1e7,hi=1e7):
    return isinstance(v,list) and len(v)==n and all(number(x,lo,hi) for x in v)

def fields(obj, allowed, label):
    require(isinstance(obj,dict),f'{label}: expected object')
    require(not set(obj)-set(allowed.split()),f'{label}: unknown fields {set(obj)-set(allowed.split())}')

def ident(v):
    return isinstance(v,str) and bool(re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,79}',v)) and v not in {'constructor','prototype','__proto__','toString','hasOwnProperty','valueOf'}

def path_shape(v):
    fields(v,'type vertices inTangents outTangents closed','path')
    if 'type' in v: require(v['type']=='path','Invalid path type')
    require(isinstance(v.get('vertices'),list) and 2<=len(v['vertices'])<=5000,'Path needs 2–5000 vertices')
    require(all(vec(p,2) for p in v['vertices']),'Invalid path vertices')
    for k in ['inTangents','outTangents']:
        if k in v: require(isinstance(v[k],list) and len(v[k])==len(v['vertices']) and all(vec(p,2) for p in v[k]),'Invalid path tangents')
    if 'closed' in v: require(isinstance(v['closed'],bool),'closed must be boolean')

def acyclic(edges,label):
    active=set();done=set()
    def visit(n):
        require(n not in active,f'{label}: cycle at {n}')
        if n in done:return
        active.add(n)
        for dep in edges[n]:visit(dep)
        active.remove(n);done.add(n)
    for n in edges:visit(n)

def validate(s):
    fields(s,'version name main assets comps colorManagement strictFonts','scene')
    require(type(s.get('version')) is int and s.get('version')==1,'Scene version must be 1')
    require(isinstance(s.get('name'),str) and 0<len(s['name'])<=200,'Missing scene name')
    require(isinstance(s.get('comps'),list) and 1<=len(s['comps'])<=100,'Need 1–100 compositions')
    if 'strictFonts' in s: require(isinstance(s['strictFonts'],bool),'strictFonts must be boolean')
    if 'colorManagement' in s:
        cm=s['colorManagement'];fields(cm,'workingSpace bitsPerChannel linearize','colorManagement')
        require(isinstance(cm.get('workingSpace'),str) and bool(cm['workingSpace']),'workingSpace required')
        require(type(cm.get('bitsPerChannel')) is int and cm['bitsPerChannel'] in [8,16,32],'bitsPerChannel must be 8,16,32')
        require(isinstance(cm.get('linearize'),bool),'linearize must be boolean')
    s.setdefault('assets',[]);require(isinstance(s['assets'],list),'assets must be list')
    aids=set()
    for a in s['assets']:
        fields(a,'id path','asset');require(ident(a.get('id')) and a['id'] not in aids,'Invalid/duplicate asset id');aids.add(a['id'])
        p=a.get('path');require(isinstance(p,str) and p.startswith('assets/') and not p.endswith('/') and '' not in p.split('/') and '\\' not in p and ':' not in p and all(x not in ('..','.') for x in p.split('/')) and not PurePosixPath(p).is_absolute(),'Assets must use safe relative assets/... paths')
    comps={}
    for c in s['comps']:
        fields(c,'id width height fps duration background layers markers','comp')
        require(ident(c.get('id')) and c['id'] not in comps,'Invalid/duplicate comp id');comps[c['id']]=c
        for k in ['width','height']:require(isinstance(c.get(k),int) and not isinstance(c[k],bool) and 4<=c[k]<=30000,f'Invalid {k}')
        require(number(c.get('fps'),1,99),'fps must be 1–99');require(number(c.get('duration'),.1,10800),'Invalid duration')
        if 'background' in c:require(vec(c['background'],3,0,1),'Invalid background')
        require(isinstance(c.get('layers'),list) and len(c['layers'])<=2000,'layers must be list, maximum 2000')
    require(ident(s.get('main')) and s.get('main') in comps,'main must identify a comp')
    edges={k:[] for k in comps}
    for c in s['comps']:
        ids={}
        for l in c['layers']:
            fields(l,'id name type parent geometry fill stroke trim text font fontSize color align source start in out motionBlur properties','layer')
            require(ident(l.get('id')) and l['id'] not in ids,'Invalid/duplicate layer id');ids[l['id']]=l
            require(isinstance(l.get('name'),str) and bool(l['name']),'Layer needs a name')
            typ=l.get('type');require(typ in ['shape','text','null','solid','footage','precomp'],'Unsupported layer type')
            type_fields={'shape':{'geometry','fill','stroke','trim'},'text':{'text','font','fontSize','color','align'},'solid':{'color'},'null':set(),'footage':{'source'},'precomp':{'source'}}
            common={'id','name','type','parent','start','in','out','motionBlur','properties'}
            require(not set(l)-(common|type_fields[typ]),'Fields not supported on '+typ)
            for k in ['motionBlur','trim']:
                if k in l:require(isinstance(l[k],bool),f'{k} must be boolean')
            if typ=='shape':
                g=l.get('geometry');require(isinstance(g,dict),'Shape needs geometry')
                if g.get('type') in ['rect','ellipse']:
                    fields(g,'type size radius','geometry');require(vec(g.get('size'),2,.01,60000),'Invalid size')
                    if 'radius' in g:require(g['type']=='rect' and number(g['radius'],0,30000),'radius is only supported on rectangles')
                else:require(g.get('type')=='path','Unknown geometry type');path_shape(g)
                require('fill' in l or 'stroke' in l,'Shape needs fill or stroke')
                if 'fill' in l:require(vec(l['fill'],3,0,1),'Invalid fill')
                if 'stroke' in l:
                    fields(l['stroke'],'color width','stroke');require(vec(l['stroke'].get('color'),3,0,1) and number(l['stroke'].get('width'),.01,1000),'Invalid stroke')
            else:
                require(not any(k in l for k in ['geometry','fill','stroke','trim']),'Shape fields on non-shape layer')
            if typ=='text':
                require(isinstance(l.get('text'),str),'Text needs text string')
                if 'font' in l:require(isinstance(l['font'],str) and bool(l['font']),'Invalid font')
                if 'fontSize' in l:require(number(l['fontSize'],1,2000),'Invalid fontSize')
                if 'align' in l:require(l['align'] in ['left','center','right'],'Invalid alignment')
            if typ in ['text','solid'] and 'color' in l:require(vec(l['color'],3,0,1),'Invalid color')
            if typ=='solid':require('color' in l,'Solid needs color')
            if typ=='footage':require(ident(l.get('source')) and l.get('source') in aids,'Unknown asset source')
            if typ=='precomp':
                require(ident(l.get('source')) and l.get('source') in comps,'Unknown precomp source');edges[c['id']].append(l['source'])
            for k in ['start','in','out']:
                if k in l:require(number(l[k],0,c['duration']),f'Invalid {k}')
            require(l.get('in',0)<l.get('out',c['duration']),'Layer in must precede out')
            l.setdefault('properties',{});require(isinstance(l['properties'],dict),'properties must be object')
            for key,spec in l['properties'].items():
                require(key in ['position','anchor','scale','rotation','opacity','fill','strokeWidth','trimEnd','path'],'Unsupported animation property: '+key)
                if key in ['fill','strokeWidth','trimEnd','path']:
                    require(typ=='shape','Geometry animation on non-shape')
                    require((key!='fill' or 'fill' in l) and (key!='strokeWidth' or 'stroke' in l) and (key!='trimEnd' or l.get('trim')) and (key!='path' or l['geometry']['type']=='path'),'Missing property target')
                fields(spec,'value keys loop','property')
                require(('value' in spec)!=('keys' in spec),'Specify exactly one of value/keys')
                vals=[]
                if 'keys' in spec:
                    require(isinstance(spec['keys'],list) and 1<=len(spec['keys'])<=10000,'Invalid keyframes');last=-1
                    for k in spec['keys']:
                        fields(k,'time value ease influence','keyframe')
                        require(number(k.get('time'),0,c['duration']) and k['time']>last,'Key times must be increasing and in comp');last=k['time']
                        require(k.get('ease','bezier') in ['bezier','linear','hold'],'Unknown easing')
                        require(number(k.get('influence',33.333),.1,100),'Invalid ease influence');require('value' in k,'Missing key value');vals.append(k['value'])
                else:vals=[spec['value']]
                if 'loop' in spec:require(isinstance(spec['loop'],bool),'loop must be boolean')
                if spec.get('loop'):require(len(spec.get('keys',[]))>=2,'Loop requires >=2 keys')
                for v in vals:
                    if key in ['position','anchor','scale']:require(vec(v,2),'Expected 2D vector')
                    elif key=='fill':require(vec(v,3,0,1),'Expected RGB 0–1')
                    elif key=='path':
                        path_shape(v)
                        require(len(v['vertices'])==len(l['geometry']['vertices']) and v.get('closed',True)==l['geometry'].get('closed',True),'Path morph topology must match')
                    else:require(number(v,0,100) if key in ['opacity','trimEnd'] else number(v,0,1000) if key=='strokeWidth' else number(v),'Invalid scalar')
        parent_edges={k:[] for k in ids}
        for l in c['layers']:
            if 'parent' in l:require(ident(l['parent']) and l['parent'] in ids,'Unknown parent');parent_edges[l['id']].append(l['parent'])
        acyclic(parent_edges,'Parent hierarchy')
        require(isinstance(c.get('markers',[]),list),'markers must be list')
        for m in c.get('markers',[]):
            fields(m,'time text','marker');require(number(m.get('time'),0,c['duration']) and isinstance(m.get('text'),str),'Invalid marker')
    acyclic(edges,'Precomp hierarchy')
    return s

def load(path):
    def reject(v):raise SceneError('Non-finite JSON constant: '+v)
    def pairs(items):
        d={}
        for k,v in items:
            require(k not in d,'Duplicate JSON key: '+k);d[k]=v
        return d
    return validate(json.loads(path.read_text(encoding='utf-8'),parse_constant=reject,object_pairs_hook=pairs))

def generate(source,out,production=None):
    s=load(source);runtime=Path(__file__).with_name('runtime.jsx').read_text()
    qc={'source_validation':'passed','native_execution':'unverified','rig_visual_review':'unverified','render_validation':'unverified'}
    if production:
        from production_check import check
        report=check(s,json.loads(Path(production).read_text(encoding='utf-8')))
        require(report['passed'],'Production requirements failed: '+ '; '.join(report['errors']))
        qc['production_contract']=report
    assets=[]
    for a in s['assets']:
        p=(source.parent/a['path']).resolve();require(p.is_relative_to(source.parent.resolve()),'Asset escapes package root')
        require(p.is_file(),'Missing asset: '+str(p));assets.append((p,a['path']))
    require(not out.exists(),'Output already exists; choose a new directory')
    out.mkdir(parents=True)
    for p,rel in assets:
        dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
    (out/'scene.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'build_project.jsx').write_text('// Generated editable scene builder; run inside After Effects.\nvar SCENE = '+json.dumps(s,ensure_ascii=True)+';\n'+runtime,encoding='utf-8')
    (out/'README.txt').write_text('Open an EMPTY After Effects project. Choose File > Scripts > Run Script File and select build_project.jsx. Choose a NEW .aep filename. Keep assets beside this script. Review fonts, Arabic shaping/RTL, layout, keyframes and footage duration, then render from After Effects. This package is not a rendered video or a prebuilt AEP. Native AE execution has not been verified by this generator. No plugins are required. See scene.json for editable source.\n',encoding='utf-8')
    (out/'source-qc.json').write_text(json.dumps(qc,indent=2)+'\n')
    if production:shutil.copyfile(production,out/'production.json')
    manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return out

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('scene',type=Path);parser.add_argument('--out',type=Path);parser.add_argument('--production',type=Path);parser.add_argument('--validate-only',action='store_true');a=parser.parse_args()
    try:
        if a.validate_only:
            scene=load(a.scene)
            if a.production:
                from production_check import check
                report=check(scene,json.loads(a.production.read_text()))
                require(report['passed'],'Production requirements failed: '+'; '.join(report['errors']))
            print('Scene validation passed')
        else:
            require(a.out is not None,'--out is required');print(generate(a.scene,a.out,a.production))
    except (SceneError,OSError,json.JSONDecodeError) as e:parser.exit(1,str(e)+'\n')
