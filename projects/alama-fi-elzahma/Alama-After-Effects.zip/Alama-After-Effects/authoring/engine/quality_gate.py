#!/usr/bin/env python3
"""Require explicit evidence for final animation delivery; never infer visual approval from metadata."""
import argparse,hashlib,json
from pathlib import Path
REQUIRED={'source_contract','native_structure','rig_visual','storyboard_visual','rendered_color','render_decode','editability','audio_sync'}

def check(report,base):
    errors=[]
    if not isinstance(report,dict) or (type(report.get('version')) is not int or report.get('version')!=1) or not isinstance(report.get('checks'),dict):return {'final_ready':False,'errors':['Malformed evidence report']}
    artifacts=report.get('artifacts',{})
    if not isinstance(artifacts,dict) or set(artifacts)!={'source_manifest','native_project','video'}:
        errors.append('Current source manifest, native project and rendered video fingerprints are required')
    else:
        for role,e in artifacts.items():
            if not isinstance(e,dict) or set(e)!={'path','sha256'} or not isinstance(e['path'],str):errors.append(role+': malformed artifact');continue
            p=(base/e['path']).resolve()
            if not p.is_relative_to(base.resolve()) or not p.is_file():errors.append(role+': artifact missing/outside package');continue
            if hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:errors.append(role+': stale artifact')
            if role=='source_manifest':
                try:
                    contents=json.loads(p.read_text())
                    if not isinstance(contents,dict) or not contents:raise ValueError('Empty manifest')
                    for rel,h in contents.items():
                        target=(p.parent/rel).resolve()
                        if not target.is_relative_to(base.resolve()) or not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=h:errors.append('Source manifest stale: '+str(rel))
                except (OSError,ValueError,TypeError):errors.append('Unreadable source manifest')
    checks=report['checks']
    if set(checks)!=REQUIRED:errors.append('Exactly these checks are required: '+', '.join(sorted(REQUIRED)))
    for name in REQUIRED:
        c=checks.get(name,{})
        if not isinstance(c,dict):errors.append(name+': invalid entry');continue
        if name=='audio_sync' and c.get('status')=='not_applicable' and c.get('reason')=='No audio requested or delivered':continue
        if c.get('status')!='passed':errors.append(name+': not passed');continue
        if not isinstance(c.get('review'),str) or not c['review'].strip():errors.append(name+': review notes missing')
        if not isinstance(c.get('evidence'),list) or not c['evidence']:errors.append(name+': evidence missing');continue
        for e in c['evidence']:
            if not isinstance(e,dict) or set(e)!={'path','sha256'} or not isinstance(e['path'],str):errors.append(name+': malformed evidence');continue
            p=(base/e['path']).resolve()
            if not p.is_relative_to(base.resolve()) or not p.is_file():errors.append(name+': evidence missing/outside package');continue
            if hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:errors.append(name+': stale/changed evidence '+e['path'])
    return {'final_ready':not errors,'errors':errors,'scope':'Confirms recorded evidence is present and unchanged. Review statements still require truthful native/visual inspection; this tool does not perform it.'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('report',type=Path);a=p.parse_args()
    try:r=check(json.loads(a.report.read_text()),a.report.parent);print(json.dumps(r,indent=2));raise SystemExit(0 if r['final_ready'] else 1)
    except (ValueError,OSError) as e:p.exit(1,str(e)+'\n')
