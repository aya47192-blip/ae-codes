"""Match a validated AE scene to a frame-based production contract; no native/visual claims."""
import argparse,json,math
from pathlib import Path

def check(scene,spec):
    errors=[]
    def test(ok,msg):
        if not ok:errors.append(msg)
    def near(a,b,tol=1e-6):
        return isinstance(a,(int,float)) and not isinstance(a,bool) and math.isfinite(a) and abs(a-b)<=tol
    def exact(a,b):
        return isinstance(a,list) and len(a)==len(b) and all(near(x,y,1/65535) for x,y in zip(a,b))
    def values(p):return [k['value'] for k in p.get('keys',[])] if 'keys' in p else [p.get('value')]
    required={'version','width','height','fps','frames','colorManagement','shots','colors','joints'}
    if not isinstance(spec,dict) or set(spec)!=required:return {'passed':False,'errors':['Production contract has missing/unknown top-level fields'],'native':'unverified'}
    if not all(type(spec[k]) is int and spec[k]>0 for k in ['width','height','frames']) or not near(spec.get('version'),1) or not isinstance(spec.get('fps'),(int,float)) or isinstance(spec['fps'],bool) or not math.isfinite(spec['fps']) or spec['fps']<=0:
        return {'passed':False,'errors':['Invalid contract dimensions/fps/frames/version'],'native':'unverified'}
    for k in ['shots','colors','joints']:
        if not isinstance(spec[k],list):return {'passed':False,'errors':[k+' must be a list'],'native':'unverified'}
    comps={c['id']:c for c in scene['comps']};main=comps[scene['main']];fps=spec['fps']
    test(main['width']==spec['width'] and main['height']==spec['height'],'Main composition dimensions differ')
    test(near(main['fps'],fps),'Main fps differs')
    test(near(main['duration']*fps,spec['frames'],1e-4),'Main duration/frame count differs')
    test(scene.get('colorManagement')==spec['colorManagement'],'Explicit scene color management differs or is missing')
    test(scene.get('strictFonts') is True or not any(l['type']=='text' for c in comps.values() for l in c['layers']),'Strict font checking required for production text')
    for c in comps.values():
        test(near(c['fps'],fps),'Comp fps differs: '+c['id'])
        test(near(c['duration']*fps,round(c['duration']*fps),1e-4),'Off-frame comp duration: '+c['id'])
        for l in c['layers']:
            for name in ['start','in','out']:
                if name in l:test(near(l[name]*fps,round(l[name]*fps),1e-4),'Off-frame '+name+': '+c['id']+'/'+l['id'])
            for prop,p in l['properties'].items():
                for k in p.get('keys',[]):test(near(k['time']*fps,round(k['time']*fps),1e-4),'Off-frame key: '+c['id']+'/'+l['id']+'/'+prop)
                if prop=='scale':test(not any(0 in v for v in values(p)),'Zero scale needs an explicitly reviewed custom implementation: '+l['id'])
    previous=0;seen=set()
    test(bool(spec['shots']),'Shot list is empty')
    for sh in spec['shots']:
        if not isinstance(sh,dict) or not {'id','comp','inFrame','outFrame','reference','reviewFrames'}<=set(sh) or set(sh)-{'id','comp','layer','inFrame','outFrame','reference','reviewFrames'}:
            errors.append('Malformed shot');continue
        if not all(type(sh[k]) is int for k in ['inFrame','outFrame']) or not isinstance(sh['reviewFrames'],list):errors.append('Shot frame ranges must be integers');continue
        test(sh['id'] not in seen,'Duplicate shot id');seen.add(sh['id'])
        test(sh['inFrame']==previous and sh['outFrame']>sh['inFrame'],'Shots must cover the timeline contiguously in order');previous=sh['outFrame']
        test(isinstance(sh['reference'],str) and bool(sh['reference'].strip()),'Missing storyboard reference: '+str(sh['id']))
        test(bool(sh['reviewFrames']) and all(type(f) is int and sh['inFrame']<=f<sh['outFrame'] for f in sh['reviewFrames']),'Invalid shot review frames')
        test(sh['comp'] in comps,'Unknown shot comp')
        if sh['comp'] not in comps:continue
        if 'layer' in sh:
            layer=next((l for l in main['layers'] if l['id']==sh['layer']),None)
            test(layer is not None and layer['type']=='precomp' and layer.get('source')==sh['comp'],'Shot precomp layer/source mismatch')
            if layer:
                test(near(layer.get('in',0)*fps,sh['inFrame'],1e-4) and near(layer.get('out',main['duration'])*fps,sh['outFrame'],1e-4),'Shot layer in/out differs')
        else:test(len(spec['shots'])==1 and sh['comp']==scene['main'],'Multi-shot timeline needs explicit main precomp layer mappings')
    test(previous==spec['frames'],'Shot coverage differs from frame count')
    def target(ref):
        c=comps.get(ref.get('comp'));l=next((l for l in c['layers'] if l['id']==ref.get('layer')),None) if c else None
        test(l is not None,'Unknown contract layer: '+str(ref));return l
    for col in spec['colors']:
        if not isinstance(col,dict) or set(col)!={'comp','layer','property','rgb'} or not isinstance(col['rgb'],list) or len(col['rgb'])!=3 or not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and 0<=x<=1 for x in col['rgb']):errors.append('Malformed color requirement');continue
        l=target(col)
        if l:
            prop=col['property'];test(prop in ['fill','stroke','color'],'Unknown color target')
            actual=l.get('stroke',{}).get('color') if prop=='stroke' else l.get(prop)
            test(exact(actual,col['rgb']),'Palette mismatch: '+l['id']+'/'+prop)
            if prop=='fill' and 'fill' in l['properties']:test(all(exact(v,col['rgb']) for v in values(l['properties']['fill'])),'Animated fill differs from locked palette: '+l['id'])
    for joint in spec['joints']:
        required_joint={'comp','layer','parent','pivot','minRotation','maxRotation','allowMirror','allowNonUniformScale'}
        if not isinstance(joint,dict) or set(joint)!=required_joint or not all(isinstance(joint[k],(int,float)) and not isinstance(joint[k],bool) and math.isfinite(joint[k]) for k in ['minRotation','maxRotation']) or joint['minRotation']>joint['maxRotation'] or not all(isinstance(joint[k],bool) for k in ['allowMirror','allowNonUniformScale']):errors.append('Malformed joint requirement');continue
        l=target(joint)
        if not l:continue
        test(l.get('parent')==joint['parent'],'Joint parent differs: '+l['id'])
        anchors=values(l['properties'].get('anchor',{'value':[0,0] if l['type'] in ['shape','null'] else None}))
        test(all(exact(a,joint['pivot']) for a in anchors),'Joint pivot differs: '+l['id'])
        for angle in values(l['properties'].get('rotation',{'value':0})):test(joint['minRotation']<=angle<=joint['maxRotation'],'Joint authored rotation exceeds limits: '+l['id'])
        for scale in values(l['properties'].get('scale',{'value':[100,100]})):
            test(joint['allowMirror'] or all(x>0 for x in scale),'Mirrored/collapsed joint: '+l['id'])
            test(joint['allowNonUniformScale'] or near(abs(scale[0]),abs(scale[1])),'Nonuniform joint scale: '+l['id'])
    return {'passed':not errors,'errors':errors,'scope':'Source contract: frame alignment, shot mapping, palette, authored joint limits and scale. Native interpolation, anatomy and rendering unverified.','native':'unverified','rig_visual':'unverified','render':'unverified'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scene',type=Path);p.add_argument('contract',type=Path);a=p.parse_args()
    from generate import load
    result=check(load(a.scene),json.loads(a.contract.read_text()));print(json.dumps(result,indent=2));raise SystemExit(0 if result['passed'] else 1)
