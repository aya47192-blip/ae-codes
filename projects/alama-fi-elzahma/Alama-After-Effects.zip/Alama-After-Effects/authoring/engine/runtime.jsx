/* Locally authored ExtendScript runtime. Scene literal is prepended by generate.py. */
(function () {
    function fail(s) { throw new Error(s); }
    function fileAt(rel) { return new File(File($.fileName).parent.fsName + '/' + rel); }
    function shape(v) {
        var s = new Shape(); s.vertices = v.vertices; s.closed = v.closed !== false;
        var z = [], i; for (i=0;i<v.vertices.length;i++) z.push([0,0]);
        s.inTangents = v.inTangents || z; s.outTangents = v.outTangents || z; return s;
    }
    var names = {position:'ADBE Position',anchor:'ADBE Anchor Point',scale:'ADBE Scale',
        rotation:'ADBE Rotate Z',opacity:'ADBE Opacity'};
    function propertyFor(layer, key) {
        if (names[key]) return layer.property('ADBE Transform Group').property(names[key]);
        var g = layer.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group');
        if (key==='fill') return g.property('ADBE Vector Graphic - Fill').property('ADBE Vector Fill Color');
        if (key==='strokeWidth') return g.property('ADBE Vector Graphic - Stroke').property('ADBE Vector Stroke Width');
        if (key==='trimEnd') return g.property('ADBE Vector Filter - Trim').property('ADBE Vector Trim End');
        if (key==='path') return g.property('ADBE Vector Shape - Group').property('ADBE Vector Shape');
        fail('Unknown property: '+key);
    }
    function applyProperty(layer,key,spec) {
        var p = propertyFor(layer,key), i, j, ease, dims, k, mode;
        function value(v) { return key==='path' ? shape(v) : v; }
        if (!p) fail('Unavailable property '+key+' on '+layer.name);
        if (spec.keys) {
            for (i=0;i<spec.keys.length;i++) p.setValueAtTime(spec.keys[i].time,value(spec.keys[i].value));
            if (key==='position') for(i=1;i<=p.numKeys;i++) {
                p.setSpatialAutoBezierAtKey(i,false);p.setSpatialContinuousAtKey(i,false);
                p.setSpatialTangentsAtKey(i,[0,0],[0,0]);
            }
            for (i=0;i<spec.keys.length;i++) {
                k=spec.keys[i]; mode=k.ease || 'bezier';
                if (mode==='hold') p.setInterpolationTypeAtKey(i+1,KeyframeInterpolationType.HOLD,KeyframeInterpolationType.HOLD);
                else if (mode==='linear') p.setInterpolationTypeAtKey(i+1,KeyframeInterpolationType.LINEAR,KeyframeInterpolationType.LINEAR);
                else {
                    p.setInterpolationTypeAtKey(i+1,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);
                    dims = key==='scale' ? k.value.length : 1;
                    ease=[]; for(j=0;j<dims;j++) ease.push(new KeyframeEase(0,k.influence || 33.333));
                    p.setTemporalEaseAtKey(i+1,ease,ease);
                }
            }
            if (spec.loop) {
                if (!p.canSetExpression) fail('Loop expression unavailable: '+key);
                p.expression='loopOut("cycle")';
            }
        } else p.setValue(value(spec.value));
    }
    function makeShape(comp,l) {
        var layer=comp.layers.addShape(), g, content, p, s=l.geometry;
        layer.name=l.name;
        g=layer.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group');
        g.name='EDIT_Geometry'; content=g.property('ADBE Vectors Group');
        if(s.type==='rect') {
            p=content.addProperty('ADBE Vector Shape - Rect');
            p.property('ADBE Vector Rect Size').setValue(s.size);
            p.property('ADBE Vector Rect Roundness').setValue(s.radius || 0);
        } else if(s.type==='ellipse') {
            p=content.addProperty('ADBE Vector Shape - Ellipse');
            p.property('ADBE Vector Ellipse Size').setValue(s.size);
        } else {
            p=content.addProperty('ADBE Vector Shape - Group');
            p.property('ADBE Vector Shape').setValue(shape(s));
        }
        // Reacquire indexed group handles after addProperty invalidates earlier handles.
        if(l.fill) {
            content=layer.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group');
            p=content.addProperty('ADBE Vector Graphic - Fill');p.property('ADBE Vector Fill Color').setValue(l.fill);
        }
        if(l.stroke) {
            content=layer.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group');
            p=content.addProperty('ADBE Vector Graphic - Stroke');
            p.property('ADBE Vector Stroke Color').setValue(l.stroke.color);
            p.property('ADBE Vector Stroke Width').setValue(l.stroke.width);
        }
        if(l.trim) {
            content=layer.property('ADBE Root Vectors Group').property(1).property('ADBE Vectors Group');
            p=content.addProperty('ADBE Vector Filter - Trim');p.property('ADBE Vector Trim End').setValue(100);
        }
        return layer;
    }
    var begun=false;
    try {
        var i,j,c,l,item,layer,td,doc,ref,comps={},layers={},assets={},base=File($.fileName).parent;
        if(app.project && app.project.numItems>0) fail('Open an empty project first. Existing projects are not modified.');
        // Verify all assets before building anything; no network downloads or shell execution.
        for(i=0;i<SCENE.assets.length;i++) {
            ref=SCENE.assets[i]; if(!fileAt(ref.path).exists) fail('Missing asset: '+ref.path);
        }
        var saveFile=File.saveDialog('Save the new editable project with a NEW filename');
        if(!saveFile) return;
        if(!/\.aep$/i.test(saveFile.name)) saveFile=new File(saveFile.fsName+'.aep');
        if(saveFile.exists) fail('Choose a new filename; existing files are not overwritten.');
        if(!app.project) app.newProject();
        if(SCENE.colorManagement) {
            var cm=SCENE.colorManagement,profiles=app.project.listColorProfiles(),found=false;
            for(i=0;i<profiles.length;i++) if(profiles[i]===cm.workingSpace) found=true;
            if(!found) fail('Requested working color profile unavailable: '+cm.workingSpace);
            app.project.bitsPerChannel=cm.bitsPerChannel;
            app.project.workingSpace=cm.workingSpace;app.project.linearizeWorkingSpace=cm.linearize;
        }
        if(SCENE.strictFonts) {
            if(!app.fonts || !app.fonts.getFontsByPostScriptName) fail('Strict font preflight requires a version with app.fonts.getFontsByPostScriptName.');
            for(i=0;i<SCENE.comps.length;i++) for(j=0;j<SCENE.comps[i].layers.length;j++) {
                l=SCENE.comps[i].layers[j];if(l.type==='text') {
                    var fontMatches=app.fonts.getFontsByPostScriptName(l.font || 'ArialMT');
                    if(!fontMatches || fontMatches.length===0) fail('Required font unavailable: '+(l.font || 'ArialMT'));
                    if(fontMatches[0].isSubstitute) fail('Required font is substituted: '+(l.font || 'ArialMT'));
                }
            }
        }
        app.beginUndoGroup('Build editable scene');begun=true;
        var folder=app.project.items.addFolder(SCENE.name);
        for(i=0;i<SCENE.assets.length;i++) {
            ref=SCENE.assets[i]; item=app.project.importFile(new ImportOptions(fileAt(ref.path)));
            item.name=ref.id;item.parentFolder=folder;assets[ref.id]=item;
        }
        for(i=0;i<SCENE.comps.length;i++) {
            c=SCENE.comps[i];item=app.project.items.addComp(c.id,c.width,c.height,1,c.duration,c.fps);
            item.parentFolder=folder;item.bgColor=c.background || [0,0,0];comps[c.id]=item;
        }
        for(i=0;i<SCENE.comps.length;i++) {
            c=SCENE.comps[i];layers[c.id]={};
            // A comp background setting alone is not rendered. Make the requested background real.
            if(c.background) {
                layer=comps[c.id].layers.addSolid(c.background,'BG_Auto_Rendered',c.width,c.height,1,c.duration);
                layer.moveToEnd();
            }
            // JSON lists front-to-back; add in reverse because AE adds layers at the top.
            for(j=c.layers.length-1;j>=0;j--) {
                l=c.layers[j];item=comps[c.id];
                if(l.type==='shape') layer=makeShape(item,l);
                else if(l.type==='null') layer=item.layers.addNull(c.duration);
                else if(l.type==='text') {
                    layer=item.layers.addText(l.text);td=layer.property('ADBE Text Properties').property('ADBE Text Document');
                    doc=td.value;doc.font=l.font || 'ArialMT';doc.fontSize=l.fontSize || 64;
                    doc.applyFill=true;doc.fillColor=l.color || [1,1,1];doc.applyStroke=false;
                    doc.justification=l.align==='center' ? ParagraphJustification.CENTER_JUSTIFY : (l.align==='right' ? ParagraphJustification.RIGHT_JUSTIFY : ParagraphJustification.LEFT_JUSTIFY);
                    td.setValue(doc);
                } else if(l.type==='solid') layer=item.layers.addSolid(l.color,l.name,c.width,c.height,1,c.duration);
                else layer=item.layers.add(l.type==='precomp' ? comps[l.source] : assets[l.source]);
                layer.name=l.name;layer.startTime=l.start || 0;layer.inPoint=l.in === undefined ? 0 : l.in;
                layer.outPoint=l.out === undefined ? c.duration : l.out;layers[c.id][l.id]=layer;
                if(l.type!=='null') layer.motionBlur=!!l.motionBlur;
            }
            // setParentWithJump keeps declared local transform coordinates, then apply authored values.
            for(j=0;j<c.layers.length;j++) {
                l=c.layers[j];layer=layers[c.id][l.id];if(l.parent) layer.setParentWithJump(layers[c.id][l.parent]);
            }
            for(j=0;j<c.layers.length;j++) {
                l=c.layers[j];layer=layers[c.id][l.id];
                // Explicit defaults avoid media-/layer-dependent default anchors and positions.
                if(l.type==='shape' || l.type==='null') {
                    layer.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([0,0]);
                    layer.property('ADBE Transform Group').property('ADBE Position').setValue([0,0]);
                }
                layer.property('ADBE Transform Group').property('ADBE Scale').setValue([100,100]);
                layer.property('ADBE Transform Group').property('ADBE Rotate Z').setValue(0);
                layer.property('ADBE Transform Group').property('ADBE Opacity').setValue(100);
                var key; for(key in l.properties) if(l.properties.hasOwnProperty(key)) applyProperty(layer,key,l.properties[key]);
                if(l.type==='footage' || l.type==='precomp') {
                    if(!layer.source.mainSource || !layer.source.mainSource.isStill) {
                        if(layer.outPoint-layer.startTime > layer.source.duration + 0.5/c.fps)
                            fail('Source shorter than visible layer: '+c.id+'/'+l.id);
                        if(layer.inPoint < layer.startTime) fail('Visible layer precedes source start: '+c.id+'/'+l.id);
                    }
                }
            }
            item=comps[c.id];item.motionBlur=true;
            if(c.markers) for(j=0;j<c.markers.length;j++) item.markerProperty.setValueAtTime(c.markers[j].time,new MarkerValue(c.markers[j].text));
        }
        // Verify important native structure before saving; this is not a visual/render approval.
        for(i=0;i<SCENE.comps.length;i++) {
            c=SCENE.comps[i];item=comps[c.id];
            if(item.width!==c.width || item.height!==c.height || Math.abs(item.frameRate-c.fps)>0.0001)
                fail('Native composition settings differ: '+c.id);
            if(Math.abs(item.duration-c.duration)>0.5/c.fps) fail('Native duration differs: '+c.id);
            if(item.numLayers!==c.layers.length+(c.background ? 1 : 0)) fail('Native layer count differs: '+c.id);
            for(j=0;j<c.layers.length;j++) {
                l=c.layers[j];layer=layers[c.id][l.id];
                if(layer.name!==l.name) fail('Layer name differs: '+l.id);
                if(l.parent && layer.parent!==layers[c.id][l.parent]) fail('Parent differs: '+l.id);
                var pk;for(pk in l.properties) if(l.properties.hasOwnProperty(pk)) {
                    var sp=l.properties[pk],pr=propertyFor(layer,pk);
                    if(sp.keys && pr.numKeys!==sp.keys.length) fail('Native key count differs: '+l.id+'/'+pk);
                    if(pr.canSetExpression && pr.expressionError) fail('Expression error: '+l.id+'/'+pk+' '+pr.expressionError);
                }
            }
        }
        comps[SCENE.main].openInViewer();app.project.save(saveFile);
        alert('Editable AEP saved: '+saveFile.fsName+'\nNative structure checks passed. Visual rig checks, color comparison and rendering remain UNVERIFIED. Review before final delivery.');
    } catch(e) { alert('Scene build stopped: '+e.toString()+'\nLine: '+e.line+'\nNo successful AEP or video render is implied. Inspect partial work before retrying.'); }
    finally { if(begun) app.endUndoGroup(); }
}());
