from pathlib import Path
import sys,json,math,wave,shutil
import numpy as np
TITLE="علامة في الزحمة"
SHOTS=[]
SYNOPSIS=""
LOGLINE=""
ROOT=Path(__file__).parent;PACKAGE=ROOT/'after-effects';PACKAGE.mkdir(exist_ok=True)
W,H,FPS=1920,1080,24
C={'ink':'243343','hair':'303146','skin':'D9A384','red':'BD5C65','navy':'344B67','teal':'548C8A','cream':'F5EEDC','sky':'DAE6E8','paper':'FFFDF5','blue':'B9C9D7','gold':'DAAE63','pink':'DEB8AD','green':'879C86'}
def rgb(c):
 c=C.get(c,c);return [int(c[i:i+2],16)/255 for i in (0,2,4)]
def val(x):return {'value':x}
def keys(v):return {'keys':[{'time':round(t*FPS)/FPS,'value':x,'ease':'bezier'} for t,x in v]}
class Draw:
 def __init__(self,id,duration):self.c={'id':id,'width':W,'height':H,'fps':FPS,'duration':duration,'layers':[]};self.n=0
 def add(self,l):self.c['layers'].append(l);return l
 def id(self,name):self.n+=1;return 'L'+str(self.n)+'_'+name
 def null(self,name,pos=(0,0),parent=None,scale=100):
  l={'id':self.id(name),'name':name,'type':'null','properties':{'position':val(list(pos)),'scale':val([scale,scale])}}
  if parent:l['parent']=parent
  self.add(l);return l
 def shape(self,name,geom,color=None,stroke=None,parent=None,pos=(0,0),width=4):
  l={'id':self.id(name),'name':name,'type':'shape','geometry':geom,'properties':{'position':val(list(pos))}}
  if color:l['fill']=rgb(color)
  if stroke:l['stroke']={'color':rgb(stroke),'width':width}
  if parent:l['parent']=parent
  self.add(l);return l
 def rect(self,name,x,y,w,h,color,r=0,parent=None,stroke=None):return self.shape(name,{'type':'rect','size':[w,h],'radius':r},color,stroke,parent,(x,y))
 def ellipse(self,name,x,y,w,h,color,parent=None,stroke=None):return self.shape(name,{'type':'ellipse','size':[w,h]},color,stroke,parent,(x,y))
 def path(self,name,points,color=None,stroke=None,parent=None,width=4,closed=True):return self.shape(name,{'type':'path','vertices':[list(p) for p in points],'closed':closed},color,stroke,parent,width=width)
 def text(self,name,txt,x,y,size=48,color='ink',align='center',parent=None):
  l={'id':self.id(name),'name':name,'type':'text','text':txt,'font':'NotoNaskhArabic-Regular','fontSize':size,'color':rgb(color),'align':align,'properties':{'position':val([x,y])}}
  if parent:l['parent']=parent
  self.add(l);return l
 def finish(self):self.c['layers'].reverse();return self.c

def environment(d,kind):
 d.rect('BG_Rendered',960,540,1920,1080,'cream')
 d.rect('Floor',960,885,1920,390,'E0D5BC')
 if kind=='school':
  d.rect('Sky',960,190,1920,380,'sky');d.ellipse('Sun',1630,125,130,130,'gold')
  d.rect('School_Wall',960,490,1920,400,'E8DCC5');d.rect('Gate',960,480,410,430,'navy',100)
  for x in range(790,1160,55):d.rect('Gate_Rail',x,495,12,390,'blue')
  for x in [210,1710]:
   d.ellipse('Tree_Foliage',x,385,310,270,'green');d.rect('Tree_Trunk',x,630,24,260,'897258')
  d.rect('School_Plate',960,245,460,95,'paper',20);d.text('School_Name','مدرستنا',960,267,58)
 elif kind=='corridor':
  d.rect('Wall_Top',960,170,1920,340,'sky');
  for x in [220,470,1450,1700]:
   d.rect('Locker',x,475,200,445,'blue',18);d.rect('Locker_Seam',x+63,475,4,410,'9CABB7');d.ellipse('Locker_Knob',x+40,470,12,12,'ink')
  d.rect('Wall_Band',960,675,1920,25,'gold')
 elif kind=='class':
  d.rect('Board_Frame',960,290,950,390,'897258',24);d.rect('Blackboard',960,290,910,350,'teal',18)
  d.path('Chalk_Line',[(600,300),(1300,300)],stroke='paper',width=4,closed=False)
  for x in [190,1650]:
   d.rect('Desk',x,725,300,50,'gold',10);d.rect('Desk_Leg',x,825,20,160,'navy')
 elif kind=='home':
  d.rect('Wall',960,375,1920,750,'E9D6CB');d.rect('Window_Frame',1540,320,380,410,'paper',25);d.rect('Window',1540,320,325,355,'blue',10)
  d.rect('Window_Cross',1540,320,10,355,'paper');d.rect('Window_Cross',1540,320,325,10,'paper')
  d.rect('Sofa_Back',930,660,1160,235,'pink',80);d.rect('Sofa_Seat',930,805,1280,115,'C79B92',35)
  d.ellipse('Rug',960,870,1350,170,'D8C4AB')
 elif kind=='teacher':
  d.rect('Window',1540,300,420,390,'sky',20);d.rect('Shelf',270,375,280,450,'blue',15)
  for y in [250,420,580]:d.rect('Shelf_Divider',270,y,270,14,'paper')
  d.rect('Teacher_Table',1010,810,1300,95,'gold',20)
 elif kind=='art':
  d.rect('Art_Wall',960,365,1920,730,'sky')
  for x,col in [(250,'pink'),(960,'gold'),(1650,'green')]:
   d.rect('Wall_Frame',x,260,240,230,'paper',15);d.ellipse('Abstract_Print',x,260,110,130,col)
  d.rect('Art_Table',960,805,1700,170,'gold',20)
 elif kind=='paper':
  d.rect('Desk_Surface',960,540,1920,1080,'D6BE94')
  d.rect('Paper_Shadow',975,515,1080,735,'B59E7B',20);d.rect('Paper',960,500,1080,735,'paper',12)
  for x,col in [(1670,'red'),(1720,'teal'),(1770,'navy')]:d.rect('Pencil',x,620,20,300,col,6)

def girl(d,name,x,y,scale=1,who='salma',emotion='sad',cover=False):
 outfit={'salma':'navy','mira':'teal','bully':'pink','mom':'879C86','teacher':'798897'}.get(who,'navy')
 r=d.null(name+'_ROOT',(x,y),scale=scale*100);rid=r['id']
 d.ellipse(name+'_Shadow',0,5,200,35,'B5AA95',rid)
 # Legs are separate thigh/shin/foot controls, kept planted for dialogue.
 hips={};knees={};feet={}
 for side,xx in [('L',-37),('R',37)]:
  hip=d.null(name+'_Hip_'+side,(xx,-112),rid)
  d.rect(name+'_Thigh_'+side,0,28,43,58,'skin',18,hip['id'])
  knee=d.null(name+'_Knee_'+side,(0,56),hip['id'])
  d.rect(name+'_Shin_'+side,0,23,36,50,'skin',16,knee['id'])
  shoe=d.ellipse(name+'_Shoe_'+side,7,51,74,30,'ink',knee['id'])
  hips[side]=hip;knees[side]=knee;feet[side]=shoe
 d.path(name+'_Skirt',[(-72,-210),(72,-210),(107,-100),(-107,-100)],outfit,parent=rid)
 d.rect(name+'_Torso',0,-241,150,145,outfit,34,rid)
 d.rect(name+'_Collar',0,-286,55,22,'paper',7,rid)
 # Arms articulated around local shoulder and elbow pivots.
 arms={}
 for side,xx in [('L',-77),('R',77)]:
  a=d.null(name+'_Shoulder_'+side,(xx,-287),rid);aid=a['id']
  d.rect(name+'_UpperArm_'+side,0,40,34,84,outfit,16,aid)
  e=d.null(name+'_Elbow_'+side,(0,80),aid);eid=e['id']
  d.rect(name+'_Forearm_'+side,0,35,26,76,'skin',12,eid);d.ellipse(name+'_Hand_'+side,0,77,35,42,'skin',eid)
  arms[side]=(a,e)
 head=d.null(name+'_HEAD',(0,-373),rid);hid=head['id']
 d.ellipse(name+'_Hair_Back',0,-8,186,207,'hair',hid)
 d.rect(name+'_Neck',0,100,48,44,'skin',15,hid)
 d.ellipse(name+'_Face',0,4,148,179,'skin',hid)
 if who=='salma':d.path(name+'_Birthmark_FIXED',[(15,-37),(38,-46),(58,-31),(52,-5),(61,24),(43,47),(23,39),(12,16)],'red',parent=hid)
 # Ears and bangs share the head transform, never mirrored.
 d.ellipse(name+'_Ear_L',-75,10,22,37,'skin',hid);d.ellipse(name+'_Ear_R',75,10,22,37,'skin',hid)
 for side,xx in [('L',-30),('R',30)]:
  eye=d.ellipse(name+'_EyeWhite_'+side,xx,-10,30,20,'paper',hid)
  d.ellipse(name+'_Pupil_'+side,xx,-9,10,14,'ink',hid)
  b=d.path(name+'_Brow_'+side,[(xx-14,-35),(xx+12,-33)],stroke='hair',parent=hid,width=5,closed=False)
  if emotion=='sad':b['properties']['rotation']=val(-10 if side=='L' else 10)
 d.path(name+'_Nose',[(1,0),(8,13),(-1,16)],stroke='B17E67',parent=hid,width=3,closed=False)
 mouth=[(-15,46),(0,53),(15,46)] if emotion=='happy' else [(-14,49),(0,43),(14,49)] if emotion=='sad' else [(-14,46),(14,46)]
 d.path(name+'_Mouth',mouth,stroke='ink',parent=hid,width=4,closed=False)
 d.path(name+'_Hair_Crown',[(-80,-4),(-82,-85),(-45,-108),(34,-105),(78,-75),(80,-21),(31,-53),(-12,-47),(-43,-18)],'hair',parent=hid)
 if cover:
  front=d.path(name+'_Hair_Front',[(-4,-85),(65,-85),(88,-20),(79,102),(27,88),(23,18)],'hair',parent=hid)
 else:front=None
 if who not in ['mom','teacher']:d.path(name+'_Ribbon',[(-66,-75),(-105,-96),(-107,-56),(-70,-63),(-40,-96),(-38,-58)],'gold' if who=='salma' else 'pink',parent=hid)
 return {'root':r,'head':head,'arms':arms,'hair':front,'hips':hips,'knees':knees,'feet':feet}

def subtitle(d,text,duration):
 # Explicit separately editable caption region; two timed lines are laid out in the reading direction.
 d.rect('Caption_Background',960,995,1920,170,'243343')
 lines=text.split('\n')
 for i,line in enumerate(lines):d.text('TXT_Caption_'+str(i+1),line,960,980+i*58 if len(lines)>1 else 1005,46,'paper')

def portrait(d):
 g=d.null('Portrait',(960,460),scale=180)
 d.ellipse('Portrait_Hair',0,0,185,205,'hair',g['id']);d.ellipse('Portrait_Face',0,8,145,176,'skin',g['id'])
 mark=d.path('Portrait_Birthmark',[(15,-37),(38,-46),(58,-31),(52,-5),(61,24),(43,47),(23,39),(12,16)],'red',parent=g['id'])
 for x in [-30,30]:d.ellipse('Portrait_Eye',x,-9,12,16,'ink',g['id'])
 d.path('Portrait_Smile',[(-16,45),(0,53),(16,45)],stroke='ink',parent=g['id'],width=4,closed=False)
 return g,mark

def make_shot(index,duration):
 d=Draw('Shot%02d'%index,duration);ids={};kind={1:'school',2:'school',3:'school',4:'school',5:'paper',6:'corridor',7:'class',8:'paper',9:'home',10:'home',11:'school',12:'corridor',13:'teacher',14:'class',15:'art',16:'art',17:'paper',18:'school',19:'class',20:'paper'}[index]
 environment(d,kind)
 if index in [1,2,3,4,6,7,9,10,11,12,13,15,16,18,19]:
  close=index in [2,10,16];x=550 if index in [3,4,9,10,11,12,13,15,16,18] else 960;y=880 if not close else 1040;scale=1.1 if not close else 1.7
  if index==19:x=810;y=890;scale=1.05
  sal=girl(d,'Salma',x,y,scale,'salma','happy' if index in [16,18,19] else 'neutral' if index in [1,2,11,12,13,15] else 'sad',cover=index in [6,7,9,10,11,12,13,15,16,19]);ids['salma']=sal
  sal['head']['properties']['rotation']=keys([(0,-3),(duration*.5,0),(duration,0)])
  if index==1:sal['root']['properties']['scale']=keys([(0,[90,90]),(duration,[96,96])]);d.text('Title',960,120,104,'ink') if False else None;d.text('TXT_Title',TITLE,960,150,108)
  if index==2:
   a,e=sal['arms']['R'];a['properties']['rotation']=keys([(0,0),(1.5,-95),(3,-90),(4.5,0)]);e['properties']['rotation']=keys([(0,0),(1.5,-100),(3,-95),(4.5,0)])
  if index in [3,4]:
   for j,x2 in enumerate([1330,1630]):
    b=girl(d,'Peer'+str(j),x2,880,.9,'bully','neutral')
    if index==3 and j==0:b['arms']['L'][0]['properties']['rotation']=keys([(0,0),(1,-55),(3,-55),(5,0)])
    if index==4:b['root']['properties']['position']=keys([(0,[x2,880]),(duration,[x2+220,880])])
  if index==6:
   sal['root']['properties']['position']=keys([(0,[750,880]),(duration,[1020,880])]);sal['head']['properties']['rotation']=val(5)
  if index==7:
   d.rect('Empty_Chair',1290,700,230,210,'blue',22);d.rect('Empty_Seat',1290,825,280,45,'navy',10)
   d.rect('Desk_Foreground',940,835,730,70,'gold',15)
  if index in [9,10]:
   m=girl(d,'Mother',1320,960 if index==10 else 890,1.55 if index==10 else 1.1,'mom','neutral');m['head']['properties']['rotation']=keys([(0,0),(2,-5),(duration,-5)])
  if index in [11,12,15,16,19]:
   mi=girl(d,'Mira',1320 if index!=19 else 1130,1040 if index==16 else 890,1.6 if index==16 else 1.08,'mira','happy')
   if index==12:mi['arms']['R'][0]['properties']['rotation']=keys([(0,0),(1.3,-75),(3.7,-75),(5.5,0)])
  if index==13:
   te=girl(d,'Teacher',1400,900,1.16,'teacher','neutral');te['head']['properties']['rotation']=keys([(0,0),(2,-4),(duration,-4)])
  if index in [15,16]:
   d.rect('Table_Foreground',960,820,1780,135,'gold',20);d.rect('Blank_Paper',960,760,400,120,'paper',8)
  if index==18:
   b=girl(d,'PeerApology',1330,880,1.1,'bully','sad');b['head']['properties']['rotation']=keys([(0,7),(duration,0)])
  if index==19:
   girl(d,'ClassmateL',420,900,.9,'bully','neutral');girl(d,'ClassmateR',1550,900,.9,'bully','neutral')
   if sal['hair']:sal['hair']['properties']['position']=keys([(0,[0,0]),(2,[0,0]),(3.5,[65,-45]),(duration,[65,-45])])
   a,e=sal['arms']['R'];a['properties']['rotation']=keys([(0,0),(2,-110),(3,-100),(4.5,0)]);e['properties']['rotation']=keys([(0,0),(2,-70),(3,-70),(4.5,0)])
   # Brief nonflashing camera aperture visual: still hold, no full-screen flash.
   d.ellipse('Camera_Status',1790,120,20,20,'red')
 if index==5:
  pencil=d.rect('Falling_Pencil',940,260,24,250,'red',5);pencil['properties']['position']=keys([(0,[940,140]),(1.3,[1000,620]),(2,[1010,650]),(duration,[1010,650])]);pencil['properties']['rotation']=keys([(0,0),(1.3,60),(2,90),(duration,90)])
  d.ellipse('Reaching_Hand',1300,600,160,80,'skin')['properties']['position']=keys([(0,[1700,600]),(2,[1250,600]),(4,[1120,650])])
 if index in [8,17]:
  g,mark=portrait(d)
  if index==8:
   cover=d.rect('Covering_Paper',960,460,650,640,'paper',8);cover['properties']['position']=keys([(0,[1800,460]),(2,[1800,460]),(4,[960,460]),(duration,[960,460])])
  else:
   mark['properties']['opacity']=keys([(0,0),(1.5,0),(3,100)]);d.text('Portrait_Title',TITLE,960,835,62,'ink')
 if index==14:
  te=girl(d,'Teacher',470,880,1.15,'teacher','neutral');d.text('Respect_Rule','احترام كل واحد حقّ',1070,320,74,'paper')
  for j in range(3):
   p=d.rect('Followup_Day',850+j*200,700,150,115,'paper',15);p['properties']['opacity']=keys([(0,0),(2+j,0),(2.5+j,100)])
   d.text('Day_Number',str(j+1),850+j*200,716,56)
 if index==20:
  g,mark=portrait(d);g['properties']['scale']=val([115,115]);g['properties']['position']=val([650,480]);d.rect('Photo_Frame',1300,470,560,560,'paper',18)
  photo=girl(d,'Photo_Salma',1230,700,.75,'salma','happy');girl(d,'Photo_Mira',1430,700,.65,'mira','happy');d.text('Final_Title',TITLE,960,160,94)
 subtitle(d,SHOTS[index-1][4],duration)
 c=d.finish();c['markers']=[{'time':0,'text':'STB%02d | '%index+SHOTS[index-1][1]}]
 return c
